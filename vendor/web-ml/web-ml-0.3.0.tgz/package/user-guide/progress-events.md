The event and progress contract is defined in
[`specification/internals/worker-training.md`](../specification/internals/worker-training.md); this
guide shows how applications consume it.

Progress is delivered through **`run.events`, an async iterable**. The function returns a run handle immediately; you consume events while `run.result` waits for the finished result.

There are four public entry points:

| Function                                | Events exposed                                    | Percentage                           |
| --------------------------------------- | ------------------------------------------------- | ------------------------------------ |
| `createTrainingClient().train(request)` | `TrainingEvent` through `run.events`              | `progress.fraction × 100`            |
| `createTuner().search(request)`         | Same event type, including `tuning-progress`      | Calculate from evaluation counts     |
| `nestedCrossValidate(request)`          | Outer-fold events and wrapped inner-search events | Calculate from completed outer folds |
| `crossValidate(request)`                | Fold and optional refit events                    | Calculate from completed folds       |

The factory functions themselves do not emit progress, and synchronous prediction does not emit it.

**1. Model training**

A `progress` event has this shape:

```ts
{
  type: 'progress',
  phase: 'training',
  fraction: 0.55,
  completed: 50,
  total: 100,
  metrics: { loss: 0.12 } // optional
}
```

- **`fraction` is between 0 and 1**, so `0.55` means 55%.
- It is an overall run-progress value, weighted across stages—not the percentage within the current phase.
- `completed` and `total` describe the current work units. Depending on the algorithm, these can be rows, iterations, shards, tree nodes, or processing steps.
- `metrics` can contain numerical diagnostics such as loss; they are not percentages. Ordinary requests accept `liveMetrics: true` for opt-in diagnostics. Existing loss and inertia are available regardless of this flag. PCA pipelines accept the flag only at the outer request, and tuning requests do not accept it.

With the flag enabled, linear and polynomial iterative fits can report `gradientNorm`, `weightNorm` and `convergence`; OLS reports `rank` and `conditionNumber`. Logistic fits can report `parameterChange` and `convergence`, and K-means can report `centroidShift`. Tree K-neighbors builds report completed leaf rows and optional index depth/node/leaf counts; brute has no index keys. Naive Bayes progress counts rows processed in ordered chunks. GaussianNB reports zero-variance pairs and, after the first chunk, variance change. Bernoulli and Multinomial scores are prequential: they evaluate eligible rows against earlier chunks, and omit a cumulative mean after a non-finite score while retaining scoredSamples. MLP fits can report fit-subset training accuracy or R², gradient norm and convergence; trees report depth, node/leaf counts and frontier impurity. A key is omitted when unavailable. See [metrics](../specification/public-api/metrics.md) for definitions.

For example, iterative training uses:

```ts
fraction = 0.15 + 0.8 * (completedIterations / maxIterations);
```

Consequently, `completed / total` can differ from `fraction`. **Use `fraction` for the training progress bar** and counts for explanatory text.

Separate `phase` events provide labels such as `queued`, `loading-data`, `initializing`, `training`, `transforming`, and `finalizing`. They contain no percentage. Show an indeterminate indicator while queued.

Progress measures scheduled work, **not elapsed time or an ETA**. Early convergence can make the bar jump to finalization. SVC counts completed one-vs-one solves over observed class pairs, and SVR counts one solve. Opt-in SVM metrics describe the current solve or calibration fold: `solverIterations`, `calibrating`, `supportVectors`, `boundedSupportVectors`, and an optional finite `maxKktViolation`. The final snapshot means termination, which may occur at the iteration limit without convergence. Native fitting polls for cancellation.

See [event definitions](../src/training/types.ts#L650).

**2. Hyperparameter tuning**

`tuning-progress` contains:

```ts
{
  type: 'tuning-progress',
  trialsCompleted: 6,
  totalTrials: 12,
  activeTrials: 2,
  rung: 0,
  bestScore: 0.91 // optional
}
```

It has no `fraction`. Calculate:

```ts
const percent = event.totalTrials > 0 ? (100 * event.trialsCompleted) / event.totalTrials : 0;
```

Label this **“Search evaluations completed”**:

- Random Search counts candidate evaluations.
- Hyperband counts evaluations across resource rungs; a promoted candidate is counted again at its next rung.
- With inner cross-validation, an evaluation completes after all its inner-fold scores are aggregated.
- Failed candidate evaluations also count as completed.
- `totalTrials` is the maximum scheduled count; failures can reduce subsequent promotions.

This ratio does not cover every remaining step, including refitting when applicable and model hydration. Keep the UI busy until the run completes. Individual candidate training-progress streams are not forwarded publicly.

See [tuning event fields](../src/training/types.ts#L650).

**3. Nested cross-validation**

This provides:

- `outer-fold-start`: zero-based `foldIndex` and `foldCount`.
- `inner-progress`: a wrapped `TrainingEvent` in `event.event`.
- `outer-fold-complete`: `foldIndex`, `score`, and running `meanScore`.

For a reliable overall bar, update on `outer-fold-complete`:

```ts
const percent = (100 * (event.foldIndex + 1)) / request.outerFolds;
```

Display the wrapped tuning events separately as progress within the current outer fold. An inner `completed` event completes that search, not the entire nested-CV run.

With `refit: true`, the outer folds are followed by `refit-start`, wrapped inner-search events as `refit-progress`, and `refit-complete` (with the refit's `durationMs`), then `completed`. Treat `refit-progress` like `inner-progress`: it reports the refit search, and an inner `completed` event does not complete the run.

See [nested-CV event types](../src/training/cross-validation.ts#L148).

**4. Fixed-option cross-validation**

`CrossValidationEvent` includes `fold-start`, `fold-progress`, `fold-complete`,
optional `refit-start`, `refit-progress`, `refit-complete`, and one terminal
event. Unread progress is coalesced only within the trailing fold or refit.

```ts
import { ArrayDatasetProvider, crossValidate } from 'web-ml';
import type { CrossValidationEvent } from 'web-ml';

async function observeFolds() {
	const data = new ArrayDatasetProvider(
		6,
		1,
		1,
		new Float64Array([1, 2, 3, 4, 5, 6]),
		new Float64Array([3, 5, 7, 9, 11, 13])
	);
	const run = crossValidate({
		algorithm: 'linear-regression',
		data,
		folds: 3,
		scoring: 'r2',
		options: { solver: 'ols' },
		refit: true
	});
	for await (const event of run.events as AsyncIterable<CrossValidationEvent>) {
		if (event.type === 'fold-complete') console.log(event.foldIndex, event.meanScore);
		if (event.type === 'refit-complete') console.log('Refit ready', event.durationMs);
	}
	console.log((await run.result).meanScore);
}
void observeFolds();
```

A typical training UI consumer looks like this:

```ts
const run = createTrainingClient().train(request);

const observe = (async () => {
	for await (const event of run.events) {
		switch (event.type) {
			case 'phase':
				setStatus(event.phase);
				break;
			case 'progress':
				setStatus(event.phase);
				setProgress(event.fraction * 100);
				break;
			case 'completed':
				setProgress(100);
				setStatus('completed');
				break;
			case 'cancelled':
				setStatus('cancelled');
				break;
			case 'failed':
				setStatus(event.error.message);
				break;
		}
	}
})();

try {
	const { model } = await run.result;
	showModel(model);
} catch (error) {
	showError(error);
} finally {
	await observe;
}
```

Two UI details matter: consume each stream once and distribute updates from that consumer; unread progress updates can be coalesced, and ordinary training updates are throttled to roughly 50 ms. Treat each event as the latest snapshot, rather than expecting every iteration. Also, `fraction === 1` can arrive before hydration finishes—**`completed` or successful `run.result` settlement is the signal that the model is ready**.
