# Instrumentation and Diagnostics

`web-ml` exposes a global `diagnostics` module to help you monitor the health, memory usage, and performance of the library in your browser environment. This is especially useful for live dashboards or when routing errors to your observability stack in locked-down browser tabs.

## Getting Started

Import the module from the root:

```typescript
import { diagnostics } from 'web-ml';
```

## Global Error Handling

When running models in the background (especially with `SharedWorker`), errors might occur outside the context of a single active training job or after the job has already rejected. You can intercept all system errors (from the Orchestrator, Compute Workers, or Main Thread) to forward them to your manual error-tracking sink:

```typescript
const unsubscribe = diagnostics.onError((context) => {
	console.error(`[web-ml ${context.component}] Error:`, context.error.message);
	if (context.jobId) {
		console.error(`Associated with Job: ${context.jobId}`);
	}

	// Push to an export queue for later manual forwarding
	myOfflineQueue.push(context);
});
```

## Live System Status

To power live resource usage widgets, use `subscribeToStatus`. It provides throttled, periodic updates (default 500ms) without overwhelming the worker IPC channel:

```typescript
const unsubscribeStatus = diagnostics.subscribeToStatus(
	(status) => {
		console.log(
			`Active workers: ${status.orchestrator.activeComputeWorkers} / ${status.hardwareConcurrency}`
		);
		console.log(`Queued jobs: ${status.orchestrator.queuedJobs}`);
		console.log(
			`Library memory allocated: ${Math.round(status.memory.managedBufferBytes / 1024 / 1024)} MB`
		);
	},
	{ throttleMs: 1000 }
);
```

### Understanding Memory Metrics

Since accurate browser memory measurements usually require restrictive `Cross-Origin-Opener-Policy` headers, `web-ml` provides two memory tracking techniques in `status.memory`:

1. **`managedBufferBytes`**: This counts the explicit `ArrayBuffer` allocations made by the library's caches and `DatasetProvider`s. Because tensor math uses typed arrays heavily, this number accurately tracks the library's primary payload footprint across all browsers, requiring no special headers.
2. **`jsHeapBytes`**: A heuristic estimate of the overall V8 Javascript VM heap size.
   - **Note for Safari / Firefox**: This uses the non-standard `performance.memory` API, which is only supported in Chromium browsers (Chrome, Edge, Brave). In Safari, Firefox, and other non-Chromium browsers, `jsHeapBytes` will be returned as `undefined`. You should fall back to `managedBufferBytes` for reliable cross-browser metrics.

### Orchestrator Modes

`web-ml` uses `SharedWorker` when available to share compute resources across tabs. The status object will tell you if this was successful:

- `status.orchestrator.isSharedWorker === true`: You are running in a shared cross-tab context.
- `status.orchestrator.isSharedWorker === false`: The library fell back to Dedicated Workers (e.g., in Safari or Android Chrome).
