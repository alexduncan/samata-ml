# Evaluating Models

Once you have a model, you need to know how well it performs on unseen data. A single train/validation split is often misleading due to random chance.

`crossValidate()` evaluates fixed options, while `nestedCrossValidate()` estimates
performance after tuning inside each outer fold.

## Scoring a model on validation data

Pass a separate provider or batch source in `validation` to score a supervised
ordinary run after fitting. The validation rows are not used for fitting.

```ts
import { ArrayDatasetProvider, createTrainingClient } from 'web-ml';

const training = new ArrayDatasetProvider(
	4,
	1,
	1,
	new Float64Array([-2, -1, 1, 2]),
	new Float64Array([0, 0, 1, 1])
);
const heldOut = new ArrayDatasetProvider(
	2,
	1,
	1,
	new Float64Array([-1.5, 1.5]),
	new Float64Array([0, 1])
);
const run = createTrainingClient().train({
	algorithm: 'decision-tree-classifier',
	classLabels: ['negative', 'positive'],
	data: training,
	validation: { data: heldOut, completeMetrics: true }
});
const { model, metrics } = await run.result;
console.log(model, metrics);
```

On a resumed incomplete cached run, supply fresh sources for both partitions.
When validation is omitted, the result has no `metrics` property.

## Metric functions

The exported standalone functions, including `accuracyScore`, `balancedAccuracyScore`, `f1Score` and
`meanSquaredError`, score caller-supplied predictions. Use the model evaluation
helpers below when predictions and probability reports should be extracted from
an already fitted model.

```ts
import { meanSquaredError } from 'web-ml';

console.log(meanSquaredError([1, 2, 3], [1, 2, 4]));
```

## Fixed options and shared diagnostics

Each row is held out once. The returned confusion matrix is row-major, with
true labels as rows and predicted labels as columns. Class labels must match the
encoding of target indices, even if a model reorders its own `classes_`.

```ts
import { ArrayDatasetProvider, createTrainingClient, crossValidate, diagnoseModel } from 'web-ml';
import type { ClassificationDiagnostics } from 'web-ml';

async function evaluateFixedOptions() {
	const labels = ['negative', 'positive'];
	const data = new ArrayDatasetProvider(
		6,
		1,
		1,
		new Float64Array([-3, -2, -1, 1, 2, 3]),
		new Float64Array([0, 0, 0, 1, 1, 1])
	);
	const request = {
		algorithm: 'decision-tree-classifier',
		data,
		folds: 3,
		scoring: 'balanced-accuracy',
		classLabels: labels,
		randomState: 7
	} as const;
	const estimate = await crossValidate(request).result; // no final model
	const withRefit = await crossValidate({ ...request, refit: true }).result;
	console.log(withRefit.refit?.model.predict([[2.5]]));
	const { model } = await createTrainingClient().train({
		algorithm: request.algorithm,
		data,
		classLabels: labels
	}).result;
	const heldOut = new ArrayDatasetProvider(
		2,
		1,
		1,
		new Float64Array([-1.5, 1.5]),
		new Float64Array([0, 1])
	);
	const render = (d: ClassificationDiagnostics) => console.log(d.labels, d.confusionMatrix);
	render(estimate.diagnostics);
	render(await diagnoseModel(model, heldOut, { classLabels: labels }));
}
void evaluateFixedOptions();
```

`refit` fits one final model on all rows. The caller owns it; call `dispose()`
when finished with an SVC or SVR refit. Fixed-option CV accepts the tuning
`ClassificationScoring` and `RegressionScoring` catalogues, with the same task,
probability and target-domain rules. Balanced accuracy is macro recall on the
class axis, counting a declared class with no truth rows as zero. It does
not tune thresholds or hyperparameters. `includeMetrics` adds averaged per-fold
metrics; SVC requires `probability: true` and regression RMSLE requires
non-negative targets. Multi-label and multi-output data are not supported.

## Partitioned classifier evaluation

Use `evaluation` to request outputs, reports, resubstitution reports, and same-split baselines independently. Without it, existing result shapes and metrics are unchanged. A holdout fits once; fixed CV holds out each row once, and nested CV evaluates only the selected outer winners. Training reports score the rows used by each fit and can be compared with its held-out report. They are not pooled because CV training complements overlap.

```ts
import { ArrayDatasetProvider, crossValidate, holdoutValidate, rocCurve } from 'web-ml';

const data = new ArrayDatasetProvider(
	12,
	1,
	1,
	new Float64Array([-6, -5, -4, -3, -2, -1, 1, 2, 3, 4, 5, 6]),
	new Float64Array([0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1])
);
const evaluation = {
	outputs: true,
	reports: true,
	trainingReports: true,
	baselines: ['most-frequent', 'stratified'],
	positiveLabel: 'positive'
} as const;
const holdout = await holdoutValidate({
	algorithm: 'decision-tree-classifier',
	data,
	testRatio: 0.25,
	classLabels: ['negative', 'positive'],
	randomState: 7,
	evaluation
}).result;
console.log(holdout.trainIndices, holdout.validationIndices);
console.log(holdout.evaluation?.trainingReports?.[0], holdout.evaluation?.reports?.pooled);
console.log(holdout.evaluation?.baselines);

const cv = await crossValidate({
	algorithm: 'decision-tree-classifier',
	data,
	folds: 3,
	scoring: 'accuracy',
	classLabels: ['negative', 'positive'],
	randomState: 7,
	evaluation
}).result;
const details = cv.evaluation!;
const rows = details.outputs!;
console.log(rows.sourceRowIndex, rows.partitionIndex, details.reports?.pooled);
if (rows.positiveScores && details.positiveLabel !== null) {
	const truth = Array.from(rows.trueIndex, (index) => details.classLabels[index]!);
	const curve = rocCurve(truth, rows.positiveScores, { positiveLabel: details.positiveLabel });
	console.log(curve);
}
if (rows.probabilities === null) console.log('Probabilities were not available for every fold.');
// Buffers are owned: transferring one does not detach the request or sibling arrays.
const transferred = structuredClone(rows.sourceRowIndex, {
	transfer: [rows.sourceRowIndex.buffer as ArrayBuffer]
});
void transferred;
```

Rows are sorted by original source index. Truth and predictions are indices into `classLabels`; probabilities, when present for every partition, are row-major with one column per label. A binary score uses an oriented SVC decision margin or the positive probability column; uncalibrated SVC has no probabilities. Curves can be calculated from the returned rows without another fit. Pooled scores come from different models and may have different calibration scales. Output buffers are independently owned and may be transferred, but retaining probabilities costs O(rows × classes) storage. Reports use dense class-by-class matrices, limited to 4096 classes.

## Comparing two cross-validated models

Run `crossValidate` twice with the same `folds`, `randomState` and `classLabels`, so both runs score the
same partitions, then compare the per-partition scores. `bayesianCorrelatedTTest` returns the posterior
probability that A's expected score is lower than B's by more than `rope`, within `rope`, or higher;
`correctedResampledTTest` returns a corrected t statistic and p-value. Both correct for the overlap between
training sets. `rope` is in score units and `testFraction` is the share of rows in each test set; neither
has a default.

Results are stated on `A - B`. For `accuracy`, `f1` and `r2`, `probabilityHigher` means A is better. For
`mean-squared-error`, `probabilityLower` means A has the lower error. Swap the arguments to state the
result from B's side.

```ts
import { ArrayDatasetProvider, bayesianCorrelatedTTest, crossValidate } from 'web-ml';

async function compareModels() {
	const data = new ArrayDatasetProvider(
		12,
		1,
		1,
		new Float64Array([-6, -5, -4, -3, -2, -1, 1, 2, 3, 4, 5, 6]),
		new Float64Array([0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1])
	);
	const shared = {
		data,
		folds: 3,
		scoring: 'accuracy',
		classLabels: ['negative', 'positive'],
		randomState: 7
	} as const;
	const a = await crossValidate({ ...shared, algorithm: 'decision-tree-classifier' }).result;
	const b = await crossValidate({ ...shared, algorithm: 'logistic-regression' }).result;

	const scoresA = a.folds.map((fold) => fold.score);
	const scoresB = b.folds.map((fold) => fold.score);
	const rows = a.folds.map((fold) => fold.validationSampleCount);
	const testFraction = rows.reduce((sum, count) => sum + count, 0) / rows.length / 12;

	const comparison = bayesianCorrelatedTTest(scoresA, scoresB, { rope: 0.01, testFraction });
	console.log(
		comparison.probabilityLower,
		comparison.probabilityEquivalent,
		comparison.probabilityHigher
	);
}
void compareModels();
```

For repeated cross-validation, run each model again with a different `randomState` (and the same `folds`)
and concatenate the per-partition scores of the repeats in the same order for both models; `testFraction`
stays `1 / folds`. `crossValidate` has no built-in repetition. See
[Cross-validated model comparison](../specification/public-api/model-comparison.md) for the equations, edge
cases and numerical accuracy.

## What is Nested Cross-Validation?

Nested cross-validation separates the data used to _choose_ the best hyperparameters from the data used to _evaluate_ the final model.

It splits the entire dataset into a set of **Outer Folds**. For each outer fold:

1. One piece of data is held back purely for final evaluation.
2. The rest of the data is split into **Inner Folds**.
3. A hyperparameter tuning search (like Random Search) is run across these inner folds to find the best configuration.
4. The winning configuration is refit on all the data _except_ the final evaluation piece.
5. The refitted model is scored against the evaluation piece.

The result is a highly reliable average score and standard deviation across all outer folds.

## Running an Evaluation

`nestedCrossValidate()` takes your data, orchestrates the tuning and splitting for you, and streams progress back as it works.

```typescript
import { ArrayDatasetProvider, nestedCrossValidate } from 'web-ml';

async function evaluateModel() {
	const features = Float64Array.from({ length: 100 }, (_, i) => i / 100);
	const targets = Float64Array.from({ length: 100 }, (_, i) => i % 2);
	const dataProvider = new ArrayDatasetProvider(100, 1, 1, features, targets);

	const run = nestedCrossValidate({
		algorithm: 'logistic-regression',
		// Provide your dataset via a provider
		data: dataProvider,

		// Configure the folds
		outerFolds: 5, // Split data into 5 evaluation chunks
		innerFolds: 3, // Tune hyperparameters using 3 chunks

		classLabels: ['negative', 'positive'],
		baseOptions: { solver: 'sgd' },

		// Configure the inner hyperparameter search
		searchSpace: {
			learningRate: { kind: 'log-uniform', min: 0.001, max: 0.1 }
		},
		scoring: 'f1',
		thresholdTuning: { positiveLabel: 'positive' },
		strategy: { kind: 'random-search', nTrials: 16, randomState: 7 },

		// Ensures repeatable splits
		randomState: 12,

		// Automatically computes detailed metrics for each outer fold
		includeMetrics: true
	});

	// Track progress as each outer fold completes
	for await (const event of run.events) {
		if (event.type === 'outer-fold-complete') {
			console.log(`Fold ${event.foldIndex} Score:`, event.score);
		}
	}

	// Get the final robust estimate
	const estimate = await run.result;
	console.log(`Estimated F1: ${estimate.meanScore} ± ${estimate.standardDeviation}`);
	console.log('Pooled metrics:', estimate.metrics);
}

await evaluateModel();
```

## Nested trial histories and refit

Two opt-in fields extend `nestedCrossValidate`. `includeTrials: true` keeps each outer fold's inner search
history on the fold result (`trials`, with `foldScores`, and `bestTrialId`), which shows how stable the
selected parameters and inner scores are. It stores `outerFolds x trials x innerFolds` doubles. `refit: true`
runs the same inner search over all rows after the outer folds and returns the winner fitted on every row as
`result.refit`, emitting `refit-start`, `refit-progress` and `refit-complete` before `completed`. Outer
results are identical with and without it. You own `refit.model`; dispose SVC and SVR models when finished.

```ts
import { ArrayDatasetProvider, nestedCrossValidate } from 'web-ml';

async function nestedWithRefit() {
	const features = Float64Array.from({ length: 40 }, (_, i) => (i % 2 ? 1 : -1) + i / 100);
	const targets = Float64Array.from({ length: 40 }, (_, i) => i % 2);
	const run = nestedCrossValidate({
		algorithm: 'support-vector-classifier',
		data: new ArrayDatasetProvider(40, 1, 1, features, targets),
		outerFolds: 3,
		innerFolds: 2,
		classLabels: ['negative', 'positive'],
		baseOptions: { kernel: 'linear' },
		searchSpace: { C: { kind: 'categorical', values: [0.5, 1, 2] } },
		scoring: 'accuracy',
		strategy: { kind: 'random-search', nTrials: 3, randomState: 5 },
		includeTrials: true,
		refit: true
	});
	for await (const event of run.events)
		if (event.type === 'refit-complete') console.log('refit took', event.durationMs);
	const result = await run.result;
	for (const fold of result.folds) {
		const winner = fold.trials?.find((trial) => trial.trialId === fold.bestTrialId);
		console.log(fold.foldIndex, winner?.params, winner?.foldScores);
	}
	const refit = result.refit;
	if (refit) {
		console.log(refit.model.predict([[0.5]]), refit.bestParams, refit.sampleCount);
		refit.model.dispose(); // SVC models are native: the caller owns and disposes them
	}
}

void nestedWithRefit();
```

## Inspecting fitted fold models

Pass `onModel` in the run options of `crossValidate`, `nestedCrossValidate` or `holdoutValidate` to receive
every model the library fits (each fold, and the refit when requested; for nested CV the outer winners, never
models inside the inner searches; for a holdout, the single training-partition fit with `context.kind ===
'holdout'`). The library awaits the hook before disposing the model or returning the refit or holdout fit, so you
can read fold-level model internals on the exact partitions without keeping models alive. The context
carries ascending `trainingIndices` and `validationIndices`; with `preprocessing` it also carries
`featureNamesOut`, `outputColumns` and the transformed `trainingFeatures` and `validationFeatures` as owned `float64`
`NumericTensor` values that you can pass straight to `predict`. The model and the tensors are valid only
until the hook settles (copy what you need; do not dispose the tensors yourself). A hook that throws or
rejects fails the run with a `TrainingError` of code `callback-failed` and the original error as `cause`.
Aborting while a hook is pending cancels the run without waiting for it. Fold `durationMs` excludes hook time.

```ts
import { ArrayDatasetProvider, crossValidate, encodeTabularFeatures } from 'web-ml';

async function collectCoefficients() {
	const rows = Array.from({ length: 24 }, (_, row) => [row * 1.5, row % 2 === 0 ? 'a' : 'b']);
	const labels = Float64Array.from({ length: 24 }, (_, row) => (row >> 1) % 2);
	const packed = encodeTabularFeatures(rows, [
		{ name: 'x', kind: 'numeric' },
		{ name: 'group', kind: 'categorical' }
	]);
	const perFold: Array<{
		names: readonly string[];
		coefficients: Float64Array;
		predicted: unknown[];
	}> = [];
	await crossValidate(
		{
			algorithm: 'logistic-regression',
			data: new ArrayDatasetProvider(24, 2, 1, Float64Array.from(packed.features), labels),
			folds: 3,
			scoring: 'accuracy',
			options: { solver: 'sgd', maxIter: 30 },
			preprocessing: { columns: packed.columns }
		},
		{
			onModel: (model, context) => {
				const preprocessing = context.preprocessing;
				if (context.kind !== 'fold' || !preprocessing?.validationFeatures || !model.coef_)
					return;
				perFold.push({
					names: preprocessing.featureNamesOut,
					coefficients: Float64Array.from(model.coef_.data, Number),
					predicted: model.predict(preprocessing.validationFeatures)
				});
			}
		}
	).result;
	console.log(perFold);
}

void collectCoefficients();
```

`holdoutValidate` calls the hook once, after the held-out rows are scored and before `fold-complete`:

```ts
import { ArrayDatasetProvider, holdoutValidate } from 'web-ml';

async function inspectHoldoutFit() {
	const data = new ArrayDatasetProvider(
		8,
		1,
		1,
		Float64Array.from([0, 1, 2, 3, 4, 5, 6, 7]),
		Float64Array.from([0, 0, 0, 0, 1, 1, 1, 1])
	);
	await holdoutValidate(
		{ algorithm: 'decision-tree-classifier', data, testRatio: 0.5, randomState: 3 },
		{
			onModel: (model, context) => {
				if (context.kind !== 'holdout') return;
				const rows = Array.from(context.validationIndices, (row) => [row]);
				console.log(context.trainingIndices, model.predict(rows));
			}
		}
	).result;
}

void inspectHoldoutFit();
```

## Keeping the evaluated holdout fit

The hook only lends you the model. To keep the exact fit that produced a holdout's evaluation, set
`returnFit: true` in the request. A successful run then returns `result.fit`: the fitted `model`, the
`preprocessor`, `featureNamesOut` and `outputColumns` when you use `preprocessing`, `sampleCount` and a fit-only `durationMs`
(the training request through hydration, so it excludes scoring, evaluation and any hook). The fit is the
training-partition fit that was evaluated, not a refit on all rows, and its preprocessor learned only from the
training rows. You own the returned model: dispose SVC models when you are finished. A failed or cancelled run
returns nothing and disposes its model itself.

Persist the model with `toJSON()` (a structured-cloneable object, for example for IndexedDB) and the
preprocessor with its JSON-safe `toJSON()`, then restore them with the concrete class's `fromJSON` and
`FittedTabularPreprocessor.fromJSON`. Typed-array model state is not JSON text; see
[current limitations](../specification/public-api/current-limitations.md).

```ts
import {
	ArrayDatasetProvider,
	FittedTabularPreprocessor,
	LogisticRegression,
	encodeTabularFeatures,
	holdoutValidate
} from 'web-ml';

async function keepHoldoutFit() {
	const rows = Array.from({ length: 24 }, (_, row) => [row * 1.5, row % 2 === 0 ? 'a' : 'b']);
	const labels = Float64Array.from({ length: 24 }, (_, row) => (row >> 1) % 2);
	const packed = encodeTabularFeatures(rows, [
		{ name: 'x', kind: 'numeric' },
		{ name: 'group', kind: 'categorical' }
	]);
	const result = await holdoutValidate({
		algorithm: 'logistic-regression',
		data: new ArrayDatasetProvider(24, 2, 1, Float64Array.from(packed.features), labels),
		testRatio: 0.25,
		randomState: 7,
		options: { solver: 'sgd', maxIter: 30 },
		preprocessing: { columns: packed.columns },
		evaluation: { outputs: true },
		returnFit: true
	}).result;
	const fit = result.fit;
	if (!fit?.preprocessor) return;

	// Store these two values, then restore them in a later session.
	const storedModel = structuredClone(fit.model.toJSON());
	const storedPreprocessor = fit.preprocessor.toJSON();
	const model = LogisticRegression.fromJSON(storedModel);
	const preprocessor = FittedTabularPreprocessor.fromJSON(storedPreprocessor);

	// Raw held-out rows go through the restored transformer, exactly as during evaluation.
	const heldOut = Array.from(result.validationIndices, (row) => rows[row]!);
	console.log(model.predict(preprocessor.transform(heldOut)));
	console.log(result.evaluation?.outputs?.predictedIndex, fit.durationMs);
	// Logistic regression owns no native memory. Call dispose() on SVC fits and restored SVC models.
}

void keepHoldoutFit();
```

## Cross-validation with tabular preprocessing

Both cross-validation APIs accept the top-level `preprocessing` option. Each outer fold learns its own
transformer from its training complement and applies it to its held-out rows, so folds can have different
feature axes and every fold reports its own `featureNamesOut` and `outputColumns`. Fixed CV's optional `refit` returns a
fresh transformer for the full data. Nested CV scores each outer holdout with the winning candidate's
transformer, then disposes the model; the mapping stays on the fold result. Adjusted R² counts the columns
each fit actually delivered to the estimator, so folds with different widths pool to
`not-applicable`.

```typescript
import {
	ArrayDatasetProvider,
	crossValidate,
	encodeTabularFeatures,
	nestedCrossValidate
} from 'web-ml';

const rows = Array.from({ length: 24 }, (_, row) => [
	row * 1.5,
	row === 7 ? 'rare' : row % 2 === 0 ? 'a' : 'b'
]);
const labels = Float64Array.from({ length: 24 }, (_, row) => (row >> 1) % 2);
const packed = encodeTabularFeatures(rows, [
	{ name: 'x', kind: 'numeric' },
	{ name: 'group', kind: 'categorical' }
]);
const provider = () =>
	new ArrayDatasetProvider(
		24,
		2,
		1,
		Float64Array.from(packed.features),
		Float64Array.from(labels)
	);

const fixed = await crossValidate({
	algorithm: 'logistic-regression',
	data: provider(),
	folds: 3,
	scoring: 'accuracy',
	options: { solver: 'sgd', maxIter: 30 },
	refit: true,
	preprocessing: { columns: packed.columns }
}).result;
for (const fold of fixed.folds)
	console.info(fold.foldIndex, fold.featureNamesOut, fold.validationIndices);
const rawRowScore = fixed.refit?.preprocessor?.transform([[10, 'a']]);

const nested = await nestedCrossValidate({
	algorithm: 'logistic-regression',
	data: provider(),
	outerFolds: 3,
	innerFolds: 2,
	searchSpace: { learningRate: { kind: 'categorical', values: [0.05] } },
	baseOptions: { solver: 'sgd', maxIter: 30 },
	scoring: 'accuracy',
	strategy: { kind: 'random-search', nTrials: 1 },
	preprocessing: { columns: packed.columns }
}).result;
const outerAxes = nested.folds.map((fold) => fold.featureNamesOut);
void [rawRowScore, outerAxes];
```

## Diagnosing a dataset before training

`diagnoseDataset` loads the dataset under the training lock, fits any supplied
preprocessing on all rows and returns structured findings. Each later training
partition fits its own preprocessing, so its encoded width may differ.

```ts
import { ArrayDatasetProvider, diagnoseDataset, encodeTabularFeatures } from 'web-ml';

const rows = [
	[1, 'a'],
	[2, 'b'],
	[null, 'a'],
	[4, 'b'],
	[5, 'a'],
	[6, 'b']
];
const encoded = encodeTabularFeatures(rows, [
	{ name: 'value', kind: 'numeric' },
	{ name: 'group', kind: 'categorical' }
]);
const data = new ArrayDatasetProvider(
	6,
	2,
	1,
	encoded.features,
	new Float64Array([0, 1, 0, 1, 0, 1])
);
const report = await diagnoseDataset({
	data,
	preprocessing: { columns: encoded.columns },
	model: { algorithm: 'logistic-regression' },
	partition: { kind: 'k-fold', folds: 2 },
	thresholds: { highMissingRate: 0.1 }
});
for (const finding of report.findings) {
	if (finding.code === 'high-missing-rate' && finding.severity === 'warning')
		console.log('Review missing values in columns', finding.columns);
}
```

See [dataset diagnostics](../specification/public-api/dataset-diagnostics.md) for
the complete definitions, thresholds and browser requirements.

## Checking stratified partition feasibility

`checkStratifiedPartition` takes per-class row counts (`classCounts[c]` is the number of rows of encoded
class `c`) and one stratified request: `k-fold` for `crossValidate`, `nested` for `nestedCrossValidate`
or `holdout` for `stratifiedTrainTestSplit`. It is synchronous and pure, runs in O(C log N) time for C
classes and N rows, and never reads a seed, so a form can call it on every edit. The verdict carries a
stable issue code, the field to correct and the limits the counts allow. See
[Stratified partition feasibility](../specification/public-api/stratified-partitions.md) for every rule.

```ts
import { checkStratifiedPartition } from 'web-ml';

const classCounts = [40, 25, 9];

// Cap a fold selector with the exact maximum.
const folds = checkStratifiedPartition(classCounts, { kind: 'k-fold', folds: 5 });
const maxFolds = folds.limits.kind === 'k-fold' ? folds.limits.maxFolds : null; // 9

// Report the first problem by code, not by message text.
const tooMany = checkStratifiedPartition(classCounts, { kind: 'k-fold', folds: 12 });
if (!tooMany.feasible && tooMany.issue.code === 'class-smaller-than-folds') {
	const { classIndex, parameter } = tooMany.issue; // 2, 'folds'
	void [classIndex, parameter];
}

// A holdout needs every observed class to keep a row on both sides.
const holdout = checkStratifiedPartition(classCounts, { kind: 'holdout', testRatio: 0.2 });
void [maxFolds, holdout.feasible];
```

A feasible verdict only covers partition capacity. Label, seed, option and estimator rules (such as the
two observed classes Naive Bayes and SVC need in a training partition) still apply.

## Supported Models and Selection

Nested cross-validation supports the supervised estimators available in the tuner,
including multi-label LogisticRegression. Its indicator columns follow
`classLabels`; seeded iterative stratification checks that every fold and its
training complement contain positives and negatives for each label.

During the inner folds, candidate models are selected using a supported
classification or regression scorer. Add
`thresholdTuning: { positiveLabel: 'positive' }` to select a binary probability
cutoff from pooled inner out-of-fold predictions. Each selected cutoff is
evaluated only on its untouched outer fold. The result reports the cutoff and
positive label alongside each fold's score. Threshold tuning supports
single-label binary classifiers; SVC requires `probability: true`. Multiclass,
multi-label LogisticRegression, unsupervised algorithms, and custom scoring
callbacks are not supported.

The option has the same name and shape in `createTrainingClient().train(...)`
hyperparameter-tuning requests and `createTuner().search(...)`. See the
[training guide](./training.md) and [tuning guide](./tuning.md) for those forms.

## Detailed Metrics

Set `includeMetrics: true` for a fitted-model report on every outer fold and a
pooled report built from all out-of-fold predictions in source-row order. Set
`completeMetrics: true` to compute the more expensive ranking and median-error
fields. Values that cannot be computed carry an availability reason. Pooled
ranking compares scores produced by different fold models, whose scales may
differ. Fixed-option CV continues to return its separate mean-of-fold summaries.
The [nested evaluation example](#running-an-evaluation) runs this report and
prints the pooled result.

## Evaluate a fitted model

Use `evaluateClassifier(model, features, targets, options?)` or
`evaluateRegressor(model, features, targets, options?)` to evaluate held-out
rows synchronously. These helpers also accept a matching PCA pipeline and leave
the fitted model in the caller's ownership. Classifier targets are decoded labels;
for multi-label LogisticRegression use a flat row-major `Uint8Array` in the
fitted class order. Regressor targets may be a vector or matrix. Set
`completeMetrics: true` for ranking metrics or median absolute error.

Probability and ranking fields carry an availability reason when a score cannot
be computed. Binary SVC ranking uses an oriented decision margin even without
probability calibration; loss and Brier scores require `probability: true`.

```ts
import { ArrayDatasetProvider, createTrainingClient, evaluateClassifier } from 'web-ml';

const data = new ArrayDatasetProvider(
	4,
	1,
	1,
	new Float64Array([-2, -1, 1, 2]),
	new Float64Array([0, 0, 1, 1])
);
const { model } = await createTrainingClient().train({
	algorithm: 'decision-tree-classifier',
	classLabels: ['negative', 'positive'],
	data
}).result;
console.log(evaluateClassifier(model, [[-1.5], [1.5]], ['negative', 'positive']));
```
