# Support Vector Regressor

**Algorithm ID:** `support-vector-regressor`

Support Vector Regressor (SVR) applies the principles of Support Vector Machines to regression problems. Specifically, `web-ml` uses LIBSVM's epsilon-Support Vector Regression implementation, which finds a function that deviates from the true targets by at most epsilon, while remaining as flat as possible.

Set `liveMetrics: true` on the training request for solver iteration, support counts and an available finite active-set KKT gap. Progress counts the one binary solve. A final snapshot indicates termination, which need not mean convergence. Cancellation is polled inside the native worker.

## When to Use It

- **Continuous Prediction**: Predicting a continuous numeric value (e.g., housing prices, temperature forecasting).
- **Non-linear Regression**: Capturing complex, non-linear relationships between features and targets using kernels.
- **Robust Regression**: The epsilon-insensitive loss function makes SVR robust to outliers within the epsilon tube.

## Quick Example

```typescript
import { ArrayDatasetProvider, createTrainingClient } from 'web-ml';

const client = createTrainingClient();
const myDatasetProvider = new ArrayDatasetProvider(
	8,
	1,
	1,
	new Float64Array([0, 1, 2, 3, 4, 0, 1, 2]),
	new Float64Array([0, 0, 0, 0, 1, 1, 1, 1])
);

const run = client.train({
	algorithm: 'support-vector-regressor',
	options: {
		kernel: 'rbf',
		C: 1.0,
		epsilon: 0.1
	},
	data: myDatasetProvider
});

const { model } = await run.result;

// Predict a continuous value
const predictions = model.predict([[2.5], [4.5]]);
```

## Hyperparameters

You can configure the model's behavior by passing these properties into the `options` object.

| Option    | Default   | Description                                                                                                  |
| :-------- | :-------- | :----------------------------------------------------------------------------------------------------------- |
| `C`       | `1.0`     | Regularization parameter C. Must be strictly positive. A smaller value specifies stronger regularization.    |
| `epsilon` | `0.1`     | Epsilon-tube width for epsilon-SVR. Specifies the margin of tolerance where no penalty is given to errors.   |
| `kernel`  | `'rbf'`   | Kernel type to be used in the algorithm. Options: `'linear'`, `'poly'`, `'rbf'`, or `'sigmoid'`.             |
| `degree`  | `3`       | Degree of the polynomial kernel function (`'poly'`). Ignored by other kernels.                               |
| `gamma`   | `'scale'` | Kernel coefficient for `'rbf'`, `'poly'`, and `'sigmoid'`. Can be `'scale'`, `'auto'`, or a specific number. |
| `coef0`   | `0.0`     | Independent term in the polynomial (`'poly'`) and sigmoid (`'sigmoid'`) kernels.                             |
| `tol`     | `1e-3`    | LIBSVM stopping tolerance.                                                                                   |
