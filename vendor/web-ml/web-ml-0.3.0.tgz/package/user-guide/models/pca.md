# Principal Component Analysis (PCA)

**Algorithm ID:** `pca`

Principal Component Analysis (PCA) is a foundational linear dimensionality reduction technique. It computes the principal components of a dataset and uses them to perform a change of basis, projecting the data into a lower-dimensional space while attempting to preserve as much variance as possible.

Under the hood, `web-ml` computes the exact PCA via eigenvalue decomposition of the covariance matrix.

## When to Use It

- **Dimensionality Reduction**: Reducing the number of features in a dataset to speed up subsequent training or reduce memory footprint, while retaining most of the important variance.
- **Data Visualization**: Projecting high-dimensional data down to 2 or 3 principal components for exploratory visual analysis.
- **Feature Extraction**: Creating a set of uncorrelated features (the principal components) from an original set of potentially correlated variables, which can improve the performance of downstream algorithms like regression or classification.

## Quick Example

```typescript
import { ArrayDatasetProvider, createTrainingClient } from 'web-ml';

const client = createTrainingClient();
const myDatasetProvider = new ArrayDatasetProvider(
	8,
	2,
	0,
	new Float64Array([0, 2, 1, 3, 2, 4, 3, 0, 4, 1, 0, 2, 1, 3, 2, 4])
);

const run = client.train({
	algorithm: 'pca',
	options: {
		nComponents: 2,
		center: true,
		scale: true
	},
	data: myDatasetProvider
});

const { model: result } = await run.result;

// The transformed data projected onto the selected principal components
console.log(result.transformed);

// You can also inspect the explained variance ratio of the components
console.log(result.explained_variance_ratio_);
```

## Hyperparameters

You can configure the PCA algorithm's behavior by passing these properties into the `options` object.

| Option        | Default | Description                                                                                                                                                               |
| :------------ | :------ | :------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| `nComponents` | (none)  | Number of principal components to keep. Must be a positive integer. If omitted, it defaults to keeping all components (the minimum of the number of samples or features). |
| `center`      | `true`  | Whether to centre each feature (subtract the mean) before PCA. Centering is required if `scale` is true.                                                                  |
| `scale`       | `false` | Whether to scale each feature to unit variance before PCA. If you want standard scaling (similar to StandardScaler followed by PCA) behavior, set this to `true`.         |

> **Note:** When using `scale: true`, you must also ensure `center: true` (which is the default), otherwise the algorithm will throw an error as PCA scaling strictly requires centering.

## PCA Pipeline

In many machine learning workflows, you may want to apply PCA to reduce dimensionality before passing the features to a classifier or regressor. `web-ml` provides a built-in `pca-pipeline` algorithm that performs both steps securely within the same high-performance worker process, avoiding the need to transfer large intermediate datasets back to the main thread.

The pipeline supports all supervised algorithms in `web-ml` **except** for Multinomial Naive Bayes (as PCA can output negative values, which MultinomialNB does not support). It works identically across `createTrainingClient`, `createTuner`, and `nestedCrossValidate`.

### Pipeline Example

To train a pipeline, specify the algorithm as `'pca-pipeline'`, provide your PCA configuration under `pcaOptions`, and define your downstream model under the `estimator` (or `pipelineEstimator` for `createTuner`) property.

```typescript
import { ArrayDatasetProvider, createTrainingClient } from 'web-ml';

const client = createTrainingClient();
const myDatasetProvider = new ArrayDatasetProvider(
	8,
	4,
	1,
	new Float64Array([
		0, 1, 2, 3, 1, 2, 3, 4, 2, 3, 1, 0, 3, 4, 2, 1, 4, 3, 2, 1, 5, 4, 3, 2, 6, 2, 3, 4, 7, 3, 4,
		5
	]),
	new Float64Array([0, 0, 0, 0, 1, 1, 1, 1])
);

const run = client.train({
	algorithm: 'pca-pipeline',
	pcaOptions: {
		nComponents: 2,
		center: true,
		scale: true
	},
	estimator: {
		algorithm: 'logistic-regression',
		options: {
			penalty: 'l2',
			C: 1.0
		},
		classLabels: ['negative', 'positive']
	},
	data: myDatasetProvider
});

// The model is a unified PCAPipeline object
const { model: pipeline } = await run.result;

// The pipeline automatically transforms inputs via PCA before predicting
const predictions = pipeline.predict([[0.5, 1.2, -0.3, 2.1]]);
const probabilities = pipeline.predictProba([[0.5, 1.2, -0.3, 2.1]]);
```
