# Support Vector Classifier

**Algorithm ID:** `support-vector-classifier`

Support Vector Classifier (SVC) is a powerful classification algorithm that finds the optimal separating hyperplane maximizing the margin between classes. Under the hood, `web-ml` uses LIBSVM's C-SVC implementation via a high-performance WebAssembly module.

Set `liveMetrics: true` on the training request to see solver iteration, current-pair support counts, calibration status, and an available finite active-set KKT gap. Progress counts finished class pairs; calibration folds do not increment the count. A final snapshot indicates termination, which need not mean convergence. Cancellation is polled inside the native worker.

## When to Use It

- **Binary Classification**: Predicting between two classes (e.g., classifying a transaction as fraudulent or legitimate).
- **Multiclass Classification**: Predicting one outcome from many mutually exclusive classes. LIBSVM handles this internally using a "One-vs-One" strategy.
- **Non-linear Classification**: Leveraging kernel functions (like RBF or polynomial) to classify data that is not linearly separable.

## Quick Example

```typescript
import { ArrayDatasetProvider, createTrainingClient } from 'web-ml';

const client = createTrainingClient();
const myDatasetProvider = new ArrayDatasetProvider(
	8,
	2,
	1,
	new Float64Array([0, 2, 1, 3, 2, 4, 3, 0, 4, 1, 0, 2, 1, 3, 2, 4]),
	new Float64Array([0, 0, 0, 0, 1, 1, 1, 1])
);

const run = client.train({
	algorithm: 'support-vector-classifier',
	classLabels: ['negative', 'positive'],
	options: {
		kernel: 'rbf',
		C: 1.0,
		probability: true
	},
	data: myDatasetProvider
});

const { model } = await run.result;

// Predict the most likely class label
const prediction = model.predict([[0.5, -1.2]]);

// Predict probabilities for each class (requires probability: true)
const probabilities = model.predictProba([[0.5, -1.2]]);
```

## Class weights

`classWeight` accepts `'balanced'`, `null`, or a record from label to weight. Keys are matched to the
**declared** `classLabels` through `String(label)`, so a weight may name a declared class that the
fitting rows happen not to contain. Each weight must be a positive finite number, an unlisted class
keeps weight `1`, and the record must be a plain or null-prototype object.

```typescript
import { ArrayDatasetProvider, createTrainingClient } from 'web-ml';

const client = createTrainingClient();
const run = client.train({
	algorithm: 'support-vector-classifier',
	classLabels: ['ham', 'spam', 'unlabelled'],
	options: { kernel: 'linear', classWeight: { spam: 4, unlabelled: 1 } },
	data: new ArrayDatasetProvider(
		8,
		2,
		1,
		new Float64Array([0, 0, 0, 1, 1, 0, 1, 1, 4, 4, 4, 5, 5, 4, 5, 5]),
		new Float64Array([0, 0, 0, 0, 1, 1, 1, 1])
	)
});

const { model } = await run.result;
model.predict([[0.5, 0.5]]);
model.dispose();
```

Booleans and numbers work the same way: use the keys `'true'` or `'10'`. A key that matches no declared
label, or two labels, fails with `invalid-request` before data is read.

## Hyperparameters

You can configure the model's behavior by passing these properties into the `options` object.

| Option        | Default   | Description                                                                                                                                                                      |
| :------------ | :-------- | :------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `C`           | `1.0`     | Regularization parameter C. Must be strictly positive. A smaller value specifies stronger regularization.                                                                        |
| `kernel`      | `'rbf'`   | Kernel type to be used in the algorithm. Options: `'linear'`, `'poly'`, `'rbf'`, or `'sigmoid'`.                                                                                 |
| `degree`      | `3`       | Degree of the polynomial kernel function (`'poly'`). Ignored by other kernels.                                                                                                   |
| `gamma`       | `'scale'` | Kernel coefficient for `'rbf'`, `'poly'`, and `'sigmoid'`. Can be `'scale'`, `'auto'`, or a specific number.                                                                     |
| `coef0`       | `0.0`     | Independent term in the polynomial (`'poly'`) and sigmoid (`'sigmoid'`) kernels.                                                                                                 |
| `tol`         | `1e-3`    | LIBSVM stopping tolerance.                                                                                                                                                       |
| `classWeight` | `null`    | Set to `'balanced'` to automatically adjust weights inversely proportional to class frequencies, or provide a record from label to a positive finite weight (see Class weights). |
| `probability` | `false`   | Whether to train probability calibration models (Platt scaling) to enable `predictProba`. Enabling this can increase training time.                                              |

## Tune a binary decision threshold

Threshold tuning needs calibrated probabilities, so set `probability: true` in
`baseOptions` and keep it true for every searched value.

```typescript
import { createTuner } from 'web-ml';

const search = createTuner().search({
	algorithm: 'support-vector-classifier',
	trainingData,
	validationData,
	classLabels: ['negative', 'positive'],
	baseOptions: { probability: true },
	searchSpace: { C: { kind: 'log-uniform', min: 0.1, max: 10 } },
	scoring: 'f1',
	thresholdTuning: { positiveLabel: 'positive' },
	strategy: { kind: 'random-search', nTrials: 12, randomState: 4 }
});
const result = await search.result;
const predictions = result.bestModel.predict([[0.5, -1.2]]);
console.log(result.bestDecisionThreshold, predictions);
```
