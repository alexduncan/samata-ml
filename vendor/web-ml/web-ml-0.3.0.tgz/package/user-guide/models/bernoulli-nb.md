# Bernoulli Naive Bayes

**Algorithm ID:** `bernoulli-nb`

Bernoulli Naive Bayes (BNB) is a classification algorithm for multivariate Bernoulli models. Like Multinomial Naive Bayes, this classifier is suitable for discrete data. The difference is that while MultinomialNB works with occurrence counts, BernoulliNB is designed for binary/boolean features.

Under the hood, `web-ml` fits Bernoulli Naive Bayes by calculating the empirical log probability of features given each class.

## When to Use It

- **Binary/Boolean Features**: Text classification with 'word occurrence' vectors (rather than word count vectors), or any dataset where features are independently distributed booleans.
- **Fast Training**: Naive Bayes models train extremely quickly and are computationally lightweight.
- **Multiclass Classification**: Predicting one outcome from many mutually exclusive classes.

## Quick Example

```typescript
import { ArrayDatasetProvider, createTrainingClient } from 'web-ml';

const client = createTrainingClient();
const myDatasetProvider = new ArrayDatasetProvider(
	8,
	3,
	1,
	new Float64Array([0, 2, 4, 1, 3, 0, 2, 4, 1, 3, 0, 2, 4, 1, 3, 0, 2, 4, 1, 3, 0, 2, 4, 1]),
	new Float64Array([0, 0, 0, 0, 1, 1, 1, 1])
);

const run = client.train({
	algorithm: 'bernoulli-nb',
	classLabels: ['ham', 'spam'],
	options: {
		alpha: 1.0,
		binarize: 0.0
	},
	data: myDatasetProvider
});

const { model } = await run.result;

// Predict the most likely class label
const prediction = model.predict([[1, 0, 0]]);

// Predict probabilities for each class
const probabilities = model.predictProba([[1, 0, 0]]);
```

## Class priors

`classPrior` holds one finite, non-negative number for every **observed** class of the fitting rows.
Position `i` belongs to the `i`th distinct observed label in portable order: booleans (`false`, `true`),
then finite numbers ascending, then strings by UTF-16 code units (case-sensitive). For example `[2, 10]`,
`['B', 'a']` and `[false, true, 2, 10, '10', '2']`. Fitting only the labels `10` and `2` with
`[0.8, 0.2]` therefore gives label `2` the prior `0.8`. Supplied values are used as given: they are not
rescaled to sum to one, so normalised probabilities are the recommended input. Explicit priors override
`fitPrior`. Fitted models keep the class axis they were trained with, so JSON saved before this ordering
was introduced restores unchanged.

```typescript
import { ArrayDatasetProvider, createTrainingClient } from 'web-ml';

const client = createTrainingClient();
const run = client.train({
	algorithm: 'bernoulli-nb',
	classLabels: [10, 2],
	options: { classPrior: [0.8, 0.2] }, // 0.8 belongs to label 2, the first observed label in order
	data: new ArrayDatasetProvider(
		6,
		2,
		1,
		new Float64Array([0, 1, 1, 0, 0, 2, 5, 4, 6, 5, 4, 6]),
		new Float64Array([0, 0, 0, 1, 1, 1])
	)
});

const { model } = await run.result;
model.classes_; // [2, 10]
model.predict([[1, 1]]);
```

Wrong lengths, sparse arrays, non-numbers, negative values and non-finite values fail with
`invalid-request` before the model is fitted, including inside every fold of a search or
cross-validation. Migration: new fits order labels with the portable comparator above, not the browser's locale collation. A string axis such as `['B', 'a']` now puts `'B'` first (locale collation placed `'a'` first), and booleans, numbers and strings can be mixed. Re-check any priors written against the old order when you refit; models that were already fitted keep their stored axis.

## Inspecting the fitted model

`model.classLogPrior_` holds each class's log prior, `model.featureLogProb_` the log probability that each binarised feature is present per class, and `model.predictJointLogProba(X)` the unnormalised joint log-likelihood. `featureContributions(model, X)` splits that score exactly; an absent feature contributes its stored negative log probability. See [Model inspection](../model-inspection.md#feature-contributions).

## Hyperparameters

You can configure the model's behavior by passing these properties into the `options` object.

| Option       | Default | Description                                                                                                                                                                                             |
| :----------- | :------ | :------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| `alpha`      | `1.0`   | Additive (Laplace/Lidstone) smoothing parameter (0 for no smoothing).                                                                                                                                   |
| `forceAlpha` | `true`  | If false and alpha is very close to zero, alpha will be set to 1e-10.                                                                                                                                   |
| `binarize`   | `0.0`   | Threshold for binarizing (mapping to booleans) of sample features. If `null`, input is presumed to already consist of binary vectors.                                                                   |
| `fitPrior`   | `true`  | Whether to learn class prior probabilities or not.                                                                                                                                                      |
| `classPrior` | `null`  | Prior probabilities of the classes. If specified, the priors are not adjusted according to the data. One finite non-negative value for each observed class, in portable label order (see Class priors). |

## Tune a binary decision threshold

For binary classification, the tuner can select a cutoff from BernoulliNB's
validation probabilities.

```typescript
import { createTuner } from 'web-ml';

const search = createTuner().search({
	algorithm: 'bernoulli-nb',
	trainingData,
	validationData,
	classLabels: ['negative', 'positive'],
	searchSpace: { alpha: { kind: 'uniform', min: 0.1, max: 2 } },
	scoring: 'f1',
	thresholdTuning: { positiveLabel: 'positive' },
	strategy: { kind: 'random-search', nTrials: 12, randomState: 4 }
});
const result = await search.result;
const predictions = result.bestModel.predict([[1, 0, 0]]);
console.log(result.bestDecisionThreshold, predictions);
```
