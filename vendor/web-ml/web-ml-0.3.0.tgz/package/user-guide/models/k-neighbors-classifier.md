# K-Neighbors Classifier

**Algorithm ID:** `k-neighbors-classifier`

K-Nearest Neighbors Classifier (KNN) is a non-parametric classification algorithm. It makes predictions by finding the $k$ closest neighbors in the training set and using a majority vote among them to determine the most likely class.

Under the hood, `web-ml` computes distances between samples using the specified distance metric (defaulting to the Minkowski metric), and can assign weights to neighbors either uniformly or inversely proportional to their distance from the query point.

## When to Use It

- **Binary Classification**: Predicting between two outcomes by checking the local neighborhood.
- **Multiclass Classification**: Naturally supports predicting one outcome from many mutually exclusive classes through majority voting.
- **Non-linear Decision Boundaries**: Unlike linear models, KNN can capture highly complex, non-linear relationships without needing explicit feature engineering or transformations.

## Quick Example

```typescript
import { ArrayDatasetProvider, createTrainingClient } from 'web-ml';

const client = createTrainingClient();
const myDatasetProvider = new ArrayDatasetProvider(
	8,
	2,
	1,
	new Float64Array([0, 2, 1, 3, 2, 4, 3, 0, 4, 1, 0, 2, 1, 3, 2, 4]),
	new Float64Array([0, 0, 0, 0, 1, 1, 1, 1])
);

const run = client.train({
	algorithm: 'k-neighbors-classifier',
	classLabels: ['A', 'B'],
	options: {
		nNeighbors: 5,
		weights: 'distance',
		metric: 'minkowski',
		p: 2
	},
	data: myDatasetProvider
});

const { model } = await run.result;

// Predict the most likely class label
const prediction = model.predict([[0.2, 0.3]]);

// Predict probabilities for each class
const probabilities = model.predictProba([[0.2, 0.3]]);
```

## Hyperparameters

You can configure the model's behavior by passing these properties into the `options` object.

| Option       | Default       | Description                                                                                                                                               |
| :----------- | :------------ | :-------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `nNeighbors` | `5`           | Number of neighbors to use by default for nearest neighbor queries. Must be an integer >= 1.                                                              |
| `weights`    | `'uniform'`   | Weight function used in prediction. Options: `'uniform'` (all neighbors weighted equally) or `'distance'` (weights are inverse of distance).              |
| `algorithm`  | `'brute'`     | Exact `brute`, `kd_tree`, or `ball_tree` search.                                                                                                          |
| `leafSize`   | `30`          | Positive integer minimum tree leaf size; ignored by brute.                                                                                                |
| `metric`     | `'minkowski'` | Metric to use for distance computation. Options: `'minkowski'`, `'euclidean'`, or `'manhattan'`.                                                          |
| `p`          | `2`           | Power parameter for the Minkowski metric. When `p = 1`, this is equivalent to Manhattan distance. When `p = 2`, this is equivalent to Euclidean distance. |

Votes retain each label's type and value, so `1` and `'1'` are different
classes. With distance weighting, if any selected neighbors exactly match the
query, only those exact matches receive votes. Probability columns correspond
to `model.classes_` in order. By default, a tie in vote weight selects the
first tied class in that order.

## Tune a binary decision threshold

For binary classification, the tuner selects a cutoff using validation
probabilities. Keep `nNeighbors` within the number of training rows.

```typescript
import { createTuner } from 'web-ml';

const search = createTuner().search({
	algorithm: 'k-neighbors-classifier',
	trainingData,
	validationData,
	classLabels: ['negative', 'positive'],
	searchSpace: { nNeighbors: { kind: 'integer', min: 1, max: 5 } },
	scoring: 'f1',
	thresholdTuning: { positiveLabel: 'positive' },
	strategy: { kind: 'random-search', nTrials: 12, randomState: 4 }
});
const result = await search.result;
const predictions = result.bestModel.predict([[0.2, 0.3]]);
console.log(result.bestDecisionThreshold, predictions);
```

Fresh tree models use worker-certified bounds to prune Euclidean and Manhattan queries. Minkowski, non-finite queries and unusual k values use exhaustive search. JSON and cache restoration validate and copy structure without fitting an index on the page; restored tree-configured models query exhaustively. With n rows, d features and M nodes, packed KD arrays use n + 2Md doubles and Ball arrays use n + 3Md + M, plus retained rows and build scratch.
