# Linear Regression

**Algorithm ID:** `linear-regression`

Linear Regression is a foundational regression algorithm used for predicting continuous values. It models the linear relationship between input features and a continuous target variable by fitting a linear equation to observed data.

LinearRegression defaults to Ordinary Least Squares (`ols`). It also supports
full-batch Stochastic Gradient Descent (`sgd`) and Adam for iterative fitting.

## When to Use It

- **Continuous Prediction**: Predicting numeric values such as house prices, temperature, or sales forecasts.

## Quick Example

```typescript
import { ArrayDatasetProvider, createTrainingClient } from 'web-ml';

const client = createTrainingClient();
const myDatasetProvider = new ArrayDatasetProvider(
	8,
	2,
	1,
	new Float64Array([0, 2, 1, 3, 2, 4, 3, 0, 4, 1, 0, 2, 1, 3, 2, 4]),
	new Float64Array([0, 0, 0, 0, 1, 1, 1, 1])
);

const run = client.train({
	algorithm: 'linear-regression',
	options: {
		solver: 'sgd',
		learningRate: 0.05,
		penalty: 'l2',
		alpha: 0.1
	},
	data: myDatasetProvider
});

const { model } = await run.result;

// Predict continuous values
const prediction = model.predict([[3.5, -1.2]]);
```

## Hyperparameters

You can configure the model's behavior by passing these properties into the `options` object.

| Option         | Default           | Description                                                                                                                            |
| :------------- | :---------------- | :------------------------------------------------------------------------------------------------------------------------------------- |
| `loss`         | `'squared_error'` | Loss function to minimize.                                                                                                             |
| `penalty`      | `'none'`          | Regularization penalty. Options: `'none'`, `'l2'`.                                                                                     |
| `alpha`        | `1.0`             | Regularization strength parameter. Must be non-negative. Ignored if `penalty` is `'none'`.                                             |
| `solver`       | `'ols'`           | Choose `'ols'`, `'sgd'`, or `'adam'`. OLS is the default.                                                                              |
| `learningRate` | `0.01`            | SGD step size. Adam uses the fixed rate `0.001`; OLS ignores this option.                                                              |
| `maxIter`      | `1000`            | Maximum SGD or Adam updates. (Also supports `maxIterations` alias).                                                                    |
| `tol`          | `1e-6`            | SGD/Adam stop when absolute objective change is at most this value; `0` disables early stopping. OLS ignores it. (Alias: `tolerance`.) |
| `fitIntercept` | `true`            | Whether to learn an intercept (bias) for this model.                                                                                   |

Adam uses fixed β₁ `0.9`, β₂ `0.999`, ε `1e-8`, and learning rate `0.001`.
