# Decision Tree Regressor

**Algorithm ID:** `decision-tree-regressor`

Decision Tree Regressor (DTR) is a non-parametric supervised learning algorithm used for regression. It learns simple decision rules inferred from the data features to predict continuous target values. Leaves predict the mean target, except with `absolute_error`, which uses the median.

`categoricalFeatures` selects input indices or unscaled ordinal preprocessing source names
for native code-set splits. Codes must be integers in `[0, 255]`; unseen prediction codes
go right. Mean-target ordering is optimal for squared error and Friedman MSE when
`minSamplesLeaf` is 1; larger minimums and `absolute_error` or `poisson` use it as a heuristic.

The regressor scores splits with squared error, Friedman MSE, absolute error, or
Poisson deviance. Poisson targets must be nonnegative.

## When to Use It

- **Interpretable Models**: When you need a model whose decisions can be easily visualized and understood.
- **Non-linear Relationships**: When the target variable has a non-linear relationship with the features.
- **Handling Mixed Data Types**: Decision trees handle features without requiring standardization or normalization.

## Quick Example

```typescript
import { ArrayDatasetProvider, createTrainingClient } from 'web-ml';

const client = createTrainingClient();
const myDatasetProvider = new ArrayDatasetProvider(
	8,
	2,
	1,
	new Float64Array([0, 2, 1, 3, 2, 4, 3, 0, 4, 1, 0, 2, 1, 3, 2, 4]),
	new Float64Array([0, 0, 0, 0, 1, 1, 1, 1])
);

const run = client.train({
	algorithm: 'decision-tree-regressor',
	options: {
		criterion: 'squared_error',
		maxDepth: 5,
		minSamplesLeaf: 2
	},
	data: myDatasetProvider
});

const { model } = await run.result;

// Predict the continuous target value
const prediction = model.predict([[2.5, 3.1]]);
```

## Hyperparameters

You can configure the model's behavior by passing these properties into the `options` object.

| Option                | Default           | Description                                                                                                                  |
| :-------------------- | :---------------- | :--------------------------------------------------------------------------------------------------------------------------- |
| `criterion`           | `'squared_error'` | Split criterion: `'squared_error'`, `'friedman_mse'`, `'absolute_error'`, or `'poisson'`.                                    |
| `maxDepth`            | `null`            | Maximum tree depth; `null` indicates unbounded growth until leaves are pure or contain fewer than `minSamplesSplit` samples. |
| `minSamplesSplit`     | `2`               | Minimum number of samples required to split an internal node.                                                                |
| `minSamplesLeaf`      | `1`               | Minimum number of samples required to be at a leaf node.                                                                     |
| `minImpurityDecrease` | `0.0`             | A split is accepted when its decrease under the selected criterion is at least this value.                                   |
| `ccpAlpha`            | `0`               | Cost-complexity pruning threshold; zero keeps the grown tree.                                                                |
| `maxLeafNodes`        | `null`            | Best-first leaf budget, an integer ≥ 2 or `null`.                                                                            |

The sample minimums can also be fractions in `(0, 1)`, resolved against the
training rows of each fit. Inspect the fitted regressor's `nLeaves_` and
`costComplexityPruningPath()` to see its leaf counts, effective alphas and total
leaf impurities; the method reports the path from the returned tree.

Use `absolute_error` for median predictions that are less affected by outliers.
Use `poisson` for nonnegative count-like targets:

```typescript
import { ArrayDatasetProvider, createTrainingClient } from 'web-ml';

const client = createTrainingClient();
const nonnegativeTargetDataset = new ArrayDatasetProvider(
	4,
	2,
	1,
	new Float64Array([0, 0, 1, 0, 0, 1, 1, 1]),
	new Float64Array([0, 1, 1, 2])
);
const run = client.train({
	algorithm: 'decision-tree-regressor',
	options: { criterion: 'poisson', maxDepth: 4 },
	data: nonnegativeTargetDataset
});
const { model } = await run.result;
const predictions = model.predict([[2.5, 3.1]]);
```
