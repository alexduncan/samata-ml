# Logistic Regression

**Algorithm ID:** `logistic-regression`

Logistic Regression is a foundational classification algorithm. Despite its name, it is used for predicting categorical classes, not continuous values. It models the probability that a given input belongs to a specific class.

LogisticRegression defaults to full-batch Adam. It also supports SGD, L-BFGS,
and cyclic proximal coordinate descent. SGD and Adam use weighted sigmoid
gradients in the worker path; L-BFGS and coordinate descent are full-data solvers.

## When to Use It

- **Binary Classification**: Predicting between two outcomes (e.g., spam vs. not spam).
- **Multiclass Classification**: Predicting one outcome from many mutually exclusive classes (e.g., identifying handwritten digits 0-9). `web-ml` handles this using independent "One-vs-Rest" heads.
- **Multi-label Classification**: Predicting multiple independent outcomes simultaneously (e.g., tagging an article as both "sports" and "local"). `web-ml` supports this natively via the `multiLabel` option.

## Quick Example

```typescript
import { ArrayDatasetProvider, createTrainingClient } from 'web-ml';

const client = createTrainingClient();
const myDatasetProvider = new ArrayDatasetProvider(
	8,
	2,
	1,
	new Float64Array([0, 2, 1, 3, 2, 4, 3, 0, 4, 1, 0, 2, 1, 3, 2, 4]),
	new Float64Array([0, 0, 0, 0, 1, 1, 1, 1])
);

const run = client.train({
	algorithm: 'logistic-regression',
	classLabels: ['negative', 'positive'],
	options: {
		solver: 'sgd',
		penalty: 'l2',
		C: 1.0,
		learningRate: 0.01
	},
	data: myDatasetProvider
});

const { model } = await run.result;

// Predict the most likely class label
const prediction = model.predict([[0.5, -1.2]]);

// Predict probabilities for each class
const probabilities = model.predictProba([[0.5, -1.2]]);
```

## Multi-label Mode

To use multi-label classification, provide a binary indicator matrix for your targets (one column per label) and enable the `multiLabel` option. The model will evaluate each label independently.

```typescript
import { ArrayDatasetProvider, createTrainingClient } from 'web-ml';

const client = createTrainingClient();
const myDatasetProvider = new ArrayDatasetProvider(
	6,
	2,
	3,
	new Float64Array([0, 0, 1, 0, 0, 1, 1, 1, 2, 1, 1, 2]),
	new Float64Array([0, 0, 0, 1, 0, 1, 0, 1, 0, 1, 1, 0, 1, 0, 1, 0, 1, 1])
);

const run = client.train({
	algorithm: 'logistic-regression',
	classLabels: ['red', 'round', 'ripe'],
	options: { multiLabel: true }, // Enable multi-label
	data: myDatasetProvider
});

const { model } = await run.result;

// Predict multiple labels simultaneously
const labels = model.predictMultiLabel([[0.5, -1.2]]);
```

## Class weights

`classWeight` accepts `'balanced'`, `null`, or a record from label to weight. Each key must equal
`String(label)` for exactly one entry of `classLabels` and carry a positive finite weight. A class you do
not list keeps weight `1`. The record must be a plain object or a null-prototype object, not an
array, `Map` or class instance. Keys named `constructor`, `toString` and `__proto__` are ordinary labels.
Weights are matched by **original label**, so reordering `classLabels` and recoding the targets
does not change which class a weight belongs to. In multi-label mode an explicit weight applies to the
positive indicators of that label.

```typescript
import { ArrayDatasetProvider, createTrainingClient } from 'web-ml';

const client = createTrainingClient();
const features = new Float64Array([0, 1, 2, 3, 4, 5, 6, 7]);

// Numeric labels: the keys are '10' and '2'.
const numeric = client.train({
	algorithm: 'logistic-regression',
	classLabels: [10, 2],
	options: { classWeight: { '10': 3 } },
	data: new ArrayDatasetProvider(8, 1, 1, features, new Float64Array([0, 0, 0, 0, 1, 1, 1, 1]))
});

// String labels: 'red' keeps weight 1.
const text = client.train({
	algorithm: 'logistic-regression',
	classLabels: ['blue', 'red'],
	options: { classWeight: { blue: 2.5 } },
	data: new ArrayDatasetProvider(8, 1, 1, features, new Float64Array([0, 0, 0, 0, 1, 1, 1, 1]))
});

// Boolean labels: the keys are 'false' and 'true'.
const boolean = client.train({
	algorithm: 'logistic-regression',
	classLabels: [false, true],
	options: { classWeight: { true: 1.5 } },
	data: new ArrayDatasetProvider(8, 1, 1, features, new Float64Array([0, 0, 0, 0, 1, 1, 1, 1]))
});

const [{ model: byNumber }, { model: byText }, { model: byBoolean }] = await Promise.all([
	numeric.result,
	text.result,
	boolean.result
]);
byNumber.predict([[2]]);
byText.predict([[6]]);
byBoolean.predict([[4]]);
```

An unknown key, a key matching two labels (for example `'1'` for the labels `1` and `'1'`), a zero,
negative or non-finite weight, and a non-record value all fail the run with `invalid-request` before any
data is read. Existing fitted models that stored a zero weight still load. A fixed binary `threshold`
compares the positive probability with `>=`, and its positive label is the second entry of `classLabels`
whatever its sort order.

## Inspecting the fitted model

`model.decisionFunction(X)` returns the linear scores `intercept + sum(coef * x)`, shape `[n, 1]` for a binary model (the score for the second class) and `[n, K]` otherwise; the sigmoid of a score is the matching `predictProba` column and no decision threshold is applied. `featureContributions(model, X)` splits each score exactly into the intercept plus one term per input column. A matrix with the wrong number of columns throws `X has <q> features, but LogisticRegression is expecting <p> features.` See [Model inspection](../model-inspection.md#feature-contributions).

## Hyperparameters

You can configure the model's behavior by passing these properties into the `options` object.

| Option         | Default          | Description                                                                                                                                                                                                                            |
| :------------- | :--------------- | :------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `multiClass`   | `'ovr'`          | The multiclass strategy. Currently only supports `'ovr'` (One-vs-Rest).                                                                                                                                                                |
| `multiLabel`   | `false`          | If true, trains independent probability outputs for each target column.                                                                                                                                                                |
| `penalty`      | `'none'`         | The type of regularization used to prevent overfitting. Options: `'none'`, `'l1'`, `'l2'`, or `'elasticnet'`.                                                                                                                          |
| `C`            | `1`              | The inverse of the regularization strength. Smaller values specify stronger regularization. Ignored if `penalty` is `'none'`.                                                                                                          |
| `l1Ratio`      | `0.5`            | Used only when `penalty` is `'elasticnet'`. Defines the mix between L1 (0.0 to 1.0) and L2 regularization.                                                                                                                             |
| `classWeight`  | `null`           | Set to `'balanced'` to automatically adjust weights inversely proportional to class frequencies, or provide a record from label to a positive finite weight (see Class weights).                                                       |
| `solver`       | `'adam'`         | Choose `'sgd'`, `'adam'`, `'lbfgs'`, or `'coordinate_descent'`. Adam and coordinate descent accept all current penalties; L-BFGS accepts only `none` or `l2`.                                                                          |
| `fitIntercept` | `true`           | Whether to calculate an intercept (bias) for this model.                                                                                                                                                                               |
| `learningRate` | Solver-dependent | SGD uses this step size (default `0.01`); Adam uses a fixed `0.001`; L-BFGS and coordinate descent do not accept it.                                                                                                                   |
| `nIterations`  | `1000`           | The maximum number of passes over the training data.                                                                                                                                                                                   |
| `tol`          | Solver-dependent | Default `1e-6` for SGD/Adam and `1e-4` for L-BFGS/coordinate descent. SGD/Adam stop on absolute objective change; L-BFGS uses the gradient infinity norm; coordinate descent uses maximum KKT violation. Zero disables early stopping. |
| `threshold`    | `0.5`            | The probability boundary (between 0 and 1) required to predict a positive class.                                                                                                                                                       |

> **Note:** The intercept term is never penalized during regularization. When using L1 penalties, `web-ml` applies mathematically stable proximal shrinkage.

Adam uses β₁ `0.9`, β₂ `0.999`, and ε `1e-8`; these values are fixed. L-BFGS
stores ten history pairs and uses an Armijo line search capped at twenty loss
evaluations.

## Tune a binary decision threshold

For a binary task, the tuner can choose the cutoff from validation probabilities.
Do not set LogisticRegression's fixed `threshold` option in the same request.

```typescript
import { createTuner } from 'web-ml';

const search = createTuner().search({
	algorithm: 'logistic-regression',
	trainingData,
	validationData,
	classLabels: ['negative', 'positive'],
	searchSpace: { C: { kind: 'log-uniform', min: 0.1, max: 10 } },
	scoring: 'f1',
	thresholdTuning: { positiveLabel: 'positive' },
	strategy: { kind: 'random-search', nTrials: 12, randomState: 4 }
});
const result = await search.result;
const predictions = result.bestModel.predict([[0.5, -1.2]]);
console.log(result.bestDecisionThreshold, predictions);
```
