# K-Neighbors Regressor

**Algorithm ID:** `k-neighbors-regressor`

K-Nearest Neighbors Regressor (KNN) is a non-parametric regression algorithm. The target value is predicted by local interpolation of the targets associated with the nearest neighbors in the training set.

Under the hood, `web-ml` computes distances between samples using the specified distance metric (defaulting to the Minkowski metric), and can assign weights to neighbors either uniformly (averaging their values) or inversely proportional to their distance from the query point.

## When to Use It

- **Regression**: Predicting a continuous target variable based on the feature similarity to known data points.
- **Non-linear Relationships**: KNN is highly flexible and can interpolate complex non-linear surfaces without making strong assumptions about the underlying data distribution.

## Quick Example

```typescript
import { ArrayDatasetProvider, createTrainingClient } from 'web-ml';

const client = createTrainingClient();
const myDatasetProvider = new ArrayDatasetProvider(
	8,
	1,
	1,
	new Float64Array([0, 1, 2, 3, 4, 0, 1, 2]),
	new Float64Array([0, 0, 0, 0, 1, 1, 1, 1])
);

const run = client.train({
	algorithm: 'k-neighbors-regressor',
	options: {
		nNeighbors: 5,
		weights: 'distance',
		metric: 'minkowski',
		p: 2
	},
	data: myDatasetProvider
});

const { model } = await run.result;

// Predict a continuous value
const prediction = model.predict([[2.5]]);
```

## Hyperparameters

You can configure the model's behavior by passing these properties into the `options` object.

| Option       | Default       | Description                                                                                                                                               |
| :----------- | :------------ | :-------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `nNeighbors` | `5`           | Number of neighbors to use by default for nearest neighbor queries. Must be an integer >= 1.                                                              |
| `weights`    | `'uniform'`   | Weight function used in prediction. Options: `'uniform'` (all neighbors weighted equally) or `'distance'` (weights are inverse of distance).              |
| `algorithm`  | `'brute'`     | Exact `brute`, `kd_tree`, or `ball_tree` search.                                                                                                          |
| `leafSize`   | `30`          | Positive integer minimum tree leaf size; ignored by brute.                                                                                                |
| `metric`     | `'minkowski'` | Metric to use for distance computation. Options: `'minkowski'`, `'euclidean'`, or `'manhattan'`.                                                          |
| `p`          | `2`           | Power parameter for the Minkowski metric. When `p = 1`, this is equivalent to Manhattan distance. When `p = 2`, this is equivalent to Euclidean distance. |

Fresh tree models use worker-certified bounds to prune Euclidean and Manhattan queries. Minkowski, non-finite queries and unusual k values use exhaustive search. JSON and cache restoration validate and copy structure without fitting an index on the page; restored tree-configured models query exhaustively. With n rows, d features and M nodes, packed KD arrays use n + 2Md doubles and Ball arrays use n + 3Md + M, plus retained rows and build scratch.
