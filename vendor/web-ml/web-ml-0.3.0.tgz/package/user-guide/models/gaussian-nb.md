# Gaussian Naive Bayes

**Algorithm ID:** `gaussian-nb`

Gaussian Naive Bayes (GNB) is a classification algorithm that assumes the continuous values associated with each class are distributed normally (Gaussian distribution). It is a variant of Naive Bayes that applies maximum a posteriori (MAP) estimation to continuous data.

Under the hood, `web-ml` fits Gaussian Naive Bayes by computing the mean and variance of the features for each class.

## When to Use It

- **Continuous Data**: Datasets where features represent continuous measurements rather than discrete counts or booleans.
- **Fast Training**: Naive Bayes models train extremely quickly and are computationally lightweight.
- **Multiclass Classification**: Predicting one outcome from many mutually exclusive classes.

## Quick Example

```typescript
import { ArrayDatasetProvider, createTrainingClient } from 'web-ml';

const client = createTrainingClient();
const myDatasetProvider = new ArrayDatasetProvider(
	8,
	2,
	1,
	new Float64Array([0, 2, 1, 3, 2, 4, 3, 0, 4, 1, 0, 2, 1, 3, 2, 4]),
	new Float64Array([0, 0, 0, 0, 1, 1, 1, 1])
);

const run = client.train({
	algorithm: 'gaussian-nb',
	classLabels: ['indoor', 'outdoor'],
	options: {
		varSmoothing: 1e-9
	},
	data: myDatasetProvider
});

const { model } = await run.result;

// Predict the most likely class label
const prediction = model.predict([[1.1, 2.0]]);

// Predict probabilities for each class
const probabilities = model.predictProba([[1.1, 2.0]]);
```

## Class priors

`priors` holds one finite, non-negative number for every **observed** class of the fitting rows.
Position `i` belongs to the `i`th distinct observed label in portable order: booleans (`false`, `true`),
then finite numbers ascending, then strings by UTF-16 code units (case-sensitive). For example `[2, 10]`,
`['B', 'a']` and `[false, true, 2, 10, '10', '2']`. Fitting only the labels `10` and `2` with
`[0.8, 0.2]` therefore gives label `2` the prior `0.8`. Supplied values are used as given: they are not
rescaled to sum to one, so normalised probabilities are the recommended input. Explicit priors override
`fitPrior`. Fitted models keep the class axis they were trained with, so JSON saved before this ordering
was introduced restores unchanged.

```typescript
import { ArrayDatasetProvider, createTrainingClient } from 'web-ml';

const client = createTrainingClient();
const run = client.train({
	algorithm: 'gaussian-nb',
	classLabels: [10, 2],
	options: { priors: [0.8, 0.2] }, // 0.8 belongs to label 2, the first observed label in order
	data: new ArrayDatasetProvider(
		6,
		2,
		1,
		new Float64Array([0, 1, 1, 0, 0, 2, 5, 4, 6, 5, 4, 6]),
		new Float64Array([0, 0, 0, 1, 1, 1])
	)
});

const { model } = await run.result;
model.classes_; // [2, 10]
model.predict([[1, 1]]);
```

Wrong lengths, sparse arrays, non-numbers, negative values and non-finite values fail with
`invalid-request` before the model is fitted, including inside every fold of a search or
cross-validation. Migration: new fits order labels with the portable comparator above, not the browser's locale collation. A string axis such as `['B', 'a']` now puts `'B'` first (locale collation placed `'a'` first), and booleans, numbers and strings can be mixed. Re-check any priors written against the old order when you refit; models that were already fitted keep their stored axis.

## Inspecting the fitted model

`model.predictJointLogProba(X)` returns the unnormalised joint log-likelihood per class, and `featureContributions(model, X)` splits it exactly into the class log prior plus one term per input column. See [Model inspection](../model-inspection.md#feature-contributions).

## Hyperparameters

You can configure the model's behavior by passing these properties into the `options` object.

| Option         | Default | Description                                                                                                                                                                                             |
| :------------- | :------ | :------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| `priors`       | `null`  | Prior probabilities of the classes. If specified, the priors are not adjusted according to the data. One finite non-negative value for each observed class, in portable label order (see Class priors). |
| `varSmoothing` | `1e-9`  | Portion of the largest variance of all features that is added to variances for calculation stability.                                                                                                   |

## Tune a binary decision threshold

For binary classification, the tuner can select a cutoff from GaussianNB's
validation probabilities.

```typescript
import { createTuner } from 'web-ml';

const search = createTuner().search({
	algorithm: 'gaussian-nb',
	trainingData,
	validationData,
	classLabels: ['negative', 'positive'],
	searchSpace: { varSmoothing: { kind: 'log-uniform', min: 1e-10, max: 1e-6 } },
	scoring: 'f1',
	thresholdTuning: { positiveLabel: 'positive' },
	strategy: { kind: 'random-search', nTrials: 12, randomState: 4 }
});
const result = await search.result;
const predictions = result.bestModel.predict([[1.1, 2.0]]);
console.log(result.bestDecisionThreshold, predictions);
```
