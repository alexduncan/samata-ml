# Multi-layer Perceptron Regressor

**Algorithm ID:** `mlp-regressor`

The Multi-layer Perceptron (MLP) Regressor is a feedforward artificial neural network used for regression tasks. It optimizes the mean squared error (MSE) loss function using gradient descent.

MLPRegressor defaults to full-batch Adam and also supports full-batch SGD.

## When to Use It

- **Continuous Regression**: Predicting continuous numeric values (e.g., predicting house prices, temperature, etc.).

## Quick Example

```typescript
import { ArrayDatasetProvider, createTrainingClient } from 'web-ml';

const client = createTrainingClient();
const myDatasetProvider = new ArrayDatasetProvider(
	8,
	2,
	1,
	new Float64Array([0, 2, 1, 3, 2, 4, 3, 0, 4, 1, 0, 2, 1, 3, 2, 4]),
	new Float64Array([0, 0, 0, 0, 1, 1, 1, 1])
);

const run = client.train({
	algorithm: 'mlp-regressor',
	options: {
		hiddenLayerSizes: [5, 2],
		activation: 'relu',
		learningRate: 0.001,
		maxIter: 1000
	},
	data: myDatasetProvider
});

const { model } = await run.result;

// Predict continuous numeric values
const predictions = model.predict([
	[2, 2],
	[-1, -2]
]);
```

## Validation loss

Set `validationFraction` (strictly between 0 and 1) to hold out a seeded random share of the fit rows and record the squared-error objective on them every epoch. `model.validationLossCurve_` lines up with `model.lossCurve_` and `model.bestEpoch_` is the first minimum; both are `null` without the option. The held-out rows are not trained on, the fitted model keeps its final weights, and `tol` still watches the training loss; there is no early stopping. See [Model inspection](../model-inspection.md#mlp-validation-loss).

## Hyperparameters

You can configure the model's behavior by passing these properties into the `options` object.

| Option               | Default     | Description                                                                                                                           |
| :------------------- | :---------- | :------------------------------------------------------------------------------------------------------------------------------------ |
| `hiddenLayerSizes`   | `[100]`     | An array where the i-th element represents the number of neurons in the i-th hidden layer. Can also be a single number for one layer. |
| `activation`         | `'relu'`    | Activation function for the hidden layers. Options: `'identity'`, `'logistic'`, `'tanh'`, or `'relu'`.                                |
| `solver`             | `'adam'`    | Choose `'adam'` or `'sgd'`. Adam is the default and uses fixed settings.                                                              |
| `learningRate`       | `0.001`     | SGD step size. Adam uses the fixed rate `0.001`.                                                                                      |
| `maxIter`            | `200`       | Maximum number of passes over the training data.                                                                                      |
| `tol`                | `1e-6`      | Stop when absolute objective change is at most this value; `0` disables early stopping.                                               |
| `randomState`        | `undefined` | Determines random number generation for weights and bias initialization. Set to an integer for reproducible results.                  |
| `validationFraction` | `null`      | Fraction of the fit rows, strictly between 0 and 1, held out to report `validationLossCurve_` and `bestEpoch_`.                       |

Adam uses β₁ `0.9`, β₂ `0.999`, and ε `1e-8`. To tune the learning rate, select
`solver: 'sgd'`.
