# Polynomial Regression

**Algorithm ID:** `polynomial-regression`

Polynomial Regression is an extension of linear regression that models the relationship between the features and the target as an $n$-th degree polynomial. In `web-ml`, it expands the input feature matrix using polynomial basis expansion and subsequently fits an ordinary or regularized linear model.

## When to Use It

- **Non-linear Relationships**: When the relationship between the features and target is not strictly linear but can be modeled by a curve (e.g., population growth, chemical kinetics).
- **Feature Interactions**: When features might interact with one another multiplicatively to affect the output.

## Quick Example

```typescript
import { ArrayDatasetProvider, createTrainingClient } from 'web-ml';

const client = createTrainingClient();
const myDatasetProvider = new ArrayDatasetProvider(
	8,
	1,
	1,
	new Float64Array([0, 1, 2, 3, 4, 0, 1, 2]),
	new Float64Array([0, 0, 0, 0, 1, 1, 1, 1])
);

const run = client.train({
	algorithm: 'polynomial-regression',
	options: {
		degree: 2,
		solver: 'ols',
		penalty: 'l2',
		alpha: 0.05
	},
	data: myDatasetProvider
});

const { model } = await run.result;

// Predict continuous values
const prediction = model.predict([[3.5]]);
```

## Hyperparameters

Polynomial Regression accepts all options from Linear Regression, plus polynomial-specific properties. You can configure the model's behavior by passing these properties into the `options` object.

| Option            | Default           | Description                                                                                                                                           |
| :---------------- | :---------------- | :---------------------------------------------------------------------------------------------------------------------------------------------------- |
| `degree`          | `2`               | Maximum polynomial degree.                                                                                                                            |
| `interactionOnly` | `false`           | If true, only interaction features are produced: features that are products of at most `degree` distinct input features (so no $x_1^2, x_1^3$, etc.). |
| `includeBias`     | `false`           | If true, include a bias column of all ones in the polynomial expansion.                                                                               |
| `loss`            | `'squared_error'` | Loss function to minimize.                                                                                                                            |
| `penalty`         | `'none'`          | Regularization penalty. Options: `'none'`, `'l2'`.                                                                                                    |
| `alpha`           | `1.0`             | Regularization strength parameter. Must be non-negative. Ignored if `penalty` is `'none'`.                                                            |
| `solver`          | `'ols'`           | Choose `'ols'`, `'sgd'`, or `'adam'`. OLS is the default after feature expansion.                                                                     |
| `learningRate`    | `0.01`            | SGD step size. Adam uses the fixed rate `0.001`; OLS ignores this option.                                                                             |
| `maxIter`         | `1000`            | Maximum SGD or Adam updates. (Also supports `maxIterations` alias).                                                                                   |
| `tol`             | `1e-6`            | SGD/Adam stop when absolute objective change is at most this value; `0` disables early stopping. OLS ignores it. (Alias: `tolerance`.)                |
| `fitIntercept`    | `true`            | Whether to learn an intercept (bias) for this model. Defaults to `false` if `includeBias` is `true`.                                                  |

Adam uses fixed β₁ `0.9`, β₂ `0.999`, ε `1e-8`, and learning rate `0.001`.
