# Decision Tree Classifier

**Algorithm ID:** `decision-tree-classifier`

Decision Tree Classifier (DTC) is a non-parametric supervised learning algorithm used for classification. It learns simple decision rules inferred from the data features to predict the class of the target variable.

Under the hood, `web-ml` builds the decision tree using criteria like Gini Impurity, Shannon Entropy, or Log Loss.

## When to Use It

- **Interpretable Models**: When you need a model whose decisions are easy to understand and explain.
- **Non-linear Relationships**: When the data has complex, non-linear relationships that linear models fail to capture.
- **Handling Mixed Data Types**: Decision trees handle both numerical and categorical data well (when encoded properly) and don't require feature scaling.

## Quick Example

```typescript
import { ArrayDatasetProvider, createTrainingClient } from 'web-ml';

const client = createTrainingClient();
const myDatasetProvider = new ArrayDatasetProvider(
	8,
	2,
	1,
	new Float64Array([0, 2, 1, 3, 2, 4, 3, 0, 4, 1, 0, 2, 1, 3, 2, 4]),
	new Float64Array([0, 0, 0, 0, 1, 1, 1, 1])
);

const run = client.train({
	algorithm: 'decision-tree-classifier',
	classLabels: ['A', 'B'],
	options: {
		criterion: 'gini',
		maxDepth: 3,
		minSamplesSplit: 2
	},
	data: myDatasetProvider
});

const { model } = await run.result;

// Predict the most likely class label
const prediction = model.predict([[0.5, 1.2]]);

// Predict probabilities for each class
const probabilities = model.predictProba([[0.5, 1.2]]);
```

## Inspecting the fitted model

`model.tree_` returns the full tree as parallel typed arrays (children, feature, threshold, impurity, node samples, depth and per-class counts) in pre-order. `model.nLeaves_`, `model.featureImportances_`, `model.apply(X)` (leaf per row) and `model.decisionPath(X)` (root-to-leaf nodes per row) complete the view. `maxDepth_` is the realised depth, root at 0, not the `maxDepth` limit. A state saved before node statistics were recorded cannot provide `tree_` or `featureImportances_` until it is refitted. See [Model inspection](../model-inspection.md#decision-tree-structure).

## Hyperparameters

You can configure the model's behavior by passing these properties into the `options` object.

| Option                | Default  | Description                                                                                                                  |
| :-------------------- | :------- | :--------------------------------------------------------------------------------------------------------------------------- |
| `criterion`           | `'gini'` | Impurity criterion to measure split quality. Options: `'gini'`, `'entropy'`, or `'log_loss'`.                                |
| `maxDepth`            | `null`   | Maximum tree depth; `null` indicates unbounded growth until leaves are pure or contain fewer than `minSamplesSplit` samples. |
| `minSamplesSplit`     | `2`      | Minimum number of samples required to split an internal node.                                                                |
| `minSamplesLeaf`      | `1`      | Minimum number of samples required to be at a leaf node.                                                                     |
| `minImpurityDecrease` | `0.0`    | A node will be split if this split induces a decrease of the impurity >= this value.                                         |
| `ccpAlpha`            | `0`      | Cost-complexity pruning threshold; zero retains the grown tree.                                                              |
| `maxLeafNodes`        | `null`   | Best-first leaf budget, an integer ≥ 2 or `null`.                                                                            |
| `classWeight`         | `null`   | Label-keyed positive weights or `'balanced'`.                                                                                |

The sample minimums also accept fractions in `(0, 1)`, resolved against the rows
of each fit. See the [option contract](../../specification/public-api/hyperparameters.md#decisiontreeclassifier).

## Pruning and leaf budgets

Fit the full tree, then compare candidates from its positive pruning alphas on
training and held-out rows. Each fit needs a fresh data source.

```typescript
import { ArrayDatasetProvider, createTrainingClient } from 'web-ml';

const client = createTrainingClient();
const trainingRows = [[0], [1], [2], [3], [4], [5], [6], [7]];
const trainingLabels = ['A', 'A', 'B', 'B', 'C', 'C', 'C', 'C'];
const heldOutRows = [[0.5], [2.5], [6.5]];
const heldOutLabels = ['A', 'B', 'C'];
const fit = (ccpAlpha: number) =>
	client.train({
		algorithm: 'decision-tree-classifier',
		classLabels: ['A', 'B', 'C'],
		options: { ccpAlpha },
		data: new ArrayDatasetProvider(
			8,
			1,
			1,
			Float64Array.from(trainingRows.flat()),
			new Float64Array([0, 0, 1, 1, 2, 2, 2, 2])
		)
	}).result;
const { model: full } = await fit(0);
const path = full.costComplexityPruningPath();
for (const alpha of path.ccpAlphas) {
	if (alpha <= 0) continue;
	const { model } = await fit(alpha);
	const accuracy = (actual: string[], expected: string[]) =>
		actual.filter((value, i) => value === expected[i]).length / expected.length;
	console.log(
		alpha,
		model.nLeaves_,
		accuracy(model.predict(trainingRows) as string[], trainingLabels),
		accuracy(model.predict(heldOutRows) as string[], heldOutLabels)
	);
}
```

`maxLeafNodes` limits growth instead, expanding the best available split first.

## Class weights

Weights affect split scoring and leaf probabilities, while sample-count minimums
continue to count rows. Balanced weights are learned from each fit's present classes.

```typescript
import { ArrayDatasetProvider, createTrainingClient } from 'web-ml';

const run = createTrainingClient().train({
	algorithm: 'decision-tree-classifier',
	classLabels: ['common', 'rare'],
	options: { classWeight: 'balanced' },
	data: new ArrayDatasetProvider(
		6,
		1,
		1,
		new Float64Array([0, 1, 2, 3, 4, 5]),
		new Float64Array([0, 0, 0, 0, 0, 1])
	)
});
const { model } = await run.result;
console.log(model.tree_.weightedNodeSamples, model.tree_.weightedClassCounts);
```

## Tune a binary decision threshold

For binary classification, the tuner can choose a cutoff from the tree's leaf
probabilities and apply it to the returned model's `predict()` method.

```typescript
import { createTuner } from 'web-ml';

const search = createTuner().search({
	algorithm: 'decision-tree-classifier',
	trainingData,
	validationData,
	classLabels: ['negative', 'positive'],
	searchSpace: { maxDepth: { kind: 'integer', min: 1, max: 8 } },
	scoring: 'f1',
	thresholdTuning: { positiveLabel: 'positive' },
	strategy: { kind: 'random-search', nTrials: 12, randomState: 4 }
});
const result = await search.result;
const predictions = result.bestModel.predict([[0.5, 1.2]]);
console.log(result.bestDecisionThreshold, predictions);
```

## Categorical splits

Use ordinal preprocessing and name a source column to let the tree split its
categories as a set. A categorical training code must be an integer from 0 to 255;
unknown prediction codes go right. With one class the fit validates codes and returns
a pure stump. Binary ordering is optimal for Gini and entropy when `minSamplesLeaf` is 1;
larger minimums make it a heuristic. For three or more classes, search is exhaustive
through eight observed levels and uses one-versus-rest orderings above eight.

```ts
import { ArrayDatasetProvider, createTrainingClient, encodeTabularFeatures } from 'web-ml';

const rows = [['red'], ['blue'], ['green'], ['red'], ['blue'], ['green']];
const labels = Float64Array.from([0, 1, 0, 0, 1, 0]);
const packed = encodeTabularFeatures(rows, [{ name: 'colour', kind: 'categorical' }]);
const data = () =>
	new ArrayDatasetProvider(rows.length, 1, 1, packed.features.slice(), labels.slice());
const order = ['red', 'blue', 'green'];
const client = createTrainingClient();
const native = await client.train({
	algorithm: 'decision-tree-classifier',
	classLabels: [0, 1],
	data: data(),
	options: { categoricalFeatures: { sourceColumns: ['colour'] } },
	preprocessing: {
		columns: packed.columns,
		columnOptions: {
			colour: { kind: 'categorical', encoding: { kind: 'ordinal', order, unknownValue: -1 } }
		}
	}
}).result;
const oneHot = await client.train({
	algorithm: 'decision-tree-classifier',
	classLabels: [0, 1],
	data: data(),
	preprocessing: { columns: packed.columns }
}).result;
const tree = native.model.tree_;
const left = Array.from(
	tree.leftCategories.slice(tree.leftCategoriesIndptr[0], tree.leftCategoriesIndptr[1]),
	(code) => order[code]
);
const predictions = [
	native.model.predict(native.preprocessor!.transform(rows)),
	oneHot.model.predict(oneHot.preprocessor!.transform(rows))
];
console.log(left, predictions);
```
