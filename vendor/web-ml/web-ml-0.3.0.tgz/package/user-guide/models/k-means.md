# K-Means

**Algorithm ID:** `k-means`

K-Means is a foundational clustering algorithm used to partition data into distinct groups based on feature similarity. It works by identifying cluster centers and assigning each data point to the nearest center, updating iteratively to minimize the variance within each cluster.

Under the hood, `web-ml` implements K-Means with deterministic k-means++ initialization for robust starting centers. Empty centers are dynamically reset to the farthest samples, and convergence tolerance is automatically scaled by the input feature variance.

## When to Use It

- **Unsupervised Grouping**: Discovering natural groupings or segments within unlabeled data (e.g., customer segmentation).
- **Feature Vector Quantization**: Reducing the dimensionality of data by representing samples by their closest cluster center.

## Quick Example

```typescript
import { ArrayDatasetProvider, createTrainingClient } from 'web-ml';

const client = createTrainingClient();
const myDatasetProvider = new ArrayDatasetProvider(
	8,
	2,
	0,
	new Float64Array([0, 2, 1, 3, 2, 4, 3, 0, 4, 1, 0, 2, 1, 3, 2, 4])
);

const run = client.train({
	algorithm: 'k-means',
	options: {
		nClusters: 3,
		maxIterations: 300,
		randomState: 42
	},
	data: myDatasetProvider
});

const { model } = await run.result;

// Predict the integer cluster assignments for new data
const labels = model.predict([
	[0.5, -1.2],
	[1.5, 2.0]
]);
```

## Hyperparameters

You can configure the model's behavior by passing these properties into the `options` object.

| Option          | Default    | Description                                                                                              |
| :-------------- | :--------- | :------------------------------------------------------------------------------------------------------- |
| `nClusters`     | (Required) | Number of clusters to fit. Must be a positive integer and cannot exceed the number of training samples.  |
| `maxIterations` | `300`      | Maximum number of update iterations. Must be a positive integer.                                         |
| `tolerance`     | `1e-4`     | Convergence tolerance. Training stops when centroid movement is at most this fraction of the data scale. |
| `randomState`   | `0`        | Seed used for deterministic k-means++ centroid selection.                                                |
