# Hyperparameters

This detailed document remains authoritative for supported options and defaults.
The corresponding machine-readable projection is linked from each implemented
model row in [Model Inventory](models.md); validate option-name coverage with
`bun run validate:model-specifications` after changing an option table.

Each model is listed below with a row for every supported hyperparameter, its
type, default, range, and usage notes. Algorithm names are discriminators passed
to `createTrainingClient().train(...)`. This describes the current public worker
path, audited on 11 October 2026.

All properties are optional unless marked **required**. Numbers must be finite;
integer ranges include endpoints. “≥ 0” and “> 0” have no fixed upper bound, but
memory and numerical stability constrain useful values. Defaults apply when an
option is omitted; `null` is valid only where explicitly listed. Union types use
TypeScript syntax.

Data, `classLabels`, cancellation signals, and tuning settings are request
metadata, not model hyperparameters. `TrainingBatch` does not support sample
weights. Unsupported keys are rejected. Future options below are suggestions,
not accepted properties or implementation promises. See
[Current Limitations](current-limitations.md) for broader constraints.

## Class-label options

Three option families depend on the class axis. All are validated with `TrainingError` code
`invalid-request`, before any data is consumed wherever the check does not need rows.

**Weight records (`LogisticRegression`, `SVC` and `DecisionTreeClassifier`).** `ClassWeight` is
`'balanced' | Record<string | number, number> | null`. A record is accepted when its immediate
prototype is the submission realm's `Object.prototype` or `null`; arrays, `Map`, class instances and
objects with a custom prototype are rejected. The original value is checked before options are copied,
search domains are projected or a worker message is sent, because those steps can erase a prototype.
Each own enumerable string key must equal `String(originalLabel)` for **exactly one** effective
configured label and carry a positive finite weight (labels `10`, `'blue'` and `true` use the keys
`'10'`, `'blue'` and `'true'`). An unlisted class has weight `1`. Keys are validated against the
complete **declared** axis, even when a fitting subset omits a declared class. Own entries named
`constructor`, `toString` and `__proto__` are ordinary labels and survive copying, transport and lookup.
A key that matches two labels (for example `'1'` for both `1` and `'1'`) is ambiguous and fails.
`null`, omitted weights and `'balanced'` need no string matching. In multi-label logistic fits an
explicit weight applies to the positive indicators of that label. The balanced formula is unchanged
and is computed per actual fit. When a CV request infers its label vocabulary, key membership becomes
checkable after the targets are read; the check still precedes any fold fit. Fitted JSON or cache
records for earlier logistic and SVC fits that stored a formerly accepted zero weight remain readable. Trees multiply
class counts by these weights; sample minimums still count rows. Balanced tree weights
use `n / (P * count)` for each present class (`P` is the number of present classes)
and 1 for absent declared classes.

**Naive Bayes priors.** `GaussianNB.priors`, `MultinomialNB.classPrior` and `BernoulliNB.classPrior` align
with the distinct **observed** original labels of the fitting rows, decoded from the zero-based targets,
in the portable total order: booleans (`false`, `true`), then finite numbers ascending, then strings by
UTF-16 code units, case-sensitive. Examples are `[2, 10]`, `['B', 'a']` and
`[false, true, 2, 10, '10', '2']`. Direct and worker fits share this order, and inference and
restoration preserve the stored axis of an already fitted model. Explicit priors need one finite,
non-negative number at every observed-axis position. Supplied values are used as given: there is no
sum check and no rescaling, zero entries stay supported, and normalised probabilities are the
recommended input. Explicit priors override `fitPrior`, and at least two observed classes are still
required. Fitting only the labels `10` and `2` with `[0.8, 0.2]` gives label `2` the prior `0.8`.
Malformed, sparse, negative, non-finite or wrong-length priors fail before any model is fitted,
including inside every fold of a search or cross-validation and inside a PCA pipeline before PCA runs.
Migration: new fits of a mixed or locale-sensitive string axis (such as `['B', 'a']`) use this order
instead of the browser's locale collation. Re-check priors written for the old order when refitting.

**Binary cutoff identity.** A fixed `LogisticRegression.threshold` compares the positive probability with
`>=`. The positive label is `classes_[1]`, the **second effective `classLabels` entry**, whatever its
sort order. Multi-label applies the cutoff to every positive indicator. Automatic
`thresholdTuning.positiveLabel` is separate: it can name either configured binary label and defaults to
the second one. The existing incompatibility between an explicit fixed cutoff and automatic tuning remains.

**One axis for a classification PCA pipeline.** A pipeline has a single effective target-code axis. For
direct tuning and the facade, the request's outer `classLabels` are compared with
`estimator.classLabels` (as originally submitted, before either is copied) and for nested CV the outer
`classLabels` are compared with the embedded estimator's original declaration before either is inferred
or replaced. When both are supplied they must have the same length and ordered, type-sensitive labels;
a reversed, different or differently typed list fails with `invalid-request` before any source is read
or inner search starts. When exactly one is supplied it is propagated to every candidate and refit and is
the axis used for target decoding, class weights, scores, threshold selection, positive-label reporting
and hydration. When both are omitted the entry points keep their existing rules: nested CV infers its
integer axis from the targets, and direct and facade tuning keep the estimator defaults (the logistic
estimator's implicit `[0, 1]` is **not** promoted to a configured tuning axis, so binary scoring or
threshold tuning still requires a configured axis). An ordinary pipeline fit keeps its single embedded
axis. This resolution applies to direct, facade and nested PCA searches whether or not preprocessing is
enabled.

**Per-fold observed-axis checks.** After ingestion, every distinct fitting subset (the explicit-holdout
training partition, each inner fold's complement, the search-training partition and each outer-fold
complement) is checked against the observed-axis requirements of the fixed options and of every
admissible categorical search-domain member before a solver is dispatched, PCA is fitted or a trial
starts. A configuration error is therefore surfaced as `invalid-request` rather than being recorded as
a failed trial.

## Binary decision-threshold tuning

All three public tuning entrypoints accept the same optional
`thresholdTuning` object for single-label binary classifiers:
`createTrainingClient().train(...)`, `createTuner().search(...)`, and
`nestedCrossValidate(...)`. With the training client, use an
`algorithm: 'hyperparameter-tuning'` request and set `targetAlgorithm` to the
classifier; ordinary estimator training requests do not accept this option. The
other two methods take it directly in their request. The object has the same
shape everywhere: `{ positiveLabel?: ClassificationLabel }`.

Threshold tuning requires exactly two configured class labels, a classifier
exposing `predictProba()`, and a `ThresholdTuningScoring` objective: `accuracy`,
`balanced-accuracy`, `recall-macro`, `f1`, `f1-macro`, `precision-macro`, or
`matthews-correlation`. The
positive class defaults to the second `classLabels` entry;
`thresholdTuning.positiveLabel` may select either label. The tuner chooses a
probability cutoff from held-out probabilities. Fold-aware searches pool the
inner out-of-fold rows to select one cutoff for each candidate; nested
cross-validation applies that cutoff only to the outer holdout predictions.

Tuning results expose `bestDecisionThreshold` and
`decisionThresholdPositiveLabel`, and apply those values to `bestModel` so its
`predict()` method uses the selected probability cutoff. Nested-CV results
report the selected cutoff and positive label on each outer-fold result. The
cutoff metadata is included in the fitted classifier's JSON state. Without
`thresholdTuning`, each classifier keeps its existing prediction rule.
LogisticRegression's fixed `threshold` option cannot be combined with automatic
tuning. LogisticRegression multi-label mode and all multiclass tasks are
unsupported because they need per-label or multiclass decision policies. SVC
requires `probability: true` in the fixed options, or a probability search
domain whose every value is `true`. The cutoff can be slightly above `1` when
the best validation rule predicts every row as negative.

## LinearRegression

**Algorithm:** `linear-regression`

| Hyperparameter  | Type                       | Default           | Range             | Notes                                                                                                               |
| --------------- | -------------------------- | ----------------- | ----------------- | ------------------------------------------------------------------------------------------------------------------- |
| `loss`          | `'squared_error'`          | `'squared_error'` | One value         | Mean squared error.                                                                                                 |
| `penalty`       | `'none' \| 'l2'`           | `'none'`          | Listed values     | L2 adds `alpha / 2 * sum(w²)`; intercept is exempt.                                                                 |
| `alpha`         | `number`                   | `1`               | ≥ 0               | Active only with L2.                                                                                                |
| `solver`        | `'ols' \| 'sgd' \| 'adam'` | `'ols'`           | Listed values     | OLS uses row-sharded QR; SGD and Adam use deterministic full-batch updates.                                         |
| `learningRate`  | `number`                   | `0.01`            | > 0               | SGD step; Adam is fixed at `0.001`. Ignored by OLS.                                                                 |
| `maxIter`       | `number`                   | `1000`            | Integer ≥ 1       | Maximum SGD or Adam updates; does not control the direct OLS solve.                                                 |
| `maxIterations` | `number`                   | `1000`            | Integer ≥ 1       | Alias; `maxIter` takes precedence.                                                                                  |
| `tol`           | `number`                   | `1e-6`            | ≥ 0               | SGD/Adam stop when absolute objective change is at most this value; zero disables early stopping. No effect on OLS. |
| `tolerance`     | `number`                   | `1e-6`            | ≥ 0               | Alias; `tol` takes precedence.                                                                                      |
| `fitIntercept`  | `boolean`                  | `true`            | `true` or `false` | Learn an intercept.                                                                                                 |

The existing progress loss is training MSE and excludes the L2 penalty, even when the update includes it.

Adam uses β₁ `0.9`, β₂ `0.999`, and ε `1e-8`; these settings and its `0.001`
learning rate are fixed. **Unsupported / possible future options:** L1/ElasticNet with `l1Ratio`, robust
losses, non-negative coefficient constraints, selectable QR/SVD solvers, actual stochastic
updates with `batchSize`/`shuffle`/`randomState`, momentum, and learning-rate
schedules. Feature-specific penalty exemptions could be exposed; the source's
`unregularizedFeatures` is currently internal and rejected as a user worker option.

Source: [options](../../src/models/linear/linear-regression.ts),
[worker behavior](../../src/training/training-engine.ts).

## PolynomialRegression

**Algorithm:** `polynomial-regression`

| Hyperparameter    | Type                       | Default           | Range             | Notes                                                                                       |
| ----------------- | -------------------------- | ----------------- | ----------------- | ------------------------------------------------------------------------------------------- |
| `degree`          | `number`                   | `2`               | Integer ≥ 1       | Maximum degree; includes lower positive degrees. Feature count grows combinatorially.       |
| `interactionOnly` | `boolean`                  | `false`           | `true` or `false` | Products of distinct features only; excludes repeated powers.                               |
| `includeBias`     | `boolean`                  | `false`           | `true` or `false` | Add a constant-one feature, exempt from L2; independent of the learned intercept.           |
| `loss`            | `'squared_error'`          | `'squared_error'` | One value         | Squared error on expanded features.                                                         |
| `penalty`         | `'none' \| 'l2'`           | `'none'`          | Listed values     | Penalty on expanded coefficients except optional bias.                                      |
| `alpha`           | `number`                   | `1`               | ≥ 0               | Active only with L2.                                                                        |
| `solver`          | `'ols' \| 'sgd' \| 'adam'` | `'ols'`           | Listed values     | Linear solver after dense expansion.                                                        |
| `learningRate`    | `number`                   | `0.01`            | > 0               | SGD step; Adam is fixed at `0.001`. Ignored by OLS.                                         |
| `maxIter`         | `number`                   | `1000`            | Integer ≥ 1       | Maximum SGD or Adam updates.                                                                |
| `maxIterations`   | `number`                   | `1000`            | Integer ≥ 1       | Alias; `maxIter` takes precedence.                                                          |
| `tol`             | `number`                   | `1e-6`            | ≥ 0               | SGD/Adam stop on absolute objective change; zero disables early stopping. No effect on OLS. |
| `tolerance`       | `number`                   | `1e-6`            | ≥ 0               | Alias; `tol` takes precedence.                                                              |
| `fitIntercept`    | `boolean`                  | `true`            | `true` or `false` | Separate intercept; enabling this and `includeBias` introduces redundant constant terms.    |

Adam uses β₁ `0.9`, β₂ `0.999`, and ε `1e-8`; these settings and its `0.001`
learning rate are fixed. **Unsupported / possible future options:** Minimum-degree/degree-interval selection,
selective interactions, sparse expansion, and orthogonal polynomial bases could
control size and conditioning. L1/ElasticNet, robust losses, QR/SVD, batching, and
schedules require extending the linear backend. Automatic scaling would require
retained preprocessing state. Internal `unregularizedFeatures` is not a user option.

Source: [polynomial options](../../src/models/linear/polynomial-regression.ts),
[inherited options](../../src/models/linear/linear-regression.ts).

## LogisticRegression

**Algorithm:** `logistic-regression`

| Hyperparameter | Type                                                 | Default          | Range                         | Notes                                                                                                                                                                                                                       |
| -------------- | ---------------------------------------------------- | ---------------- | ----------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `multiClass`   | `'ovr'`                                              | `'ovr'`          | One value                     | One-vs-rest heads for single-label multiclass classification.                                                                                                                                                               |
| `multiLabel`   | `boolean`                                            | `false`          | `true` or `false`             | Uses one independent sigmoid output per indicator target column.                                                                                                                                                            |
| `penalty`      | `'none' \| 'l1' \| 'l2' \| 'elasticnet'`             | `'none'`         | Listed values                 | Intercepts are exempt; L1 uses proximal shrinkage.                                                                                                                                                                          |
| `C`            | `number`                                             | `1`              | > 0                           | Inverse regularization strength; no effect with no penalty.                                                                                                                                                                 |
| `l1Ratio`      | `number`                                             | `0.5`            | 0–1                           | L1 fraction for elastic-net; ignored by other penalties.                                                                                                                                                                    |
| `classWeight`  | `ClassWeight`                                        | `null`           | `balanced`, record, or `null` | Record of label to positive finite weight, keyed by `String(label)` and matched by original label; see Class-label options. In multi-label mode weights apply to positive labels.                                           |
| `solver`       | `'sgd' \| 'adam' \| 'lbfgs' \| 'coordinate_descent'` | `'adam'`         | Listed values                 | SGD/Adam use full-batch updates; L-BFGS uses limited-memory quasi-Newton steps; coordinate descent uses cyclic proximal coordinate sweeps.                                                                                  |
| `fitIntercept` | `boolean`                                            | `true`           | `true` or `false`             | Learn an intercept.                                                                                                                                                                                                         |
| `learningRate` | `number`                                             | Solver-dependent | > 0                           | SGD default is `0.01`; Adam is fixed at `0.001`. L-BFGS and coordinate descent reject this option.                                                                                                                          |
| `maxIter`      | `number`                                             | `1000`           | Integer ≥ 1                   | Maximum updates.                                                                                                                                                                                                            |
| `nIterations`  | `number`                                             | `1000`           | Integer ≥ 1                   | Alias; **`nIterations` takes precedence over `maxIter`**.                                                                                                                                                                   |
| `tol`          | `number`                                             | solver-dependent | ≥ 0                           | Default `1e-6` for SGD/Adam, `1e-4` for L-BFGS/coordinate descent. SGD/Adam use absolute objective change; L-BFGS uses gradient infinity norm; coordinate descent uses maximum KKT violation. Zero disables early stopping. |
| `threshold`    | `number`                                             | `0.5`            | 0–1                           | Probability boundary (`>=`) for the second `classLabels` entry, or for each multi-label output.                                                                                                                             |

Adam uses β₁ `0.9`, β₂ `0.999`, ε `1e-8`, and learning rate `0.001`;
it accepts explicit `0.001` and rejects any other supplied value. L-BFGS
uses history size `10` and an Armijo backtracking line search capped at `20`
evaluations, with sufficient-decrease coefficient `1e-4` and rate halved after
each rejected trial. Coordinate descent uses cyclic proximal updates with a
`0.25 * sampleWeight * feature²` curvature upper bound and a `1e-12` curvature
floor. Adam and coordinate descent support all four listed penalties;
L-BFGS supports only `none` and `l2`. **Unsupported / possible future options:**
Multinomial softmax, liblinear, Newton-CG, SAG, SAGA, minibatches, and schedules. Softmax is not used for
multi-label targets. Automatic binary threshold selection is available through
the tuner; a direct LogisticRegression `threshold` remains a fixed model option.

Source: [options](../../src/models/linear/logistic-regression.ts),
[worker validation](../../src/training/training-engine.ts).

Progress loss for SGD/Adam is mean weighted binary cross-entropy across outputs, without the penalty. L-BFGS and coordinate descent report the sum across outputs including their supported regularization terms.

## MLPClassifier

**Algorithm:** `mlp-classifier`

| Hyperparameter       | Type                                           | Default     | Range                                                    | Notes                                                                                                                                                                                                                                                                    |
| -------------------- | ---------------------------------------------- | ----------- | -------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| `hiddenLayerSizes`   | `number \| readonly number[]`                  | `[100]`     | Positive integer or non-empty array of positive integers | Number means one hidden layer; array gives successive widths. Empty topology is rejected.                                                                                                                                                                                |
| `activation`         | `'identity' \| 'logistic' \| 'tanh' \| 'relu'` | `'relu'`    | Listed values                                            | Hidden activation; output is fixed sigmoid for binary or softmax for multiclass.                                                                                                                                                                                         |
| `solver`             | `'sgd' \| 'adam'`                              | `'adam'`    | Listed values                                            | Both use full-batch updates; Adam is the default.                                                                                                                                                                                                                        |
| `learningRate`       | `number`                                       | `0.001`     | > 0                                                      | SGD step; Adam uses a fixed rate of `0.001`.                                                                                                                                                                                                                             |
| `maxIter`            | `number`                                       | `200`       | Integer ≥ 1                                              | Maximum updates.                                                                                                                                                                                                                                                         |
| `tol`                | `number`                                       | `1e-6`      | ≥ 0                                                      | Stops when absolute objective change is at most this value; zero disables early stopping.                                                                                                                                                                                |
| `randomState`        | `number`                                       | `undefined` | Any finite number                                        | Initialization seed, truncated to unsigned 32-bit; omission uses `Math.random`.                                                                                                                                                                                          |
| `validationFraction` | `number \| null`                               | `null`      | Finite, > 0 and < 1, or `null`                           | Holds out this share of the fit rows (stratified for the classifier, a seeded shuffle for the regressor, seeded by `randomState ?? 0`) to report `validationLossCurve_` and `bestEpoch_`. Held-out rows are not trained on and the fitted weights are the final weights. |

Adam uses β₁ `0.9`, β₂ `0.999`, and ε `1e-8`; these settings are fixed.
Its learning rate is fixed at `0.001`: explicit `0.001` is accepted, while any
other supplied rate is rejected.
**Unsupported / possible future options:** L-BFGS `solver`, `batchSize`,
`shuffle`, momentum/Nesterov, L2 `alpha`, dropout, schedules, gradient clipping,
`earlyStopping`/patience on the validation loss, best-weight restoration, class weights,
and a direct estimator threshold option. Binary cutoffs can instead be selected
through validation-based tuning. Multilabel output requires a new target/loss
contract and is not supported by the tuner.

Source: [shared options](../../src/models/neural-networks/_base.ts),
[classifier](../../src/models/neural-networks/mlp-classifier.ts),
[worker initialization](../../src/training/worker-compute.ts).

## MLPRegressor

**Algorithm:** `mlp-regressor`

| Hyperparameter       | Type                                           | Default     | Range                                                    | Notes                                                                                                                                                                                                                                                                    |
| -------------------- | ---------------------------------------------- | ----------- | -------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| `hiddenLayerSizes`   | `number \| readonly number[]`                  | `[100]`     | Positive integer or non-empty array of positive integers | Width of each hidden layer; empty topology is rejected.                                                                                                                                                                                                                  |
| `activation`         | `'identity' \| 'logistic' \| 'tanh' \| 'relu'` | `'relu'`    | Listed values                                            | Hidden activation; output uses identity.                                                                                                                                                                                                                                 |
| `solver`             | `'sgd' \| 'adam'`                              | `'adam'`    | Listed values                                            | Both use full-batch updates; Adam is the default.                                                                                                                                                                                                                        |
| `learningRate`       | `number`                                       | `0.001`     | > 0                                                      | SGD step; Adam uses a fixed rate of `0.001`.                                                                                                                                                                                                                             |
| `maxIter`            | `number`                                       | `200`       | Integer ≥ 1                                              | Maximum number of updates.                                                                                                                                                                                                                                               |
| `tol`                | `number`                                       | `1e-6`      | ≥ 0                                                      | Stops when absolute objective change is at most this value; zero disables early stopping.                                                                                                                                                                                |
| `randomState`        | `number`                                       | `undefined` | Any finite number                                        | Initialization seed, truncated to unsigned 32-bit; omission uses `Math.random`.                                                                                                                                                                                          |
| `validationFraction` | `number \| null`                               | `null`      | Finite, > 0 and < 1, or `null`                           | Holds out this share of the fit rows (stratified for the classifier, a seeded shuffle for the regressor, seeded by `randomState ?? 0`) to report `validationLossCurve_` and `bestEpoch_`. Held-out rows are not trained on and the fitted weights are the final weights. |

Adam uses β₁ `0.9`, β₂ `0.999`, and ε `1e-8`; these settings are fixed.
**Unsupported / possible future options:** L-BFGS, minibatch size/shuffling,
momentum, L2 `alpha`, dropout, schedules, gradient clipping,
`earlyStopping`/patience on the validation loss, best-weight restoration, and alternative regression losses. Multiple
outputs already work via `data.targetCount`, not an output-size hyperparameter.

Source: [shared options](../../src/models/neural-networks/_base.ts),
[regressor](../../src/models/neural-networks/mlp-regressor.ts).

## DecisionTreeClassifier

**Algorithm:** `decision-tree-classifier`

| Hyperparameter        | Type                                    | Default  | Range                            | Notes                                                                                                                                     |
| --------------------- | --------------------------------------- | -------- | -------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------- |
| `criterion`           | `'gini' \| 'entropy' \| 'log_loss'`     | `'gini'` | Listed values                    | `log_loss` uses the entropy split calculation.                                                                                            |
| `categoricalFeatures` | indices, source-column object or `null` | `null`   | See below                        | Selects native categorical split columns.                                                                                                 |
| `maxDepth`            | `number \| null`                        | `null`   | Integer ≥ 1 or `null`            | Null removes the depth limit; other stopping rules still apply. The fitted `maxDepth_` is the realised depth (root at 0), not this limit. |
| `minSamplesSplit`     | `number`                                | `2`      | Integer ≥ 2 or fraction in (0,1) | Fraction `f` resolves to `max(2, ceil(f * n))` for the fit's `n` rows.                                                                    |
| `minSamplesLeaf`      | `number`                                | `1`      | Integer ≥ 1 or fraction in (0,1) | Fraction `f` resolves to `max(1, ceil(f * n))` for the fit's `n` rows.                                                                    |
| `minImpurityDecrease` | `number`                                | `0`      | ≥ 0                              | Minimum decrease required to accept a split.                                                                                              |
| `ccpAlpha`            | `number`                                | `0`      | finite ≥ 0                       | Cost-complexity pruning threshold; zero preserves the grown tree.                                                                         |
| `maxLeafNodes`        | `number \| null`                        | `null`   | Integer ≥ 2 or `null`            | Best-first growth with a leaf budget; null is unlimited.                                                                                  |
| `classWeight`         | `ClassWeight`                           | `null`   | See class-label options          | Balanced uses `n / (P * count)` for each present class, where `P` is the number of present classes; absent classes keep weight 1.         |

**Unsupported / possible future options:** `maxFeatures`, randomized `splitter`
with `randomState`, monotonic constraints, and
missing-value split policies. Current ties are deterministic and
there is no random splitter requiring a seed.

Source: [tree options](../../src/models/trees/types.ts),
[tree construction](../../src/training/training-engine.ts).

For example, JavaScript computes `Math.ceil(0.1 * 30) === 3` and
`Math.ceil(0.07 * 100) === 8`, including ordinary IEEE rounding.

## DecisionTreeRegressor

**Algorithm:** `decision-tree-regressor`

| Hyperparameter        | Type                                                                 | Default           | Range                            | Notes                                                                                                                                                                                                                           |
| --------------------- | -------------------------------------------------------------------- | ----------------- | -------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `criterion`           | `'squared_error' \| 'friedman_mse' \| 'absolute_error' \| 'poisson'` | `'squared_error'` | Listed values                    | Squared-error/Friedman-MSE use variance reduction; absolute-error uses mean absolute deviation; Poisson uses mean Poisson deviance and requires nonnegative targets. Leaves use medians for absolute error and means otherwise. |
| `categoricalFeatures` | indices, source-column object or `null`                              | `null`            | See below                        | Selects native categorical split columns.                                                                                                                                                                                       |
| `maxDepth`            | `number \| null`                                                     | `null`            | Integer ≥ 1 or `null`            | Null removes the depth limit.                                                                                                                                                                                                   |
| `minSamplesSplit`     | `number`                                                             | `2`               | Integer ≥ 2 or fraction in (0,1) | Fraction `f` resolves to `max(2, ceil(f * n))` for the fit's `n` rows.                                                                                                                                                          |
| `minSamplesLeaf`      | `number`                                                             | `1`               | Integer ≥ 1 or fraction in (0,1) | Fraction `f` resolves to `max(1, ceil(f * n))` for the fit's `n` rows.                                                                                                                                                          |
| `minImpurityDecrease` | `number`                                                             | `0`               | ≥ 0                              | Minimum required impurity decrease.                                                                                                                                                                                             |
| `ccpAlpha`            | `number`                                                             | `0`               | finite ≥ 0                       | Cost-complexity pruning threshold; zero preserves the grown tree.                                                                                                                                                               |
| `maxLeafNodes`        | `number \| null`                                                     | `null`            | Integer ≥ 2 or `null`            | Best-first growth with a leaf budget; null is unlimited.                                                                                                                                                                        |

**Unsupported / possible future options:** `maxFeatures`, randomized splitter/seed,
monotonic constraints, missing-value policies,
and multioutput leaf/scoring state.

Source: [tree options](../../src/models/trees/types.ts).

Both tree options accept unique model-input indices or `{ sourceColumns: ['name'] }` with
preprocessing. Source names must identify unscaled ordinal categorical columns with at most
256 ordered levels; `unknownValue`, when set, must not be an integer in `[0, 255]`.
Training codes must be integers in `[0, 255]`. Indices address the encoded matrix; source
names resolve separately for each fit. The source form requires preprocessing and cannot be
searched as a tuning parameter or used inside a PCA pipeline estimator.

## KNeighborsClassifier

**Algorithm:** `k-neighbors-classifier`

| Hyperparameter | Type                                        | Default       | Range                           | Notes                                                                                                 |
| -------------- | ------------------------------------------- | ------------- | ------------------------------- | ----------------------------------------------------------------------------------------------------- |
| `nNeighbors`   | `number`                                    | `5`           | Integer 1–training sample count | Configure explicitly when fewer than five training rows are available.                                |
| `weights`      | `'uniform' \| 'distance'`                   | `'uniform'`   | Listed values                   | Inverse distance; if selected neighbors contain exact matches, only those matches receive weight.     |
| `algorithm`    | `'brute' \| 'kd_tree' \| 'ball_tree'`       | `'brute'`     | Listed values                   | Exact search; trees can prune certified Euclidean and Manhattan queries.                              |
| `leafSize`     | `number`                                    | `30`          | Integer ≥ 1                     | Minimum tree leaf size; validated but ignored by brute.                                               |
| `metric`       | `'minkowski' \| 'euclidean' \| 'manhattan'` | `'minkowski'` | Listed values                   | Distance metric.                                                                                      |
| `p`            | `number`                                    | `2`           | ≥ 1                             | Minkowski exponent; explicit Euclidean/Manhattan fix effective exponent to 2/1. Infinity is rejected. |

Votes use the original class label identity, preserving both type and value.
Probability columns follow the fitted `classes_` order. When vote totals tie,
default prediction selects the first tied class in that order.

**Unsupported / possible future options:** approximate search,
search-effort options, cosine/Chebyshev/precomputed/custom metrics,
`metricParams`, and callable weights. `nJobs` is absent; worker training does not
parallelize synchronous prediction.

Source: [neighbor options](../../src/models/distance-based/types.ts),
[classifier search](../../src/models/distance-based/k-neighbors-classifier.ts).

## KNeighborsRegressor

**Algorithm:** `k-neighbors-regressor`

| Hyperparameter | Type                                        | Default       | Range                           | Notes                                                                                |
| -------------- | ------------------------------------------- | ------------- | ------------------------------- | ------------------------------------------------------------------------------------ |
| `nNeighbors`   | `number`                                    | `5`           | Integer 1–training sample count | Stored neighbors used per prediction; default requires at least five rows.           |
| `weights`      | `'uniform' \| 'distance'`                   | `'uniform'`   | Listed values                   | Uniform/inverse-distance average; exact matches suppress nonzero-distance neighbors. |
| `algorithm`    | `'brute' \| 'kd_tree' \| 'ball_tree'`       | `'brute'`     | Listed values                   | Exact search; trees can prune certified Euclidean and Manhattan queries.             |
| `leafSize`     | `number`                                    | `30`          | Integer ≥ 1                     | Minimum tree leaf size; validated but ignored by brute.                              |
| `metric`       | `'minkowski' \| 'euclidean' \| 'manhattan'` | `'minkowski'` | Listed values                   | Distance metric.                                                                     |
| `p`            | `number`                                    | `2`           | ≥ 1                             | Minkowski exponent; explicit Euclidean/Manhattan select 2/1. Must be finite.         |

**Unsupported / possible future options:** Approximate search,
additional/custom/precomputed metrics, `metricParams`, callable weights,
prediction concurrency controls, and multioutput stored targets.

Source: [neighbor options](../../src/models/distance-based/types.ts),
[regressor](../../src/models/distance-based/k-neighbors-regressor.ts).

## GaussianNB

**Algorithm:** `gaussian-nb`

| Hyperparameter | Type                        | Default | Range                                            | Notes                                                                                                                                                                                                                     |
| -------------- | --------------------------- | ------- | ------------------------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `priors`       | `readonly number[] \| null` | `null`  | One finite non-negative entry per observed class | Null learns empirical priors. Position `i` is the `i`th observed label in portable order (booleans, numbers, strings), not request order. Used as given: no sum check or rescaling; normalised probabilities recommended. |
| `varSmoothing` | `number`                    | `1e-9`  | ≥ 0                                              | Fraction of largest global feature variance added to class variances. Numerical floor remains at zero; zero global variance uses a fallback scale.                                                                        |

**Unsupported / possible future options:** Per-feature smoothing/floors and
label-keyed priors could provide more control and avoid ordering ambiguity.
Weighted fitting and incremental updates require new worker data/state contracts.

Source: [NB options](../../src/models/bayesian/types.ts),
[prior/variance handling](../../src/training/training-engine.ts).

## MultinomialNB

**Algorithm:** `multinomial-nb`

| Hyperparameter | Type                        | Default | Range                                            | Notes                                                                                                                                                                                          |
| -------------- | --------------------------- | ------- | ------------------------------------------------ | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `alpha`        | `number`                    | `1`     | ≥ 0                                              | Scalar additive feature-count smoothing. Zero permits impossible events; features must be non-negative.                                                                                        |
| `forceAlpha`   | `boolean`                   | `true`  | `true` or `false`                                | True preserves alpha; false floors effective alpha at `1e-10`.                                                                                                                                 |
| `fitPrior`     | `boolean`                   | `true`  | `true` or `false`                                | Empirical priors when true, uniform when false, unless explicit priors override.                                                                                                               |
| `classPrior`   | `readonly number[] \| null` | `null`  | One finite non-negative entry per observed class | Overrides `fitPrior`; position `i` is the `i`th observed label in portable order (booleans, numbers, strings). Used as given: no sum check or rescaling; normalised probabilities recommended. |

**Unsupported / possible future options:** Per-feature `alpha`, label-keyed priors,
weighted and incremental fitting. ComplementNB needs its own estimator/objective,
not a repurposed smoothing option. Zero smoothing has a known JSON persistence
defect; see the limitations document.

Source: [NB options](../../src/models/bayesian/types.ts),
[worker smoothing](../../src/training/training-engine.ts).

## BernoulliNB

**Algorithm:** `bernoulli-nb`

| Hyperparameter | Type                        | Default | Range                                            | Notes                                                                                                                                                                                          |
| -------------- | --------------------------- | ------- | ------------------------------------------------ | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `alpha`        | `number`                    | `1`     | ≥ 0                                              | Scalar additive smoothing; zero permits impossible binary events.                                                                                                                              |
| `forceAlpha`   | `boolean`                   | `true`  | `true` or `false`                                | False floors effective alpha at `1e-10`; true preserves zero.                                                                                                                                  |
| `binarize`     | `number \| null`            | `0`     | Any finite number or `null`                      | Numeric threshold maps strictly greater values to one; null expects already-binary input.                                                                                                      |
| `fitPrior`     | `boolean`                   | `true`  | `true` or `false`                                | Empirical or uniform priors unless explicit priors override.                                                                                                                                   |
| `classPrior`   | `readonly number[] \| null` | `null`  | One finite non-negative entry per observed class | Overrides `fitPrior`; position `i` is the `i`th observed label in portable order (booleans, numbers, strings). Used as given: no sum check or rescaling; normalised probabilities recommended. |

**Unsupported / possible future options:** Per-feature `alpha`, per-feature
binarization thresholds, label-keyed priors, weighted/incremental fitting.
Per-feature thresholds could handle differently scaled indicators. Zero smoothing
has a known JSON persistence defect.

Source: [NB options](../../src/models/bayesian/types.ts),
[Bernoulli behavior](../../src/models/bayesian/bernoulli-nb.ts).

## SVC

**Algorithm:** `support-vector-classifier`

| Hyperparameter | Type                                                     | Default   | Range                                                | Notes                                                                                                                                                                                                   |
| -------------- | -------------------------------------------------------- | --------- | ---------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `C`            | `number`                                                 | `1`       | > 0                                                  | C-SVC regularization parameter; class weights multiply effective C by class.                                                                                                                            |
| `kernel`       | `'rbf' \| 'linear' \| 'poly' \| 'sigmoid'`               | `'rbf'`   | Listed values                                        | LIBSVM kernel.                                                                                                                                                                                          |
| `degree`       | `number`                                                 | `3`       | Integer ≥ 0                                          | Polynomial kernel only; zero is accepted.                                                                                                                                                               |
| `gamma`        | `'scale' \| 'auto' \| number`                            | `'scale'` | Listed strings or number ≥ 0                         | RBF/poly/sigmoid. Auto: `1 / featureCount`. Scale: `1 / (featureCount * variance(X))` over all entries; auto fallback for zero variance. Numeric zero is accepted.                                      |
| `coef0`        | `number`                                                 | `0`       | Any finite number                                    | Polynomial/sigmoid independent term.                                                                                                                                                                    |
| `tol`          | `number`                                                 | `1e-3`    | > 0                                                  | Native stopping tolerance.                                                                                                                                                                              |
| `classWeight`  | `'balanced' \| Record<string \| number, number> \| null` | `null`    | Null, balanced, or record of positive finite weights | Balanced: `samples / (classes * classCount)`. Record keys are `String(label)` of the **declared** labels (a weight may name a declared class the fitting rows omit); unspecified classes have weight 1. |
| `probability`  | `boolean`                                                | `false`   | `true` or `false`                                    | Train probability calibration; required for `predictProba()` and log-loss scoring.                                                                                                                      |

**Unsupported / possible future options:** Native `cacheSize`/`shrinking` controls
could be exposed. Calibration `randomState` requires explicit native RNG support.
`maxIter`, SGD, squared-hinge loss, sample weights, and OVR decision output require
a deliberate backend/API change. Custom/precomputed kernels and NuSVC need new
packing/formulation contracts. Follow the [SVM guidance](../internals/svm.md)
before extending the stock integration.

Source: [types](../../src/models/support-vector-machines/types.ts),
[defaults](../../src/models/support-vector-machines/support-vector-classifier.ts),
[validation/resolution](../../src/models/support-vector-machines/adapter.ts).

## SVR

**Algorithm:** `support-vector-regressor`

| Hyperparameter | Type                                       | Default   | Range                        | Notes                                                                                                                              |
| -------------- | ------------------------------------------ | --------- | ---------------------------- | ---------------------------------------------------------------------------------------------------------------------------------- |
| `C`            | `number`                                   | `1`       | > 0                          | Epsilon-SVR regularization parameter.                                                                                              |
| `epsilon`      | `number`                                   | `0.1`     | ≥ 0                          | Epsilon-insensitive tube width; zero is accepted.                                                                                  |
| `kernel`       | `'rbf' \| 'linear' \| 'poly' \| 'sigmoid'` | `'rbf'`   | Listed values                | Native kernel.                                                                                                                     |
| `degree`       | `number`                                   | `3`       | Integer ≥ 0                  | Polynomial only.                                                                                                                   |
| `gamma`        | `'scale' \| 'auto' \| number`              | `'scale'` | Listed strings or number ≥ 0 | Auto: `1 / featureCount`. Scale: `1 / (featureCount * variance(X))`, auto fallback for zero variance. Linear kernel ignores gamma. |
| `coef0`        | `number`                                   | `0`       | Any finite number            | Polynomial/sigmoid independent term.                                                                                               |
| `tol`          | `number`                                   | `1e-3`    | > 0                          | Native stopping tolerance.                                                                                                         |

**Unsupported / possible future options:** Native cache/shrinking controls,
precomputed/custom kernels, and a separate NuSVR formulation. `maxIter`, SGD,
squared-epsilon loss, sample weights, and multioutput fitting require backend or
contract changes. SVC's `classWeight`/`probability` are not SVR options; this
integration does not expose uncertainty estimates.

Source: [types](../../src/models/support-vector-machines/types.ts),
[defaults](../../src/models/support-vector-machines/support-vector-regressor.ts), [validation](../../src/models/support-vector-machines/adapter.ts).

## KMeans

**Algorithm:** `k-means`

| Hyperparameter  | Type     | Default                  | Range                  | Notes                                                                                      |
| --------------- | -------- | ------------------------ | ---------------------- | ------------------------------------------------------------------------------------------ |
| `nClusters`     | `number` | **Required; no default** | Integer 1–sample count | Number of centers; duplicate data can still leave centers empty.                           |
| `maxIterations` | `number` | `300`                    | Integer ≥ 1            | Maximum Lloyd updates; no `maxIter` alias.                                                 |
| `tolerance`     | `number` | `1e-4`                   | ≥ 0                    | Relative convergence threshold scaled using feature variance, not a raw absolute distance. |
| `randomState`   | `number` | `0`                      | Any finite number      | Single k-means++ initialization seed, truncated to unsigned 32-bit.                        |

**Unsupported / possible future options:** `nInit` for multiple starts, `init`
selection/custom centers, Elkan algorithm, minibatch size/update controls, sample
weights, and automatic cluster-count selection. Multiple starts could reduce
dependence on one local optimum but require winner selection/resource budgeting.

Source: [options](../../src/models/clustering/k-means.ts),
[worker updates](../../src/training/training-engine.ts).

## PCA

**Algorithm:** `pca`

| Hyperparameter | Type      | Default                          | Range                                      | Notes                                                                                                                 |
| -------------- | --------- | -------------------------------- | ------------------------------------------ | --------------------------------------------------------------------------------------------------------------------- |
| `nComponents`  | `number`  | `min(sampleCount, featureCount)` | Integer 1–`min(sampleCount, featureCount)` | Retained axes; fractional variance targets and `'mle'` are invalid. Requires at least two samples.                    |
| `center`       | `boolean` | `true`                           | `true` or `false`                          | Subtract feature means. False decomposes uncentered second moments normalized by `samples - 1`.                       |
| `scale`        | `boolean` | `false`                          | `true` or `false`                          | Requires centering. Training sample standard deviations use `samples - 1`; zero deviations become one during fitting. |

**Unsupported / possible future options:** `whiten`, `svdSolver` with direct,
randomized/truncated SVD, solver `randomState`, `nOversamples`, power iterations,
and tolerance; variance-fraction/MLE component selection; incremental batch
controls. The fitted `PCA` retains means and effective standard deviations for
reusable transform/inverse-transform. Scaled reconstruction scoring uses this
same guarded scale state, including unit scales for constant columns.

Source: [options/result](../../src/models/dimensionality-reduction/pca.ts),
[defaults/validation](../../src/training/training-engine.ts),
[scaling/decomposition](../../src/training/worker-compute.ts).

## PCA Pipeline

`algorithm: 'pca-pipeline'` accepts `pcaOptions` and one supervised `estimator`
request with that estimator's existing option type. MultinomialNB is rejected
because PCA scores may be negative. Random Search accepts namespaced search
keys: `pca.nComponents`, `pca.center`, `pca.scale`, and
`estimator.<supported-option>`. `baseOptions` separates fixed values into
`pcaOptions` and `estimatorOptions`. Random Search is supported; Hyperband is
not. Nested cross-validation uses the same option namespaces and refits PCA
inside every fold's training partition.

A pipeline has one class axis; conflicting outer and embedded `classLabels` declarations are rejected
(see Class-label options). With the opt-in top-level `preprocessing` option the order is raw rows,
frozen tabular transform, PCA, estimator; the embedded estimator must not carry `preprocessing`. PCA
components are then checked against each fit's **encoded** width, an omitted `pca.nComponents` resolves
per fit to `min(rows, encodedWidth)`, and a Random Search over `pca.nComponents` is rejected as a whole
(with `invalid-request`, before any candidate runs) when any admissible count cannot fit any fitting
partition. The same rule covers a standalone `pca` search. See
[Tabular preprocessing](tabular-preprocessing.md).
