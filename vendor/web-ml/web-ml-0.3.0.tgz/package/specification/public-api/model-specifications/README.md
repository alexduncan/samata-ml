# Machine-readable model specifications

This directory contains versioned JSON projections of the implemented model
catalogue. The detailed Markdown specifications and public TypeScript declarations
remain authoritative; these files make model IDs, supported options, and exposed
model-specific diagnostics easier to inspect with ordinary JSON tooling.

## Files and schema

- `schema.json` uses JSON Schema Draft 2020-12. Its `$defs.model` describes each
  model document and `$defs.index` describes `index.json`.
- `index.json` lists each model by its public training `algorithm` ID, display
  name, normalized task type, and path relative to this directory.
- `models/<model-id>.json` contains the corresponding model document.

All documents use `schemaVersion: 1`. `lastUpdated` is an ISO date and changes
when that model document's contract metadata changes. A fixed default is stored
in `default`, including when its value is `null`; other non-conditional default
kinds use `defaultNote`. A `conditional` default uses `defaultBy` rules with a `when`
object containing prerequisite option values and the resulting `value`. `appliesWhen`
identifies when an option is user-configurable or tunable; `defaultBy` records each
solver's effective default, including a fixed value accepted explicitly at runtime. Enum
hyperparameters provide an `enumDescriptions` object keyed by each allowed
value, separately from the concise parameter-level `description`. `when` matches
effective option values after each option's own default has been applied, so an
omitted solver can select the matching default rule. Model entries
omit `status` because this catalogue contains only implemented models. An empty
`metrics` list means the model has no model-specific
diagnostic or fit statistic currently exposed. Standalone evaluation scores,
held-out validation reports, tuning and nested cross-validation reports, and
run timing are not model metrics. Schema v1 therefore remains unchanged for
these library-wide evaluation capabilities.

The catalogue maps K-Means to `taskType: "clustering"`. PCA uses
`dimensionality-reduction`. The PCA pipeline and hyperparameter-tuning request
are compositions/orchestration modes, not concrete model entries.

## Documentation paths and package contents

Each model document's `documentation` paths are POSIX paths relative to the
installed package root. The package must include these targets:

- `user-guide/models/<model-id>.md`
- `specification/public-api/models.md`
- `specification/public-api/hyperparameters.md`
- `specification/public-api/metrics.md`

The package includes the whole `user-guide/` directory, so every documentation
target and the guide links in the packaged `README.md` resolve.

The package also publishes this directory so consumers can load the index,
schema, and individual model documents through the documented package subpaths.

`inputScaleSensitivity` is an optional additive schema-v1 projection. Its `default`
is `sensitive`, `invariant`, or `not-applicable`. Rules in `when` are matched in
order against effective options after defaults are applied; the first matching
rule supplies the value, otherwise `default` applies. Sensitive fits may change
when input scales change; invariant fits are treated as scale independent, and
not-applicable denotes count models for which standardisation can be unsuitable.
Gaussian Naive Bayes is classified invariant although its variance-smoothing
term depends weakly on the largest feature variance. The `pca-pipeline`
composition has no model document and uses the `pca` rule on `pcaOptions`.

## Keeping the projection current

Update the relevant model JSON, its `lastUpdated` date, and `index.json` in the
same change whenever an implemented model ID, name, family, task, supported
option/default/constraint, or exposed diagnostic changes. Validate the catalogue
against the inventory and option tables with `bun run validate:model-specifications`.
That check verifies the Markdown projection and paths; it does not inspect
TypeScript semantics. Contributors must also audit IDs against the public
training discriminator, options against the runtime allow-list and exported
option types, and metrics against fitted model classes, hydration, progress
events, and tests.

Progress-event metrics describe the optional per-model `liveMetrics` snapshots,
except existing loss and inertia, which remain available without the flag.
Availability is conditional: for example a finite SVM gap may be unavailable,
prequential NB scores need an earlier chunk, and neighbour index keys exist only
for tree builds. PCA has no live keys. The index projects model identity and
paths rather than duplicating metric lists, so metric-only updates leave its
contents unchanged while it is still validated against the individual documents.
