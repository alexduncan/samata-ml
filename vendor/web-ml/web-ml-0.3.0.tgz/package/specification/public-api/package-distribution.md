# Package distribution

How the `web-ml` package is laid out, versioned and released as a tarball. The consumer-facing API is described in the other [public API documents](../README.md#public-api-public-api); this document covers only the packed artefact.

## Package contents

The package contains exactly what `package.json` `"files"` allows, plus the files npm always includes (`package.json`, `README.md`, `LICENSE.md`):

- `dist/` (bundles, declarations under `dist/src/`, and `dist/wasm/`)
- `specification/public-api/`
- `user-guide/` (the whole consumer guide, so the packed `README.md` links resolve)
- `README.md`, `LICENSE.md` and `THIRD-PARTY-NOTICES.md`

A packed file must also match no forbidden rule. These never ship: sources and tooling (`src/`, `scripts/`, `test/`, `tests/`, `docs/`, `scratch/`, `tmp/`, `.claude/`, `.github/`), `specification/internals/`, `specification/plans/`, `specification/requests/`, any `node_modules` path, native sources (`.zig`, `.c`, `.cc`, `.cpp`, `.h`), `.map`, `.tgz` and `.tsbuildinfo` files, `.ts` files other than `.d.ts`, test files, `.DS_Store` and `.env*` files.

`dist/src/**/*.d.ts` is generated declarations that `dist/index.d.ts` imports; it is part of the package. Markdown that links to repository-only paths (`src/`, `specification/internals/`, `CONTRIBUTING.md`) keeps those links, which resolve on the repository host only.

## Exports and relative layout

Every `main`, `module`, `types` and `exports` target exists in the package. `./model-specifications/*` expands to one target per model listed in the packed catalogue, and every model `documentation` path exists too.

The relative layout of `dist/` is part of the contract: `dist/index.js`, both orchestrators, the probe and the compute workers sit side by side, and `wasm/` sits beside them. Every string-literal `new URL('<path>', import.meta.url)` in a packed `dist` module whose path ends in `.js` or `.wasm` resolves to a packed file. See [current limitations](current-limitations.md#browser-and-deployment-constraints) for the deployment rule.

## Licences and notices

`THIRD-PARTY-NOTICES.md` holds one `## <package>` section for every third-party package bundled into `dist/` (today `numpy-ts` and `idb`) with its full licence text, and a `## LIBSVM` section matching `dist/wasm/LIBSVM-COPYRIGHT`. Bundled packages are found from the `// node_modules/<package>/` origin comments in the packed bundles. A bundled package without an installed licence file, a section, or its licence text in the notices file fails the release.

## Versioning

Versions follow SemVer 2.0.0 and, before `1.0.0`, the `0.MINOR.PATCH` convention. Increase MINOR for any new public capability or breaking change and PATCH for fixes, documentation or packaging-only changes. `-rc.N` pre-releases are used only for candidates shared before a final version. Build metadata (`+...`) is not allowed, because SemVer precedence ignores it. The first packed release is `0.2.0`.

## Release tarballs

`bun run pack:release` builds, packs and verifies the package on a clean, committed working tree:

1. Refuse a dirty tree, an invalid version, or an existing output file.
2. Delete `dist/`, run `bun run build`, and refuse if the build modified tracked files. Stale output from removed modules therefore cannot ship.
3. Pack with `bun pm pack`, extract the tarball and check the allowlist, forbidden content, required files, export targets, relative URLs and notices.
4. Copy the extracted package into a standalone consumer directory, resolve every export subpath from it, and import the entry to check its function exports.
5. Write `releases/web-ml-<version>.tgz` and `releases/web-ml-<version>.tgz.sha256`.

The checksum file uses `sha256sum` format: `<64 lowercase hex>  web-ml-<version>.tgz`. The command never overwrites an existing release; bumping the version is the only way to produce a new tarball. `releases/` is ignored by git.

Reproducibility means the same commit and pinned toolchains produce the same packed file list and file contents. Tarball bytes are not guaranteed to be identical across runs. Packing needs the pinned Zig and Emscripten toolchains; consumers do not.
