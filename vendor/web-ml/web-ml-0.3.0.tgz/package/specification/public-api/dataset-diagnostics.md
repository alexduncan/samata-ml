# Pre-training dataset diagnostics

`diagnoseDataset(request, options?)` analyses a dataset before training. It returns
`Promise<DatasetDiagnostics>` and reports source-column summaries, missingness,
correlation and variance inflation, effective dimensionality, class balance and
stable, machine-readable findings. It complements `diagnoseModel`, which evaluates
predictions, and [`checkStratifiedPartition`](stratified-partitions.md), which checks
partition feasibility without loading rows.

The request takes the same `data` source and optional `preprocessing` as training,
plus optional `classLabels`, `model`, `partition`, `thresholds` and `limits`.
`model` carries an algorithm and its options; for `pca-pipeline`, use `pcaOptions`
and optionally `estimator: { algorithm }`. It selects scale sensitivity and
partition rules; no model is fitted. `options.signal` cancels the operation.
The exported declarations define `DatasetDiagnosticsRequest`,
`DatasetDiagnosticsOptions`, `DatasetDiagnosticsModel`,
`DatasetDiagnosticsThresholds`, `DatasetDiagnosticsLimits`, `DatasetDiagnostics`,
`DatasetColumnSummary`, `NumericColumnSummary`, `CategoricalColumnSummary`,
`DatetimeColumnSummary`, `DatasetCorrelation`, `DatasetVarianceInflation`,
`DatasetExcludedColumn`, `DatasetDimensionality`, `DatasetClassBalance`,
`DatasetFinding`, `DatasetFindingCode`, and `InputScaleSensitivity`.

## Input, preprocessing and validation

`sampleCount` and `featureCount` must be positive safe integers. A classifier model
or `classLabels` requires `targetCount` 1; labels must be valid, unique, and between
1 and 4,096 in number. Labels with a non-classifier model are invalid. A partition
requires a model accepted by the matching validation entry point: `k-fold` uses
`crossValidate`, `holdout` uses `holdoutValidate`, and `nested` uses
`nestedCrossValidate`. A nested PCA pipeline also requires an estimator. Invalid
requests reject with `TrainingError` `invalid-request` before source reading;
invalid fold counts or holdout ratios are reported as `partitionIssue` instead.
Only model options used to determine scale sensitivity are checked: linear and
polynomial solver and penalty, and PCA `center` and `scale` (including pipeline
`pcaOptions`). Scaling with `center: false` is invalid.

The source is loaded once under the training lock. `NaN` features are missing;
positive or negative infinity, including an unwritten provider cell, rejects with
`invalid-request`. Used classification targets must be finite integer class indices
from 0 to 4,095 and, if labels are supplied, less than their length. Other targets
are loaded but ignored, including non-finite values. Algorithm-specific training
fit restrictions do not apply. Unknown tabular codes and invalid imputation reject
as they do during training.

When preprocessing is supplied, it is fitted on **all** rows, and the resulting
`featureNamesOut` and `outputColumns` are returned as copies. The encoded width
`p_eff` is `featureNamesOut.length`; otherwise it is the source feature count.
The fit is not reused by training: a training or validation fold fits its own
transformer and can have a narrower output. See [tabular preprocessing](tabular-preprocessing.md).

## Summaries and statistics

Each source column reports its index, name (`null` for dense data), kind, missing
count, missing rate (`missingCount / n`) and observed count. Numeric summaries
include the observed mean, population standard deviation (`ddof = 0`), minimum,
maximum, quartiles and IQR. Quartiles use NumPy's linear method: interpolate at
`(n_observed - 1) * q` for `q = 0.25, 0.5, 0.75`. All statistics are `null`
when no values are observed. Interpolation preserves equal subnormal endpoints
and avoids overflowing the difference between opposite extreme endpoints.

Categorical summaries report observed non-missing level counts in transport
dictionary order, excluding zero-count levels; `rareLevelCount`, the fitted
encoding, the number of levels grouped into the fitted one-hot infrequent bucket,
and encoded output width including any indicator. Rare levels use observed counts
before imputation; grouping uses the fitted transform's own count basis.

Datetime summaries report the observed epoch-millisecond minimum and maximum
(`null` when none), resolved time zone, and the number of mapped outputs including
any indicator. Datetime values are validated and imputed as in training, but
datetime outputs do not participate in categorical findings, constant-column
findings, scale, correlation or VIF analysis.

Scale uses value columns: numeric columns after fitted imputation and scaling,
ordinal columns after imputation, ordering and scaling, and dense numeric columns
over observed values. It is the ratio of largest to smallest positive SD, or
`null` if fewer than two value columns have positive SD. SD ties select the lowest
source index. One-hot, indicators and datetime outputs are excluded.

Correlation and VIF use numeric **source** columns only. A no-observed-values or
constant column is excluded and recorded in `excludedFromCorrelation`. With
preprocessing, numeric values use fitted imputation and all `n` rows. Dense data
uses listwise-complete rows across the initially eligible columns; that row set is
computed once. A column constant on those rows is then excluded without recomputing
the row set. Fewer than two complete rows or fewer than two eligible columns yields
null correlation and VIF. Otherwise Pearson correlation uses centred cross-products,
is clamped to `[-1, 1]`, and has an exact unit diagonal. The result owns a
row-major `TrainingTensor<Float64Array>` with shape `[k, k]` and `rowsUsed`.
Numeric means, population standard deviations and correlations centre values
relative to an observed anchor before scaling, retaining small representable
differences around a large offset. Extreme ranges use overflow-safe centring.

For `2 ≤ k ≤ maxVifColumns` and `rowsUsed > k`, VIF uses the correlation matrix:
for each column, Cholesky factorisation orders it last and skips other pivots
`≤ 1e-10`; `VIF = 1 / (1 - R²)`, or `Infinity` when the final complement is
`≤ 1e-10`. Correlation is skipped above `maxCorrelationColumns` and VIF above
`maxVifColumns` or when too few complete rows are available.

`classBalance`, when requested by a classifier model or `classLabels`, reports
labels and counts in declared order, or inferred integer labels `0..max(target)`;
the first minimum and maximum indices break ties. The imbalance ratio is maximum
count divided by minimum count, or `Infinity` for an empty class. The minority
count divided by `p_eff` is events per variable.

`dimensionality` contains `n`, source width, `p_eff`, mappings, `minTrainingRows`,
`partitionStratified`, `partitionIssue`, minority count and events per variable.
Without a partition the minimum is `n`. With stratification, feasibility uses
`checkStratifiedPartition`: k-fold minimum is `n` minus the largest validation
fold tally across classes; holdout minimum is `n - Math.round(testRatio * n)`;
nested minimum is the smallest inner-training tally over outer and inner folds.
Unstratified k-fold uses `n - ceil(n / K)`; nested first sets
`m = n - ceil(n / outerFolds)` and uses `m - ceil(m / innerFolds)`. Infeasibility
sets the minimum to `null` and returns the issue. With fewer than two resolved
labels, k-fold and nested return a null minimum and null issue; holdout still uses
its split rule. See [stratified partitions](stratified-partitions.md).

## Thresholds and findings

Effective thresholds and limits are echoed in the result. Upper bounds fire at
equality; `minEventsPerVariable` fires strictly below its threshold. Comparisons use
the reported double value directly.

| Setting                 | Default | Valid values                                      |
| ----------------------- | ------- | ------------------------------------------------- |
| `scaleRatio`            | 10      | finite > 1                                        |
| `correlation`           | 0.8     | 0 < value ≤ 1, compared with absolute correlation |
| `vif`                   | 5       | finite > 1                                        |
| `dimensionalityRatio`   | 0.5     | 0 < value < 1                                     |
| `minEventsPerVariable`  | 10      | finite > 0                                        |
| `imbalanceRatio`        | 3       | finite ≥ 1                                        |
| `rareLevelMinFrequency` | 5       | integer ≥ 1, or fraction in (0, 1)                |
| `oneHotWidth`           | 20      | integer ≥ 2                                       |
| `highMissingRate`       | 0.5     | 0 < value ≤ 1                                     |
| `maxCorrelationColumns` | 200     | integer ≥ 2                                       |
| `maxVifColumns`         | 50      | integer ≥ 2                                       |

Findings have `{ code, severity, columns, classIndex?, value, threshold }`. They
are emitted in the order below, then by source column and class index. `columns`
are source indices except that `scale-disparity` reports largest then smallest.
Finding codes are stable across patch releases; new codes require a minor release.

| Code                         | Severity        | Condition and reported value                                                    |
| ---------------------------- | --------------- | ------------------------------------------------------------------------------- |
| `missing-without-imputation` | warning         | no preprocessing and missing cells; total missing cells                         |
| `high-missing-rate`          | warning         | column missing rate ≥ `highMissingRate`                                         |
| `missing-values`             | info            | 0 < missing rate < `highMissingRate`                                            |
| `constant-column`            | info            | excluded numeric constant; its value                                            |
| `scale-disparity`            | warning or info | scale ratio ≥ `scaleRatio`, for a sensitive model or no model respectively      |
| `perfect-collinearity`       | warning         | VIF is `Infinity`                                                               |
| `high-vif`                   | warning         | finite VIF ≥ `vif`                                                              |
| `high-correlation`           | info            | absolute pair correlation ≥ `correlation`; value retains its sign               |
| `correlation-skipped`        | info            | eligible column count exceeds `maxCorrelationColumns`                           |
| `vif-skipped`                | info            | count exceeds `maxVifColumns` but not correlation limit                         |
| `vif-insufficient-rows`      | info            | rows used ≤ eligible column count                                               |
| `features-exceed-rows`       | warning         | `p_eff ≥ minTrainingRows`; value is `p_eff`                                     |
| `features-approach-rows`     | info            | `p_eff < minTrainingRows` and `p_eff / minTrainingRows ≥ dimensionalityRatio`   |
| `low-events-per-variable`    | warning         | events per variable < `minEventsPerVariable`                                    |
| `single-observed-class`      | warning         | fewer than two observed classes; threshold 2                                    |
| `empty-class`                | warning         | declared class count is zero; identifies `classIndex`                           |
| `class-imbalance`            | info            | no empty class and ratio ≥ `imbalanceRatio`; identifies minority `classIndex`   |
| `large-one-hot-expansion`    | info            | one-hot category plus infrequent outputs ≥ `oneHotWidth`                        |
| `rare-levels`                | info            | observed levels have count below integer threshold `t`, or below `fraction * n` |

Thresholds in findings are the corresponding effective threshold, except missing,
constant and perfect-collinearity findings use `null`; `features-exceed-rows`
uses `minTrainingRows`, `vif-insufficient-rows` uses `k`, and `rare-levels` uses
the effective count threshold. Findings never contain messages.

Scale sensitivity is `sensitive` for iterative logistic, MLP, KNN, SVM and
K-Means fits; `invariant` for decision trees and Gaussian NB (its variance
smoothing has a small scale dependence); and `not-applicable` for multinomial
and Bernoulli NB. Linear and polynomial regression are invariant for unpenalised
OLS and sensitive for SGD, Adam or L2. PCA and PCA pipelines are invariant when
`scale: true`, otherwise sensitive. The model catalogue projects the same rules;
iterative solvers are sensitive because fixed step sizes, iteration limits and
tolerances operate in input units.

## Execution, cancellation and memory

Diagnostics requires cross-origin isolation, Web Workers and Web Locks, like
training. It waits behind active training on the `web-ml:training` lock, runs
statistics in cancellable chunks on the orchestrator, and creates no compute
workers, model, cache entry or public progress stream. An aborted signal rejects
with `AbortError` and releases the lock. A numerical overflow that cannot produce
a finite statistic rejects with `numerical-failure`; documented infinite VIFs and
empty-class imbalance ratios are the only non-finite result values.

Memory includes the page and orchestrator input buffers, numeric value columns,
one transient sorted column and `O(k²)` correlation/VIF state. Datetime fitting
also uses its existing capped instant memo (up to 65,536 entries per datetime
column); no full encoded matrix is materialised. Work is bounded by the configured
column limits, but up to `O(n * 200²)` correlation and `O(50⁴ / 3)` VIF work is
possible at defaults. The implementation yields between chunks for cancellation.
