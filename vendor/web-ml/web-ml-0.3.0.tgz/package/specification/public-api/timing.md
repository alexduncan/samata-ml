# Training Metrics and Timing

Fixed-option `crossValidate` measures page-side end-to-end `trainingMetrics.durationMs`
from loading through all folds, diagnostics and optional refit. Each fold duration
includes its fit and scoring; `refit.durationMs` covers only the final full-data
fit. These measurements include worker waits and hydration.

The duration contract is defined in
[`worker-training.md`](../internals/worker-training.md). This
guide explains how applications read those measurements.

This document explains how `web-ml` measures and reports the time taken for training, tuning, and nested cross-validation runs.

## Where Metrics Live

Instead of embedding `durationMs` directly on the fitted estimator result payload, timing is returned through a separate promise on the run object:

```ts
const run = createTrainingClient().train(request);
const { model } = await run.result;
const { durationMs } = await run.trainingMetrics;
```

This ensures that all estimators, whether they are classifiers, regressors, or clustering algorithms, report timing in a consistent format without polluting the model's domain-specific output. For ordinary runs, `run.result` resolves to an object containing the hydrated estimator as `model`; tuning runs resolve to their tuning result.

## Duration Semantics

For ordinary runs with validation, `evaluationDurationMs` measures held-out
evaluation inside `durationMs`. It is absent when validation is not requested.

For ordinary training, `fitDurationMs` measures the orchestrator's wall interval
around algorithm dispatch after the initial pool is acquired. It includes branch
preparation and reductions, but excludes ingestion, initial pool acquisition,
finalization and validation. For a PCA pipeline it is the sum of the PCA and
estimator fit calls: PCA transformation and projection assembly are included;
both pools, shard creation, metadata validation and projected-data handoff are
excluded. This is not pure compute time. Tuning, cross-validation and holdout
timings do not supply this field.

The `durationMs` field measures the end-to-end wall-clock time elapsed during the training operation.
It includes the work needed to compute enabled live diagnostics; enabling them
does not change the measurement boundaries or evaluation intervals.

- **Orchestrator Timing**: For basic training and tuning runs, `durationMs` is measured in the orchestrator worker. It starts when `executeRun` begins and ends when the final result is ready. This includes data ingestion, worker pool startup, algorithm fitting, and reduction.
- **Nested Cross-Validation Timing**: Nested CV is orchestrated on the page-side, so its overall `durationMs` is measured on the main thread using `performance.now()`.
- **Fixed-option Cross-Validation Timing**: `crossValidate` measures page-side
  elapsed time from data loading through diagnostics and optional refit. Nested CV likewise
  includes its optional refit. Both include the time spent in `onModel` hooks and in model disposal.

## High-Resolution Timing

We use `performance.now()` instead of `Date.now()` for precise sub-millisecond timing. This avoids inconsistencies caused by system clock adjustments and provides higher precision for fast-training models.

## Per-trial and Per-fold Timing

While the overall run exposes a single `trainingMetrics` promise, granular timings are available within summary objects:

- **Tuning Trials**: Each `TuningTrialSummary` returned within a `TuningResult` includes a `durationMs` field. This measures the time taken strictly to fit and score that specific trial (excluding worker pool startup time).
- **Nested CV Folds**: Each `NestedCVFoldResult` includes a `durationMs` field representing the time taken to tune and evaluate that specific outer fold. It ends before the `onModel` hook runs and before the winner is disposed, so it excludes both.
- **Nested CV refit**: `NestedCVRefitResult.durationMs` covers the refit search plus its final fit, excluding the outer folds and any hook.
- **Fixed-option CV and refit**: Each fold measures fit and scoring and, like nested folds, excludes hook time and model disposal; the optional
  `refit.durationMs` measures only the full-data fit, excluding fold timings and hook time.

## Failure Handling

If a run fails, the `run.trainingMetrics` promise rejects with the exact same error as `run.result`. To prevent unhandled promise rejections for users who only await `run.result`, the library internally attaches a no-op `.catch(() => undefined)` to the metrics promise.

`holdoutValidate` measures page-side elapsed time from the start of the run through data loading, worker fitting, scoring, requested evaluation, any `onModel` hook and, unless `returnFit` keeps the model, fit cleanup. With `returnFit: true`, `result.fit.durationMs` covers only the training request through page hydration, like `refit.durationMs`: it is page-side wall-clock time that includes client queueing, worker data loading and fitting, not CPU time inside the worker, and it excludes the split, scoring, evaluation, the hook and cleanup; it is at most the end-to-end `durationMs`. The run's successful `trainingMetrics` contains only `durationMs`; on failure or cancellation both promises reject with the same error.
