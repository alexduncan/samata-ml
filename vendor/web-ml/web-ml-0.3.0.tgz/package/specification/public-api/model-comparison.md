# Cross-validated model comparison

`bayesianCorrelatedTTest(scoresA, scoresB, options)` and `correctedResampledTTest(scoresA, scoresB, options)`
compare two models, or two hyperparameter settings, from paired per-partition scores on one dataset. Both are
exported from the package root. They are synchronous and pure: they need no worker, training client, lock,
WebAssembly module or browser API, so they run on the page or in any module worker. They never mutate their
inputs, and their results are plain, structured-cloneable objects.

Comparing mean cross-validation scores without a test overstates differences, and the ordinary paired t-test is
overconfident because partitions share training rows (Nadeau & Bengio, 2003). Both tests correct the variance
for that overlap. The Bayesian test adds a region of practical equivalence (ROPE), so it can say that two
models differ by less than a chosen amount. The corrected test gives a p-value. Equal `folds` and `randomState`
give equal partitions across algorithms in `crossValidate`, so the scores of two runs are paired.

## Types

```ts
interface BayesianCorrelatedTTestOptions {
	readonly rope: number; // finite, >= 0, in score units
	readonly testFraction: number; // finite, in (0, 1)
}

interface BayesianCorrelatedTTestResult {
	readonly probabilityLower: number; // P(δ < −rope)
	readonly probabilityEquivalent: number; // P(−rope ≤ δ ≤ rope)
	readonly probabilityHigher: number; // P(δ > rope)
	readonly meanDifference: number; // mean of A[i] − B[i]
	readonly scale: number; // posterior scale; 0 for a point mass
	readonly degreesOfFreedom: number; // n − 1
}

type TTestAlternative = 'two-sided' | 'less' | 'greater';

interface CorrectedResampledTTestOptions {
	readonly testFraction: number; // finite, in (0, 1)
	readonly alternative?: TTestAlternative; // default 'two-sided'
}

interface CorrectedResampledTTestResult {
	readonly statistic: number;
	readonly pValue: number;
	readonly degreesOfFreedom: number;
	readonly meanDifference: number;
	readonly standardError: number;
	readonly alternative: TTestAlternative;
}

function bayesianCorrelatedTTest(
	scoresA: ArrayLike<number>,
	scoresB: ArrayLike<number>,
	options: BayesianCorrelatedTTestOptions
): BayesianCorrelatedTTestResult;

function correctedResampledTTest(
	scoresA: ArrayLike<number>,
	scoresB: ArrayLike<number>,
	options: CorrectedResampledTTestOptions
): CorrectedResampledTTestResult;
```

`scoresA[i]` and `scoresB[i]` are the scores of the two models on the same partition `i`, in any orientation
(accuracy, loss or other). The functions accept plain arrays, typed arrays and objects with a numeric `length`.
There is no default `rope` and no default `testFraction`: a `rope` presumes a score scale and a
`testFraction` presumes a fold count.

## Orientation

Results are stated on the difference `δ = A − B`. There is no orientation flag. `probabilityHigher` is the
posterior probability that A's expected score is higher than B's by more than `rope`; for scores where higher is
better that means A is better, and for losses such as `mean-squared-error` it means A is worse. To state the
result from B's side, swap the arguments: the swap exactly exchanges `probabilityLower` and `probabilityHigher`,
exactly negates `meanDifference` and `statistic`, and leaves `probabilityEquivalent`, `scale`,
`degreesOfFreedom` and the two-sided `pValue` unchanged. The `'less'` and `'greater'` p-values are exchanged.

## Validation

The first failing rule throws `TrainingError` with code `invalid-request`; the message names the parameter
(`scoresA`, `scoresB`, `rope`, `testFraction`, `alternative` or `options`).

1. `options` is not a non-null object.
2. `scoresA` or `scoresB` is not a non-null object with a non-negative safe-integer `length` (strings and other
   primitives are rejected).
3. The lengths differ.
4. `n < 2`.
5. (Bayesian only) `rope` is not a finite number `>= 0`.
6. `testFraction` is not a finite number with `0 < testFraction < 1`.
7. (Corrected only) `alternative` is present and is not one of the three strings.
8. A score is not a finite `number`, checked for `i = 0 … n − 1` as `scoresA[i]` then `scoresB[i]`.
9. A difference `scoresA[i] − scoresB[i]` is not finite (overflow).

`TrainingError` with code `numerical-failure` is reserved for two cases: the corrected variance overflows, and
the defensive path in which the Student-t evaluation fails to converge.

## Method

Let `d[i] = A[i] − B[i]` for `i = 0 … n − 1`, with mean `d̄` (summed left to right), sample variance
`s² = Σ (d[i] − d̄)² / (n − 1)`, and `ρ = testFraction`, the share of the data in each test set,
`n_test / (n_train + n_test)`. Define

```
σ = sqrt((1/n + ρ/(1 − ρ)) · s²)
```

The factor `1/n + ρ/(1 − ρ)` equals the Nadeau–Bengio factor `1/n + n_test/n_train`. Let `F` be the cumulative
distribution function of Student's t distribution with `n − 1` degrees of freedom.

**Bayesian correlated t-test** (Corani & Benavoli, 2015). The posterior of the expected difference `δ` is a
Student-t distribution with `n − 1` degrees of freedom, location `d̄` and scale `σ`:

```
probabilityLower      = F((−rope − d̄) / σ)
probabilityHigher     = F((d̄ − rope) / σ)
probabilityEquivalent = max(0, 1 − (probabilityLower + probabilityHigher))
```

The parentheses are normative: adding the two tails first makes `probabilityEquivalent` bit-identical when A and
B are swapped. With `rope = 0` and a positive scale, `probabilityEquivalent` is exactly 0 (see
[Zero variance](#zero-variance) for the point-mass case).

**Corrected resampled t-test** (Nadeau & Bengio, 2003; Bouckaert & Frank, 2004 for its use with k-fold
cross-validation). `standardError = σ`, `statistic = d̄ / σ`, and the reference distribution is Student-t with
`n − 1` degrees of freedom. The p-value is `min(1, 2 · F(−|statistic|))` for `'two-sided'`, `F(statistic)` for
`'less'` and `F(−statistic)` for `'greater'`.

### Zero variance

When every difference is identical (`d[i] === d[0]` for all `i`), or `σ` underflows to exactly 0, the posterior
is a point mass at `meanDifference`. The region that contains it gets probability 1, with the closed interval
`[−rope, rope]` as the equivalence region, so `rope = 0` and `meanDifference = 0` gives
`probabilityEquivalent = 1`. `scale` and `standardError` are 0. In the corrected test, `statistic` is `0` when
`meanDifference` is 0, `+Infinity` when it is positive and `−Infinity` when it is negative, and the p-values
follow from `F(±Infinity)`. The corrected test takes no `rope`, so the same positive difference can be
"equivalent" in the Bayesian test and an infinite statistic in the corrected test.

## Choosing `testFraction` and repeated runs

The correlation `ρ` depends only on the test share of each partition, not on the run or fold layout, so the
input is two flat arrays plus `testFraction`. The functions are invariant to the order of the pairs.

- For `k`-fold cross-validation with equal folds, `testFraction = 1 / k`.
- From a `crossValidate` result, `result.folds.map((fold) => fold.score)` lists the per-partition scores in
  ascending `foldIndex` order, and `testFraction` is the mean of `validationSampleCount` divided by the sum
  of `validationSampleCount`. For uneven partitions this is a single average share and an approximation.
- For repeated cross-validation, run `crossValidate` again with a different `randomState` for each repeat and
  the same `folds`, `classLabels` and `randomState` values for both models. Concatenate the partition scores of
  the repeats in the same order for both models. `testFraction` stays `1 / k`.

`crossValidate` has no built-in repetition.

## Correspondence with `baycomp`

`baycomp.CorrelatedTTest.probs(x = A, y = B, rope, runs)`, where `n / runs = 1 / testFraction`, returns
`(p_left, p_rope, p_right) = (probabilityHigher, probabilityEquivalent, probabilityLower)`, because `baycomp`
forms `y − x`. With `rope = 0` it returns `(probabilityHigher, probabilityLower)`. Result names here are
orientation-neutral on purpose, because `baycomp`'s `left` and `right` use the opposite sign convention.

## Numerical accuracy

The Student-t CDF evaluates the lower tail directly through the regularised incomplete beta function
(`F(−|t|) = ½ · I_x(ν/2, ½)` with `x = ν / (ν + t²)`) and uses symmetry for the upper half. No small
probability is formed as `½` plus a number near `−½`. With `ν = n − 1` degrees of freedom the measured accuracy is
bounded as follows.

| Degrees of freedom `ν` | Absolute bound | Relative bound (lower tail) |
| ---------------------- | -------------- | --------------------------- |
| `ν ≤ 1000`             | 1e-14          | 3e-13                       |
| `1000 < ν ≤ 10^4`      | 1e-13          | 2e-12                       |
| `10^4 < ν ≤ 10^6`      | 1e-11          | 2e-10                       |

For `ν ≤ 1000`, every probability and p-value is accurate to 1e-14 absolute, and `probabilityLower`, a small
`probabilityHigher` and every p-value below ½ are lower-tail values with relative accuracy of 3e-13 while they
are normal doubles. Beyond `ν = 10^6` accuracy degrades with `ν`; the measurements at `ν = 10^7` (8.6e-12
absolute, 3.8e-10 relative) are an indication only. `probabilityEquivalent` is accurate in absolute terms only,
because it is a difference of nearly equal quantities when both tails are near 1.

`probabilityLower` and `probabilityHigher` are non-increasing or non-decreasing in `meanDifference`, and p-values
in the statistic, on the tested grids. At the resolution of single-ulp steps, rounding may reverse them by no
more than the absolute bound.

Cost is O(n) time and O(1) extra memory beyond one pass over the differences.

## Scope and limits

Out of scope: the hierarchical Bayesian comparison across several datasets, the Bayesian signed-rank and sign
tests, Friedman and Nemenyi tests and other multiple-model comparisons, multiple-comparison correction, posterior
sampling or plotting, quantile functions and a public Student-t API. See
[Current limitations](current-limitations.md).

## Standalone example

```ts
import { bayesianCorrelatedTTest, correctedResampledTTest } from 'web-ml';

const scoresA = [0.82, 0.79, 0.85, 0.81, 0.84, 0.8, 0.83, 0.86, 0.78, 0.82];
const scoresB = [0.8, 0.78, 0.81, 0.8, 0.82, 0.79, 0.8, 0.83, 0.79, 0.8];

// Ten-fold cross-validation: each partition tests one tenth of the rows.
const result = bayesianCorrelatedTTest(scoresA, scoresB, { rope: 0.01, testFraction: 0.1 });
console.log(result.probabilityLower); // about 0.0009147
console.log(result.probabilityEquivalent); // about 0.1214
console.log(result.probabilityHigher); // about 0.8777

const test = correctedResampledTTest(scoresA, scoresB, {
	testFraction: 0.1,
	alternative: 'greater'
});
console.log(test.statistic, test.pValue);
```
