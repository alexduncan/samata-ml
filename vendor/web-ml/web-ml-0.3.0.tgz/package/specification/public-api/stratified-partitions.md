# Stratified partition feasibility

`checkStratifiedPartition(classCounts, request)` says, before training, whether a stratified
single-target classification partition request will pass the library's partition-capacity rules, and
which limits the class counts allow. It is exported from the package root. It is synchronous and pure,
needs no worker and reads no seed: stratified fold sizes depend only on class size, fold count and fold
index, and holdout quotas are seed-independent.

[`diagnoseDataset`](dataset-diagnostics.md) reproduces the validation entry points'
partition sizes and stratification decision for a given model.

`crossValidate`, `nestedCrossValidate` and `stratifiedTrainTestSplit` decide each partition-capacity
rejection with the same per-rule predicates the check composes, at the position where they decide it
today and with the message they use today. Two checks stay in the entry points because they also
validate other inputs: the nested positivity check on `sampleCount`, `outerFolds` and `innerFolds`
(`no-rows`, and `invalid-fold-count` below 1) and the split helper's empty-input check (`no-rows`).
Unit tests pin their outcomes to the rules below.

## Types

```ts
type StratifiedPartitionRequest =
	| { kind: 'k-fold'; folds: number }
	| { kind: 'nested'; outerFolds: number; innerFolds: number }
	| { kind: 'holdout'; testRatio: number };

function checkStratifiedPartition(
	classCounts: readonly number[],
	request: StratifiedPartitionRequest
): StratifiedPartitionFeasibility;
```

The result is `{ feasible: true, limits }` or `{ feasible: false, issue, limits }`. An issue has a stable
`code`, an informative English `message`, and, where they apply, `parameter` (`'folds'`, `'outerFolds'`,
`'innerFolds'` or `'testRatio'`), `classIndex` and `outerFold`. Callers branch on `code`, not on `message`.

`classCounts[c]` is the number of rows whose encoded class is `c`. An empty array is valid and reports
`no-rows`. `checkStratifiedPartition` throws `TrainingError` (`invalid-request`) when `classCounts` is not
an array, holds a value that is not a non-negative safe integer, or sums to more than `2 ** 32 - 1`, or
when `request` is not an object or its `kind` is unknown. Any numeric field of a valid request kind may
hold any number; an invalid value produces an issue, never a throw. Let `N` be the sum of the counts.

## Rules and order

The first failing rule is reported. Classes are visited in ascending index, outer folds in ascending
index with classes ascending inside each fold. The order matches each entry point's capacity checks.

### `k-fold` (`crossValidate`)

1. `N = 0`: `no-rows`.
2. `folds` is not a safe integer or is below 2: `invalid-fold-count`, parameter `folds`.
3. `folds > N`: `too-many-folds`, parameter `folds`.
4. The first observed class with fewer than `folds` rows: `class-smaller-than-folds`, with `classIndex`.

Classes with zero rows are ignored.

### `nested` (`nestedCrossValidate`, single-label classification)

1. `N = 0`: `no-rows`.
2. `outerFolds` is not a safe integer or is below 1: `invalid-fold-count`, parameter `outerFolds`.
3. `innerFolds` is not a safe integer or is below 1: `invalid-fold-count`, parameter `innerFolds`.
4. `outerFolds = 1`: `invalid-fold-count`; `outerFolds > N`: `too-many-folds`; parameter `outerFolds`.
5. `innerFolds = 1`: `invalid-fold-count`; `innerFolds > N - 1`: `too-many-folds`; parameter `innerFolds`.
6. The first class with fewer than `outerFolds` rows: `class-smaller-than-folds`, with `classIndex`,
   parameter `outerFolds`. Unlike k-fold, classes with zero rows are included, because nested CV
   evaluates the whole label axis (a declared `classLabels`, else `0 ... max target`).
7. The first outer fold `f` and, within it, class `c` of size `n` where
   `n - (floor((f+1)·n/K) - floor(f·n/K)) < innerFolds` and `K = outerFolds`:
   `class-short-in-outer-training`, with `classIndex`, `outerFold` and parameter `innerFolds`.

Rules 2 and 3 precede 4 and 5 because the entry point validates both fields as positive integers before
it checks either range. The block `floor((f+1)·n/K) - floor(f·n/K)` is the number of rows of a class of
size `n` that land in outer fold `f`; it equals the tally the fold assignment produces.

### `holdout` (`stratifiedTrainTestSplit`)

1. `N = 0`: `no-rows`.
2. `testRatio` is not a finite number in the open interval (0, 1): `invalid-test-ratio`.
3. The first observed class with exactly one row: `singleton-class`, with `classIndex`.
4. With `lo(n) = clamp(floor(r·n), 1, n - 1)` and `hi(n) = clamp(ceil(r·n), 1, n - 1)` over observed
   classes, `Math.round(r·N)` outside `[Σ lo, Σ hi]`: `test-count-infeasible`, parameter `testRatio`.

Classes with zero rows are ignored. A single observed class is valid when its total is feasible.

### Singleton classes

A class with one row is infeasible in every kind: k-fold and nested through the two-fold minimum, holdout
through the singleton rule.

## Issue codes

The codes are a closed union and are stable across patch releases. A new code needs a minor release and
existing codes are never repurposed.

| Code                            | Kind    | Entry-point message it maps to                                                                                                                                                                                                                       |
| ------------------------------- | ------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `no-rows`                       | all     | `Invalid data dimensions or fold count.` (k-fold); `sampleCount must be a positive safe integer.` (nested); `targets must not be empty.` (holdout)                                                                                                   |
| `invalid-fold-count`            | k-fold  | `Invalid data dimensions or fold count.`                                                                                                                                                                                                             |
| `invalid-fold-count`            | nested  | `outerFolds must be a positive safe integer.` / `innerFolds must be a positive safe integer.` (value below 1 or not an integer); `outerFolds must be between two and sampleCount.` / `innerFolds must be between two and sampleCount - 1.` (value 1) |
| `too-many-folds`                | k-fold  | `Invalid data dimensions or fold count.`                                                                                                                                                                                                             |
| `too-many-folds`                | nested  | `outerFolds must be between two and sampleCount.` / `innerFolds must be between two and sampleCount - 1.`                                                                                                                                            |
| `class-smaller-than-folds`      | k-fold  | `Class ${c} needs at least ${folds} rows for stratified folds.`                                                                                                                                                                                      |
| `class-smaller-than-folds`      | nested  | `Class ${c} needs at least outerFolds (${outerFolds}) rows for stratification.`                                                                                                                                                                      |
| `class-short-in-outer-training` | nested  | `Class ${c} leaves too few training rows in outer fold ${f} for ${innerFolds} inner folds.`                                                                                                                                                          |
| `invalid-test-ratio`            | holdout | `testRatio must be a finite number in the open interval (0, 1).`                                                                                                                                                                                     |
| `singleton-class`               | holdout | `Class ${c} has a single row, so it cannot appear on both sides of a split.`                                                                                                                                                                         |
| `test-count-infeasible`         | holdout | `testRatio ${r} needs ${required} test rows, but per-class bounds allow only ${min} to ${max}.`                                                                                                                                                      |

## Limits

Limits are returned with both verdicts so a form can bound its inputs. Each is an exact integer, or
`null` when no value is feasible or the prerequisite is invalid.

- k-fold `maxFolds`: the smallest observed class count when it is at least 2, else `null`.
- nested `maxOuterFolds`: the smallest count over all classes, zero counts included, when it is at least
  2, else `null`. It bounds rule 6 only.
- nested `maxInnerFolds`: when the request's `outerFolds` passes rules 2, 4 and 6, the minimum over
  classes of `n - ceil(n / outerFolds)`, capped at `N - 1`, when that is at least 2; otherwise `null`.
- nested `maxEqualFolds`: the largest `k >= 2` for which `outerFolds = innerFolds = k` is feasible, else
  `null` (including when `maxOuterFolds` is `null`).
- holdout `requiredTestCount = Math.round(r·N)`, `minTestCount = Σ lo`, `maxTestCount = Σ hi`; all `null`
  when `N = 0`, the ratio is invalid or a singleton class exists.

Worked examples (they are pinned by the unit tests):

- Counts `[5, 3]`: k-fold `maxFolds = 3`. Nested with `outerFolds = 3` gives `maxInnerFolds = 2` and
  `maxEqualFolds = null`.
- Counts `[6, 6]`: `maxEqualFolds = 4`.
- Counts `[0, 4, 4]`: k-fold with `folds = 4` is feasible. Nested with `outerFolds = 2, innerFolds = 2`
  reports `class-smaller-than-folds` for class 0.
- Nested `outerFolds = 1, innerFolds = 0` on `[6, 6]` reports `invalid-fold-count` for `innerFolds`.
- Holdout `[2, 2]` with `testRatio = 0.2`: each class has `lo = hi = 1`, so two test rows are needed but
  `Math.round(0.8) = 1`: `test-count-infeasible` with `requiredTestCount = 1`, `minTestCount =
  maxTestCount = 2`.

## Cost

The check runs in O(C · log₂ N) time for C = `classCounts.length`, with O(C) extra memory and nothing
allocated in proportion to the row count. No loop runs over rows, candidate fold counts or outer folds,
so it is safe to call on every form edit. `maxEqualFolds` is a binary search, exact because the per-class
condition `n - ceil(n / k) >= k` is prefix-monotone in `k`.

## Equivalence contract

An entry-point call _corresponds_ to `classCounts` and `request` when its encoded targets have exactly
`classCounts[c]` rows of class `c`, its sample count is `N`, its fold counts or `testRatio` equal the
request's, and, for CV, its label axis has exactly `classCounts.length` entries: a declared `classLabels`
of that length, or, when `classLabels` is omitted, the inferred axis `0 ... max target`, which requires the
last count to be positive. Fixed CV and the split helper ignore zero-count classes, so trailing zeros
affect only nested CV.

A call is _capacity-clean_ when both hold:

1. Every non-capacity condition of a shared check holds. Two checks combine capacity and non-capacity
   conditions: the `crossValidate` pre-read condition and the nested positivity loop. For `crossValidate`,
   `data` must be present, `data.featureCount` a safe integer of at least 1 and `data.targetCount` equal
   to 1. For `nestedCrossValidate`, `featureCount` and `targetCount` must be positive safe integers.
2. No other check rejects: the call would pass every check of that entry point that is not a partition
   capacity check.

For every corresponding, capacity-clean call, the entry point rejects with a partition-capacity message
if and only if the check is infeasible, and the message is the one the table above gives for the issue,
with the same class and outer fold. A feasible verdict guarantees that the entry point does not reject for
partition capacity; an infeasible one guarantees that it does.

### Exclusions

The check makes no claim about calls that are not capacity-clean. A `crossValidate` call with
`featureCount = 0` or `targetCount = 2` is rejected with `Invalid data dimensions or fold count.` even when
the check is feasible; a nested call with `featureCount = 0` is rejected with `featureCount must be a
positive safe integer.` before any fold message. Likewise a label axis shorter than two, a target index
outside a declared axis, a non-finite seed, F1 scoring with three labels and estimator requirements such
as the two observed classes Naive Bayes and SVC need in a training partition are separate rules; their
rejection order and messages are unchanged. Regression (unstratified), multi-label (iterative) and
caller-supplied tuning folds are not covered.

## Standalone example

```ts
import { checkStratifiedPartition } from 'web-ml';

const classCounts = [6, 6];
const equal = checkStratifiedPartition(classCounts, {
	kind: 'nested',
	outerFolds: 4,
	innerFolds: 4
});
if (equal.feasible && equal.limits.kind === 'nested') {
	// maxEqualFolds is 4 for these counts.
	void equal.limits.maxEqualFolds;
}

const bad = checkStratifiedPartition(classCounts, { kind: 'holdout', testRatio: 1.5 });
if (!bad.feasible) void [bad.issue.code, bad.issue.parameter]; // 'invalid-test-ratio', 'testRatio'
```

`holdoutValidate` delegates its split directly to `stratifiedTrainTestSplit`, including its seed, ratio and capacity rules; it applies its own training-input and estimator checks before fitting.
