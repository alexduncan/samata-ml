# Model inspection

**Status:** current

Fitted classifiers expose what they learned, so callers can debug, teach and audit a model
without re-implementing its arithmetic. Everything here is stable public API, runs on the
calling thread, never starts a training worker and never mutates its inputs. Result arrays are
freshly allocated ordinary typed arrays owned by the caller, and getters return copies on every
access. Where this page and `src/` disagree, `src/` is wrong. Examples live in the
[model inspection guide](../../user-guide/model-inspection.md).

Contributions and tree `featureImportances_` are per **model input column** and can be summed
by source using `featureNamesOut` and `outputColumns`, including one-hot, infrequent groups and
each `datetime` role. [Permutation importance](#permutation-importance) is per permutation unit:
one input column by default or one `featureGroups` group. Score drops are not additive, so do not
sum them by source; build `featureGroups` from `outputColumns[i].sourceIndex` instead.

## Decision tree

`DecisionTreeClassifier` records `samples`, `classCounts` (on the sorted `classes_` axis) and
`impurity` for every node at fit time, in both fit paths, and carries them in portable state.
`maxDepth_` is the **realised** depth with the root at depth 0, not the configured `maxDepth`;
`nodeCount_` counts every node.

```ts
interface DecisionTreeStructure {
	readonly nodeCount: number;
	readonly classes: readonly ClassificationLabel[]; // copy of classes_
	readonly childrenLeft: Int32Array; // -1 for a leaf
	readonly childrenRight: Int32Array; // -1 for a leaf
	readonly feature: Int32Array; // -1 for a leaf
	readonly threshold: Float64Array; // NaN for a leaf or categorical node
	readonly categorical: Uint8Array; // 1 for a categorical internal node
	readonly leftCategoriesIndptr: Uint32Array; // nodeCount + 1 offsets
	readonly leftCategories: Uint32Array; // concatenated sorted left code sets
	readonly impurity: Float64Array;
	readonly nodeSamples: Uint32Array;
	readonly depth: Uint32Array; // root 0
	readonly classCounts: Uint32Array; // nodeCount x classes.length, row-major
	readonly weightedNodeSamples: Float64Array; // nodeCount
	readonly weightedClassCounts: Float64Array; // nodeCount x classes.length, row-major
}

interface DecisionTreePath {
	readonly indptr: Uint32Array; // length rows + 1, indptr[0] = 0
	readonly indices: Uint32Array; // node indices, root to leaf, per row
}
```

| Member                 | Meaning                                                                         |
| ---------------------- | ------------------------------------------------------------------------------- |
| `tree_`                | `DecisionTreeStructure`. Throws when the state lacks node statistics (below).   |
| `nLeaves_`             | Number of nodes whose `feature` is `-1`.                                        |
| `categoricalFeatures_` | Sorted model-input categorical indices, returned as an independent copy.        |
| `featureImportances_`  | `Float64Array`, length `nFeaturesIn_`, mean decrease in impurity, summing to 1. |
| `apply(X)`             | `Uint32Array`: the leaf node index reached by each row.                         |
| `decisionPath(X)`      | `DecisionTreePath` in compressed sparse row form.                               |

- Node `i` is the `i`-th node of a pre-order traversal that visits the left child first. Row
  `i` of `classCounts` gives the training rows reaching node `i` per class and sums to
  `nodeSamples[i]`.
- At a numeric node, a row goes left when `X[row, feature[i]] <= threshold[i]` and right otherwise, **including
  `NaN`**. At a categorical node it goes left only when the integer code is in that node's
  ascending `leftCategories` slice; unseen, negative, non-integer, out-of-range and `NaN` values go right.
  Each row's path starts at 0, ends at
  `apply(X)[row]`, is strictly increasing and has length `depth[leaf] + 1`.
- `impurity[i]` is Gini `1 - sum p^2`, or `-sum p log2 p` (bits) for `entropy` and `log_loss`,
  with `p = weightedClassCounts / weightedNodeSamples` and `0 log 0 = 0`; a pure node has exactly 0. Both fit
  paths record it through one shared kernel, so equal counts give bit-identical values.
- `featureImportances_`: for every internal node `t` with children `l`, `r`, add the
  signed weighted impurity decrease to `feature[t]` and normalise feature totals to sum 1.
  Unit weights retain the original arithmetic `n_t imp_t - n_l imp_l - n_r imp_r`, then divide
  by root count. With non-unit weights each term is root-normalised before multiplication,
  `(W_t/W_root) imp_t - (W_l/W_root) imp_l - (W_r/W_root) imp_r`, avoiding an
  overflowing intermediate. A tree with no impurity decrease returns all zeros.
- `apply` and `decisionPath` validate `X` like prediction (fitted model, 2-D matrix, `nFeaturesIn_`
  columns) and throw the same errors.
- **Legacy states.** A state saved before node statistics hydrates and predicts, and supports
  `apply`, `decisionPath` and `nLeaves_`, but `tree_` and `featureImportances_` throw an `Error`
  saying the state lacks node statistics and the model must be refitted.

The regressor exposes `nLeaves_` and records node samples and impurity in portable
state, but does not expose `tree_`. Both models return fresh `ccpAlphas`,
`impurities` and `nLeaves` arrays from `costComplexityPruningPath()`.

For binary classification, category levels are ordered by weighted proportion of class 1;
for regression they are ordered by mean target. With `minSamplesLeaf` 1, prefix search is
optimal for binary Gini or entropy and for squared error or Friedman MSE. With larger leaf
minimums, and for absolute error or Poisson regression, it is a heuristic. For `K >= 3`
classes, the fit enumerates all unique partitions at up to eight observed levels; beyond eight,
it uses one-versus-rest orderings. `K` follows the class-axis rule below. A `K = 1` fit validates
all categorical codes before returning a pure stump. Ties choose lower feature first and the first
enumerated categorical partition.

Portable categorical nodes store ascending `leftCategories` and omit `threshold`; leaves omit
both. The state carries the fitted categorical indices, and `fromJSON` rejects invalid indices,
code sets and inconsistent categorical nodes. Older states lacking these fields hydrate normally.
On gain-separated fits with matching class axes, the fit-path parity rule extends to categorical
membership sets and statistics; regressor predictions agree within `1e-12 * max(1, |a|)`.

An unfitted model throws exactly `Model has not been trained yet. Train with createTrainingClient().train(...) first.`
A legacy classifier without node statistics throws exactly `This DecisionTreeClassifier state lacks node statistics (it was saved before they were recorded). Refit the model to use costComplexityPruningPath().`
A legacy regressor without node statistics throws exactly `This DecisionTreeRegressor state lacks node statistics (it was saved before they were recorded). Refit the model to use costComplexityPruningPath().`

### Fit-path parity rule

P1: each path reproduces its own pre-change tree bit for bit with default new
options; the two paths need not be bit-identical to each other. P2: on a
gain-separated fit with equal `classes_`, both paths return identical structure,
threshold bits and row/class counts. Gain separation means each best gain and
each compared frontier priority differs from its alternatives and the threshold
by more than `1e-9 * max(1, |best gain|)`. P3: shared kernels compute classifier
weighted counts, impurity, probabilities and importances and regressor node
impurity from sorted node targets, so these recorded values and pruning paths are
bit-identical under equal structure. P4: regressors retain their respective leaf
mean arithmetic; predictions agree within `1e-12 * max(1, |a|)` under equal structure.

### Tree class-axis rule

Direct classifier fits use sorted observed labels; worker fits use sorted declared
labels, retaining zero slots for absent classes. For `n` rows, class count `c_k`
and `P` present classes, balanced weight is `n / (P * c_k)` for `c_k > 0`,
and 1 otherwise. Records resolve each original-label key to its declared or observed
class, defaulting to 1. A declared but absent class may be named in a record.
Parity above requires equal axes. Weighted totals, impurity and probabilities use
one weight multiplication per class; row minimums remain unweighted.

Positive finite input weights whose derived products or totals overflow fail fits
with `TrainingError('numerical-failure')`; invalid or overflowing saved statistics
fail hydration with `TrainingError('invalid-request')`. An underflowed probability
of zero contributes zero to entropy rather than `NaN`.

### Pruning path rule

For node `t`, `R(t) = (W_t / W_root) * impurity_t`; subtree risk sums child risks
left first. Each step collapses the internal node with minimum
`max(0, (R(t) - R(T_t)) / (leaves(T_t) - 1))`, breaking ties by the lowest
pre-order index. Entry zero describes the returned fit; subsequent entries record
the running maximum alpha, total leaf risk and strictly decreasing leaf count,
ending at one. Alphas may repeat, including zero. `ccpAlpha: 0` applies no pruning;
positive alpha applies the prefix with recorded alpha at most that value. A pruned
fit reports the suffix of leaf counts and risks from its returned tree, with alphas
restarted at zero. Poisson regressor alphas are twice scikit-learn's half-deviance
alphas. Best-first growth and pruning still return nodes in left-first pre-order.

## Naive Bayes

| Member                    | Models                         | Meaning                                                                                          |
| ------------------------- | ------------------------------ | ------------------------------------------------------------------------------------------------ |
| `classLogPrior_`          | `MultinomialNB`, `BernoulliNB` | `NumericTensor` `[K]` in `classes_` order: the stored `log(prior + 1e-15)` used by prediction.   |
| `featureLogProb_`         | `BernoulliNB`                  | `NumericTensor` `[K, p]`: `log((N_cj + alpha) / (N_c + 2 alpha))`, the presence log probability. |
| `predictJointLogProba(X)` | all three                      | `NumericTensor` `[n, K]`: the unnormalised joint log-likelihood.                                 |

`prior` follows `classPrior`, otherwise `fitPrior` (empirical) or uniform; for empirical and
uniform priors `sum exp(classLogPrior_) = 1` within `1e-12`.

Joint log-likelihood of class `c`:

- GaussianNB: `log(classPrior_[c] + 1e-15) + sum_j (-0.5 log(2 pi var_cj) - (x_j - theta_cj)^2 / (2 var_cj))`.
  User-supplied `priors` are used unnormalised, so the base term is the model's own
  `log(prior + 1e-15)`.
- MultinomialNB: `classLogPrior_[c] + sum_j x_j featureLogProb_[c][j]`; negative input throws.
- BernoulliNB: `classLogPrior_[c] + sum_j (x_j > binarize ? featureLogProb_[c][j] : log(1 - exp(featureLogProb_[c][j])))`,
  using the stored negative term. The constructor maps `binarize: null` to `0`, and contributions
  follow that implemented behaviour.

Row-wise softmax of `predictJointLogProba` equals `predictProba` within `1e-12`, and
`predict`, `predictProba` and `predictJointLogProba` share one score routine. A matrix with the
wrong column count throws `Error('X has N features, but <Model> is expecting M features.')` from
every method.

## Logistic regression

`decisionFunction(X): NumericTensor` returns `intercept_k + sum_j coef_kj x_j`, summed from the
intercept in ascending `j` in Float64. Binary models give shape `[n, 1]`, the score for
`classes_[1]`; multiclass one-vs-rest and multi-label models give `[n, K]` in `classes_` order.
It does not apply the configured or tuned decision threshold.

`sigmoid(decisionFunction)` equals the matching `predictProba` column within `1e-7`, and for
non-multi-label multiclass the row argmax equals `predict`.

`predict`, `predictProba` and `decisionFunction` check the column count before any backend call:
a model that is not fitted throws the usual unfitted `Error`; a matrix whose column count `q`
differs from the coefficient column count `p` throws
`Error('X has <q> features, but LogisticRegression is expecting <p> features.')`. Valid inputs
are unaffected. SVC `decisionFunction` stays pairwise one-vs-one.

## Feature contributions

```ts
type ContributionModel = GaussianNB | MultinomialNB | BernoulliNB | LogisticRegression;

interface FeatureContributions {
	readonly score: 'joint-log-likelihood' | 'decision-function';
	readonly rowCount: number;
	readonly featureCount: number;
	readonly columnLabels: readonly ClassificationLabel[];
	readonly values: Float64Array;
}

function featureContributions(model: ContributionModel, X: MatrixLike): FeatureContributions;
```

`columnLabels` has one label per score column: `classes_` for Naive Bayes and for multiclass or
multi-label logistic regression, and `[classes_[1]]` for binary logistic regression. With
`C = columnLabels.length` and `T = featureCount + 1`, `values[(row * C + c) * T]` is the base term
and `values[(row * C + c) * T + 1 + j]` is the term for input column `j`.

The base and feature terms are exactly the summands of `predictJointLogProba` (Naive Bayes) or
`decisionFunction` (logistic regression) in the same order, so their left-to-right sum reproduces
those outputs **bit for bit**. For Naive Bayes the column argmax of the sums equals `predict`. A
BernoulliNB column that is absent contributes its stored negative log probability.

Errors: a model that is not one of the four classes throws `TypeError` naming the supported
models; an unfitted model or invalid `X` throws the model's own prediction error; a layout of
`rows * C * T` elements that is not a safe integer or exceeds `2 ** 31 - 1` throws `RangeError`
before allocating. Memory is `8 * rows * C * T` bytes.

## MLP validation loss

`MLPClassifier` and `MLPRegressor` accept `validationFraction?: number | null` (default `null`).
A value must be finite and strictly between 0 and 1: the constructor throws a plain `Error` and the
worker path rejects with `invalid-request` otherwise.

When set, the fit's rows are split before training:

- Classifiers use `stratifiedTrainTestSplit` with `testRatio: validationFraction` and
  `randomState ?? 0`, so its `TrainingError`s (such as a class with one row) propagate.
- Regressors take `nVal = ceil(validationFraction * n)` rows, require `1 <= nVal <= n - 1`
  (otherwise `invalid-request`, a plain `Error` on the direct path) and select them with a
  seeded Fisher-Yates shuffle seeded with `randomState ?? 0`.

Both index sets are ascending, and the split is reproducible even when weight initialisation is
not. The model trains exactly as before on the training rows only (they define the class
encoding, divisors and worker shards), so the fit equals a fit without `validationFraction` on
those rows alone. At each epoch, before the optimizer update, the validation loss is the same
training objective evaluated on the validation rows with the same pre-update parameters, divided
by `nVal` (classifier) or `nVal * targetCount` (regressor). The worker path evaluates it by
dispatching `mlp-gradient` on validation shards and discarding the gradients; the direct path uses
its own loss routine.

- `validationLossCurve_: number[] | null` has the same length as `lossCurve_`, entry `i` aligned
  with `lossCurve_[i]`.
- `bestEpoch_: number | null` is the first index of the minimum finite entry, or `null` when none
  is finite. Both are `null` without `validationFraction`.
- The stop rule, `nIter_`, `TrainingLossItem` history and returned weights are unchanged. The fitted
  model keeps its **final** weights, `tol` keeps monitoring the training objective, and
  `bestEpoch_` is informational. `earlyStopping`, `nIterNoChange`, best-weight restoration and L2
  `alpha` remain unsupported.
- Portable state gains `validationLossCurve`; a state without it hydrates as `null`. The worker
  `MLPClassifierTrainingResult` and `MLPRegressorTrainingResult` carry an optional
  `validationLossCurve`, present only when `validationFraction` is set.
- A run resumed from a checkpoint rejects `validationFraction` (`invalid-request`).

**Determinism.** Two fits with equal inputs, options and `randomState` on the same path and
runtime give bit-identical `lossCurve_` and `validationLossCurve_`. The worker and direct paths use
separate optimizers and reductions and are not required to agree. The worker summation order
depends on its shard count, `min(4, hardwareConcurrency - 1, ceil(n / 1024))`, so worker curves are
repeatable on one runtime but can differ across machines.

**Preprocessing note.** The internal split is taken from the fit's input after any tabular
preprocessing, so imputation and scaling statistics (including min-max) are learned from rows that include the
validation share. Callers who need a strictly unseen holdout use the evaluation entry points.

## Permutation importance

```ts
type PermutationImportanceScoring = ClassificationScoring | RegressionScoring;

interface PermutationImportanceData {
	readonly features: MatrixLike;
	readonly targets: readonly ClassificationLabel[] | VectorLike;
}

interface PermutationImportanceOptions {
	readonly scoring: PermutationImportanceScoring;
	readonly nRepeats?: number; // integer >= 1, default 5
	readonly randomState?: number; // finite, default 0
	readonly classLabels?: readonly ClassificationLabel[];
	/**
	 * Columns permuted together, one permutation unit per group, in result order. Each group is a
	 * non-empty array of model-input column indices in `[0, featureCount)`; no column may appear in
	 * more than one group or twice in one group. Columns in no group are never permuted.
	 * Default: each column is its own unit, in column order.
	 */
	readonly featureGroups?: readonly (readonly number[])[];
	/**
	 * One unsigned 32-bit integer key per unit (per group, or per column without `featureGroups`)
	 * seeding that unit's permutation stream instead of its position. Default: the unit's position.
	 * Equal keys share a stream, as does one pair of distinct keys per `randomState` (keys 0 and
	 * 4294967295 when `randomState` is 0); see the specification.
	 */
	readonly groupKeys?: readonly number[];
	readonly signal?: AbortSignal;
}

interface PermutationImportanceResult {
	readonly scoring: PermutationImportanceScoring;
	readonly baselineScore: number;
	readonly featureCount: number; // model-input columns
	readonly groupCount: number; // permutation units: featureGroups.length, or featureCount without it
	readonly nRepeats: number;
	readonly importancesMean: Float64Array; // length groupCount
	readonly importancesStd: Float64Array; // length groupCount, population standard deviation
	readonly importances: Float64Array; // groupCount x nRepeats, [g * nRepeats + r]
}

function permutationImportance(
	model: Classifier | Regressor,
	data: PermutationImportanceData,
	options: PermutationImportanceOptions
): Promise<PermutationImportanceResult>;
```

- `features` are in the model's input space. They are copied once into mutable row arrays and
  passed to the model's synchronous `predict`; inputs are never mutated. At least one row, finite
  values and a target length equal to the row count are required, otherwise `RangeError`.
- The classifier scorer set is `ClassificationScoring`; regressors use `RegressionScoring`.
  These are the supervised tuning catalogue, with the same task and target-domain rules.
  The axis is `classLabels ?? model.classes_`; binary-only scorers require exactly two
  labels and use entry 1 as positive. For newly accepted classifiers, the axis must be
  distinct and contain every fitted class and target label. A missing fitted class gives
  `RangeError("classLabels must contain every fitted class; '<label>' is missing.")`;
  an off-axis target gives `RangeError("Target label '<label>' is not in the class axis.")`.
  A declared but unfitted label is allowed and receives a zero probability column.
- Probability columns are aligned from `classes_` to the axis. `log-loss`, `brier-score`
  and ranking without eligible binary SVC margins require probabilities; otherwise, before
  prediction, they throw `RangeError("Scoring '<scorer>' requires class probabilities, which this model does not provide.")`.
  Binary SVC without calibration uses decision margins towards axis entry 1 only when both
  axis labels were fitted; multiclass ranking requires probabilities. Each probability scorer
  calls `predictProba` once per evaluation, costing roughly K times the label path for K classes.
- Logarithmic regression scorers reject negative targets with
  `RangeError("Scoring '<scorer>' requires non-negative targets.")`. Other unavailable scores
  throw `RangeError("Scoring '<scorer>' is unavailable: <reason>.")`.
- A classifier's `predict` must return one label per row. A regressor's must return one value per
  row, shape `[n]` or `[n, 1]` (a single-target `MLPRegressor` returns `[n, 1]`). Any other shape,
  including a multi-output regressor's `[n, T]` with `T > 1`, rejects with `RangeError` stating that
  only single-output predictions are supported. The check runs on the baseline prediction, so a
  rejected model is called exactly once.
- A permutation unit is one supplied `featureGroups` group, or one column by default. In each
  repeat one row order is shared by every column in the unit, then the unit is restored. Columns
  outside the supplied groups are never shuffled. `groupCount` is the number of units, and results
  are indexed in group order. Without either option the existing results and prediction calls are
  unchanged and `groupCount === featureCount`. A tabular source's one-hot, indicator or datetime
  outputs can be measured together by grouping `outputColumns[i].sourceIndex`.
- A unit's importance is `baseline - permuted` for higher-is-better scorers and
  `permuted - baseline` for lower-is-better scorers. Unchanged scorer outputs give exactly zero.
  Unit `g` has one xorshift32 stream seeded `((randomState ?? 0) | 0) ^ Math.imul(k + 1, 0x9e3779b9)`,
  where `k = groupKeys?.[g] ?? g`. Each repeat shuffles a fresh identity order with Fisher–Yates.
  For a unit with key `k`, the permutation applied in repeat `r` is a function of only `randomState | 0`, `k`, `r` and the row count. It does not depend on the model, the scorer, the targets, the columns in the unit, the other units, the unit's position or `nRepeats` (for any `nRepeats > r`). Two calls that share `randomState | 0`, a key and the row count therefore apply identical permutations to the units with that key in every common repeat. Units with equal keys in one call receive identical permutations. Distinct keys have distinct streams with exactly one exception per `randomState`: the two keys `k` for which `((randomState | 0) ^ Math.imul(k + 1, 0x9e3779b9)) >>> 0` is `0` or `0x9e3779b9` share one stream, because the generator replaces a zero seed with `0x9e3779b9` (for `randomState` 0 these are keys `0` and `4294967295`). Distinct streams can still yield equal permutations, since a repeat has only `rowCount!` orderings, so distinct keys are never promised distinct permutations. Without `groupKeys` the key is the unit's position, so ungrouped results equal today's.
- Options are present when `!== undefined`, so `null` rejects. Groups and keys are copied during
  validation before any prediction or signal check, after all other existing validation. All these
  failures are `RangeError`, checked in order:
  1. A non-array or empty `featureGroups`: `featureGroups must be a non-empty array of column groups.`
  2. For each group `g`, a non-array or empty group: `featureGroups[g] must be a non-empty array of column indices.`
     For each index `i`, a non-integer or out-of-range column: `featureGroups[g][i] must be an integer column index in [0, featureCount).`
     A repeated column: `Column column appears in more than one place in featureGroups.` In each message,
     the placeholders are replaced with their actual numeric values.
  3. Non-array `groupKeys` or length unequal to `groupCount`: `groupKeys must have one entry per permutation unit (groupCount).`
  4. For each `g`, a key outside the integers `[0, 4294967295]`: `groupKeys[g] must be an integer in [0, 4294967295].`
- The signal is checked before the baseline, before each permuted evaluation and before resolving,
  and the run yields with `setTimeout(..., 0)` after each evaluation. An aborted signal rejects
  with a `DOMException` named `AbortError` and calls `predict` no further. Errors thrown by `predict`
  reject unchanged.
- Cost: `1 + groupCount * nRepeats` prediction evaluations, one feature copy, plus
  `rowCount × unit width` saved values and one `rowCount` order array per unit.
