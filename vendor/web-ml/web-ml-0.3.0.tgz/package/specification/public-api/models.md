# Model Inventory

This inventory distinguishes models in the current public worker-training API
from ideas carried forward from earlier documentation. `implemented` means
accepted by the current training path; it does not imply that every algorithm
family has identical options or limits. The future entries are proposals, not
commitments. See [Hyperparameters](hyperparameters.md) for supported options, the [machine-readable model specifications](model-specifications/README.md) for JSON projections, and
[Current Limitations](current-limitations.md) for constraints.

## Implemented models

| Model family             | Family ID                  | Model ID                    | Model name                        | Acronym | Task                     | Status      |
| ------------------------ | -------------------------- | --------------------------- | --------------------------------- | ------- | ------------------------ | ----------- |
| Bayesian                 | `bayesian`                 | `bernoulli-nb`              | Bernoulli Naive Bayes             | BNB     | Classification           | implemented |
| Bayesian                 | `bayesian`                 | `gaussian-nb`               | Gaussian Naive Bayes              | GNB     | Classification           | implemented |
| Bayesian                 | `bayesian`                 | `multinomial-nb`            | Multinomial Naive Bayes           | MNB     | Classification           | implemented |
| Distance-Based           | `distance-based`           | `k-neighbors-classifier`    | K-Nearest Neighbors Classifier    | KNN     | Classification           | implemented |
| Distance-Based           | `distance-based`           | `k-neighbors-regressor`     | K-Nearest Neighbors Regressor     | KNN     | Regression               | implemented |
| Linear Models            | `linear`                   | `linear-regression`         | Linear Regression                 | LinReg  | Regression               | implemented |
| Linear Models            | `linear`                   | `logistic-regression`       | Logistic Regression               | LogReg  | Classification           | implemented |
| Linear Models            | `linear`                   | `polynomial-regression`     | Polynomial Regression             | PR      | Regression               | implemented |
| Neural Networks          | `neural-networks`          | `mlp-classifier`            | Multi-layer Perceptron Classifier | MLP     | Classification           | implemented |
| Neural Networks          | `neural-networks`          | `mlp-regressor`             | Multi-layer Perceptron Regressor  | MLP     | Regression               | implemented |
| Support Vector Machines  | `support-vector-machines`  | `support-vector-classifier` | Support Vector Classifier         | SVC     | Classification           | implemented |
| Support Vector Machines  | `support-vector-machines`  | `support-vector-regressor`  | Support Vector Regressor          | SVR     | Regression               | implemented |
| Trees & Ensembles        | `trees`                    | `decision-tree-classifier`  | Decision Tree Classifier          | DTC     | Classification           | implemented |
| Trees & Ensembles        | `trees`                    | `decision-tree-regressor`   | Decision Tree Regressor           | DTR     | Regression               | implemented |
| Clustering               | `clustering`               | `k-means`                   | K-Means                           | —       | Unsupervised learning    | implemented |
| Dimensionality Reduction | `dimensionality-reduction` | `pca`                       | Principal Component Analysis      | PCA     | Dimensionality reduction | implemented |

PCA also supports a `pca-pipeline` training composition: one PCA transformer
followed by one supported supervised estimator. This does not add a general
transformer or arbitrary multi-step pipeline framework.

## Future model proposals

| Model family             | Family ID                  | Model ID                       | Model name                                                  | Acronym | Task                                             | Status                    |
| ------------------------ | -------------------------- | ------------------------------ | ----------------------------------------------------------- | ------- | ------------------------------------------------ | ------------------------- |
| Linear Models            | `linear`                   | —                              | Lasso Regression                                            | —       | Regression                                       | Not implemented; proposal |
| Clustering               | `clustering`               | `dbscan`                       | Density-Based Spatial Clustering of Applications with Noise | DBSCAN  | Unsupervised learning                            | Not implemented; proposal |
| Clustering               | `clustering`               | —                              | Gaussian Mixture Model                                      | GMM     | Unsupervised learning                            | Not implemented; proposal |
| Clustering               | `clustering`               | `hierarchical-clustering`      | Hierarchical Clustering                                     | —       | Unsupervised learning                            | Not implemented; proposal |
| Dimensionality Reduction | `dimensionality-reduction` | `t-sne`                        | t-Distributed Stochastic Neighbor Embedding                 | t-SNE   | 2D/3D visualization                              | Not implemented; proposal |
| Dimensionality Reduction | `dimensionality-reduction` | `umap`                         | Uniform Manifold Approximation and Projection               | UMAP    | Visualization, feature extraction                | Not implemented; proposal |
| Neural Networks          | `neural-networks`          | `convolutional-neural-network` | Convolutional Neural Network                                | CNN     | Image classification, spatial feature extraction | Not implemented; proposal |
| Neural Networks          | `neural-networks`          | `gated-recurrent-unit`         | Gated Recurrent Unit                                        | GRU     | Sequence classification, time-series regression  | Not implemented; proposal |
| Neural Networks          | `neural-networks`          | `long-short-term-memory`       | Long Short-Term Memory                                      | LSTM    | Sequence classification, time-series forecasting | Not implemented; proposal |
| Transformers             | `transformers`             | `bert`                         | Bidirectional Encoder Representations from Transformers     | BERT    | NLP tasks                                        | Not implemented; proposal |
| Trees & Ensembles        | `trees`                    | `gradient-boosted-classifier`  | Gradient Boosting Classifier                                | GBC     | Classification                                   | Not implemented; proposal |
| Trees & Ensembles        | `trees`                    | `gradient-boosted-regressor`   | Gradient Boosting Regressor                                 | GBR     | Regression                                       | Not implemented; proposal |
| Trees & Ensembles        | `trees`                    | `random-forest-classifier`     | Random Forest Classifier                                    | RFC     | Classification                                   | Not implemented; proposal |
| Trees & Ensembles        | `trees`                    | `random-forest-regressor`      | Random Forest Regressor                                     | RFR     | Regression                                       | Not implemented; proposal |
| Vector Space Models      | `vector-space`             | `glove`                        | Global Vectors for Word Representation                      | GloVe   | Word embeddings, semantic similarity             | Not implemented; proposal |
| Reinforcement Learning   | —                          | —                              | Multi-Armed Bandit                                          | —       | Reinforcement learning                           | Not implemented; proposal |
| Reinforcement Learning   | —                          | —                              | Tabular Q-Learning                                          | —       | Reinforcement learning                           | Not implemented; proposal |
| Reinforcement Learning   | —                          | —                              | Deep Q-Network                                              | DQN     | Reinforcement learning                           | Not implemented; proposal |

The former README also listed decision-threshold tuning as a future evaluation
feature. Binary validation-based threshold tuning is now implemented through
`createTrainingClient().train(...)`, `createTuner().search(...)`, and
`nestedCrossValidate(...)`; its multiclass, multi-label, and probability
requirements are documented in [Current Limitations](current-limitations.md).
Cross-validation, hyperparameter tuning, and the metrics currently described in
[Metrics](metrics.md) are implemented.
