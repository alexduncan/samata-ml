# web-ml

`web-ml` is a TypeScript machine-learning library for browser applications.
Training runs asynchronously in Web Workers so it does not block the page;
fitted estimators provide synchronous prediction and inspection.

## Features

- Worker-backed classification, regression, clustering, and dimensionality
  reduction.
- Streamed `Float64Array` training batches with progress events and cancellation. Ordinary requests accept the optional `liveMetrics` flag for model-specific diagnostics.
- Synchronous prediction from the fitted estimator returned by training.
- Pre-training dataset summaries and findings via `diagnoseDataset`.
- Persistent completed training state, Random Search, Hyperband, and nested
  cross-validation.
- TypeScript numerical kernels, model-specific WebAssembly backends, and
  LIBSVM-backed SVC/SVR.

See [supported models](#supported-models), [limitations](#important-limitations),
and the [API reference](docs/index.html).

Machine-readable JSON descriptions for each implemented model are available
through the package's `web-ml/model-specifications` subpaths. See the
[model specifications guide](user-guide/model-specifications.md) for examples.

## Installation

Install from your package manager:

```bash
bun add web-ml
```

```bash
npm install web-ml
```

```bash
yarn add web-ml
```

```bash
pnpm add web-ml
```

### Install from a release tarball

A maintainer-built release is a versioned tarball with a checksum file. Check the
checksum, then install the tarball:

```bash
shasum -a 256 -c web-ml-<version>.tgz.sha256
bun add ./web-ml-<version>.tgz
```

See [Package distribution](specification/public-api/package-distribution.md) for
the package contents, versioning and tarball naming.

Applications do not need to install `numpy-ts`; the published package bundles
its internal TypeScript numerical backend.

## Browser and runtime requirements

Training requires module Web Workers and the Web Locks API. Use a secure context
(HTTPS or localhost). The client prefers a same-origin `SharedWorker` when the
browser can start nested module workers from it; otherwise it uses a dedicated
orchestrator worker for the page. If workers or Web Locks are unavailable,
training fails with an `environment-not-supported` error. There is no
main-thread training fallback.

An exclusive origin-wide lock permits one independent training run at a time
across pages and tabs using web-ml. Compute workers and tuner candidates may run
in parallel inside that active run; nested outer folds run one at a time.

Training input is dense, finite, row-major `Float64Array` data (the opt-in `preprocessing`
option accepts raw codes with `NaN` for missing values; see
[Mixed and incomplete tabular data](#mixed-and-incomplete-tabular-data)). The orchestrator
assembles the full declared dataset in memory before fitting, so streaming batches
does not make training out-of-core. Yield each batch in a fresh owned buffer:
transferring it detaches the feature and target buffers.

IndexedDB is required for persistent training state and hyperparameter tuning.
Shared memory is **strictly required** for performance. To enable it, you must serve the
application as a secure, cross-origin-isolated page with the following headers:

```text
Cross-Origin-Opener-Policy: same-origin
Cross-Origin-Embedder-Policy: require-corp
```

If these headers are missing, `createTrainingClient()` will throw an `environment-not-supported` error and the library will not function.

## Train a model

All model fitting uses `createTrainingClient().train(...)`. The client returns
an event stream and a promise for the hydrated estimator:

```ts
import { createTrainingClient } from 'web-ml';

const run = createTrainingClient().train({
	algorithm: 'linear-regression',
	options: { solver: 'sgd' },
	data: {
		sampleCount: 4,
		featureCount: 1,
		targetCount: 1,
		batches: (async function* () {
			yield {
				rowCount: 4,
				features: new Float64Array([0, 1, 2, 3]),
				targets: new Float64Array([1, 3, 5, 7])
			};
		})()
	}
});

for await (const event of run.events) {
	if (event.type === 'progress') {
		updateProgressBar(event.fraction);
	}
	if (event.type === 'failed') {
		showError(event.error.message);
	}
}

const { model } = await run.result;
const prediction = model.predict([[4]]);
```

The `data` metadata describes the complete sample, feature, and target
dimensions. Batches contain contiguous, owned `Float64Array` buffers.
Classification targets are zero-based numeric class indices; provide
`classLabels` to map those indices to application labels. PCA and K-means use
`targetCount: 0` and omit batch targets.

### LogisticRegression multi-label mode

For multi-label classification, provide a row-major binary indicator target
matrix with one column for each ordered `classLabels` entry. LogisticRegression
uses independent sigmoid outputs and thresholds each label independently; it
does not use a joint softmax. Use `predictMultiLabel()` and
`scoreMultiLabel()` for label sets. The estimator also supports `none`, `l1`,
`l2`, and `elasticnet` penalties with SGD, plus balanced or label-keyed class
weights.

```ts
const run = createTrainingClient().train({
	algorithm: 'logistic-regression',
	classLabels: ['red', 'round', 'ripe'],
	options: { multiLabel: true, penalty: 'elasticnet', l1Ratio: 0.4 },
	data: {
		sampleCount: 4,
		featureCount: 2,
		targetCount: 3,
		batches: (async function* () {
			yield {
				rowCount: 4,
				features: new Float64Array([0, 0, 1, 0, 0, 1, 1, 1]),
				targets: new Float64Array([1, 0, 0, 1, 1, 1, 0, 0, 1, 0, 1, 0])
			};
		})()
	}
});
const { model } = await run.result;
const labels = model.predictMultiLabel([
	[0, 0],
	[1, 1]
]);
```

Pass an `AbortSignal` as the second argument to cancel a queued or active run.
Cancellation rejects `run.result` with an `AbortError`. Progress is scheduled
work rather than an ETA. Other run failures reject with `TrainingError` and a
stable error code. See the [progress events guide](user-guide/progress-events.md).

## Persistent training state

Pass an application-owned `cacheKey` to store a portable completed result in
IndexedDB. On a later page load, `checkTrainingState(cacheKey)` returns
`false`, an incomplete state, or a completed state containing the portable
result and hydrated model.

```ts
const client = createTrainingClient();
const cacheKey = 'my-app/iris-linear-regression-v1';
const cached = await client.checkTrainingState(cacheKey);

if (cached && cached.status === 'completed') {
	showPrediction(cached.model.predict([[4]]));
} else {
	const request = makeTrainingRequest(); // Create fresh owned batch buffers.
	const run =
		cached?.status === 'incomplete'
			? cached.resume(request)
			: client.train(request, { cacheKey });
	const { model } = await run.result;
	showPrediction(model.predict([[4]]));
}
```

The key is not derived from streamed data; include your application, dataset, and
model version in it. The cache stores request metadata and portable model state,
not input batches. Resuming an incomplete state starts training again from the
beginning with a new batch stream; it does not restore an optimizer iteration.
Completed and incomplete states expose `clear()`. Intentional cancellation
clears the incomplete marker; unexpected failure or page shutdown leaves it for
inspection. Cache writes are best effort and do not fail training, while
`checkTrainingState()` and `clear()` reject when storage cannot be read or
changed. Browser eviction may remove entries.

## Hyperparameter tuning

`createTuner().search(...)` runs candidates through the same worker-backed
training path. Provide separate training and validation data so candidate scores
are measured on rows that were not used for fitting.

Binary threshold tuning uses the same `thresholdTuning` option shape in all
three public tuning APIs: `createTrainingClient().train(...)` with an
`algorithm: 'hyperparameter-tuning'` request, `createTuner().search(...)`, and
`nestedCrossValidate(...)`. For the direct training-client request, see the
[training guide](user-guide/training.md). Ordinary classifier `.train(...)`
requests do not tune a threshold; they fit one model without a validation
search. Each tuning request can set `thresholdTuning: { positiveLabel }`, where
`positiveLabel` is optional and defaults to the second configured class label.

```ts
import { createTuner } from 'web-ml';

const run = createTuner().search({
	algorithm: 'logistic-regression',
	trainingData,
	validationData,
	classLabels: ['negative', 'positive'],
	searchSpace: {
		learningRate: { kind: 'log-uniform', min: 0.001, max: 0.1 },
		C: { kind: 'log-uniform', min: 0.1, max: 10 }
	},
	scoring: 'f1',
	thresholdTuning: { positiveLabel: 'positive' },
	strategy: { kind: 'random-search', nTrials: 24, randomState: 7 },
	maxWorkers: 4
});

for await (const event of run.events) {
	if (event.type === 'tuning-progress') {
		updateSearchProgress(event.trialsCompleted, event.totalTrials);
	}
}

const result = await run.result;
const bestClassifier = result.bestModel;
console.log('Selected cutoff:', result.bestDecisionThreshold);
```

Random Search supports the estimators accepted by the training client.
Resumable Hyperband supports SGD/Adam LinearRegression and
PolynomialRegression, SGD/Adam/L-BFGS/coordinate descent LogisticRegression, and
SGD/Adam MLPClassifier and MLPRegressor. OLS remains the ordinary
Linear/Polynomial default and is excluded from Hyperband; if their Hyperband
request omits `solver`, the tuner starts with SGD. Tuning requires IndexedDB. Built-in scorers
include accuracy, binary F1, log loss, R², mean squared error, validation inertia
for K-means, and reconstruction error for PCA. Set `thresholdTuning` with
accuracy or F1 to select a cutoff from validation probabilities; the returned
`bestModel.predict()` uses and serializes that cutoff. This option supports
single-label binary classification. Multiclass and multi-label cutoff policies
are not inferred. SVC requires `probability: true`. Custom scorer callbacks are
not supported. See the [progress events guide](user-guide/progress-events.md) and
[timing guide](specification/public-api/timing.md).

Hyperband measures resource in solver iterations: one SGD/Adam update, one
accepted L-BFGS step including line search, or one full coordinate sweep.
`maxResource` is the maximum, `minResource` defaults to 1, `eta` to 3, and rung cooldown to 100 ms. Tuning
defaults `maxWorkers` to one fewer than reported logical cores (at least one).
Its estimated memory budget defaults to 128 MiB when device memory is unavailable,
otherwise to the smaller of 256 MiB and 10% of reported device memory; set
`memoryBudgetBytes` to override it. The estimate can reduce candidate
concurrency, and a single estimated trial that exceeds the budget fails before
workers start. A search is capped at 100,000 scheduled trial evaluations.
Hyperband checkpoints portable model and optimizer state in IndexedDB and
removes run data on completion, failure, or cancellation. Trial summaries expose
`durationMs`; solver iterations have different costs, so compare solver choices
with elapsed time as well as validation score.

## Fixed-option cross-validation

`crossValidate` evaluates fixed options using held-out folds and always returns
pooled out-of-fold diagnostics. Set `refit: true` to fit one final model on all
rows; the caller owns it and must dispose SVC/SVR refits when finished.

```ts
import { ArrayDatasetProvider, crossValidate } from 'web-ml';

async function evaluate() {
	const data = new ArrayDatasetProvider(
		6,
		1,
		1,
		new Float64Array([1, 2, 3, 4, 5, 6]),
		new Float64Array([3, 5, 7, 9, 11, 13])
	);
	const result = await crossValidate({
		algorithm: 'linear-regression',
		data,
		folds: 3,
		scoring: 'r2',
		options: { solver: 'ols' },
		randomState: 7,
		refit: true
	}).result;
	console.log(result.meanScore, result.diagnostics.residuals, result.refit?.model.predict([[7]]));
}
void evaluate();
```

Use `diagnoseModel` with a separate held-out provider for the same diagnostics
from an ordinary fitted model; classifiers require `classLabels` in target
encoding order. See [out-of-sample diagnostics](specification/public-api/metrics.md#out-of-sample-diagnostics).

## Comparing models

`bayesianCorrelatedTTest` and `correctedResampledTTest` compare two models from paired per-partition
cross-validation scores. They are pure and synchronous, so they need no worker. Results are stated on
`A - B`: `probabilityHigher` is the posterior probability that A's expected score exceeds B's by more than
`rope`. Neither `rope` nor `testFraction` has a default.

```ts
import { bayesianCorrelatedTTest } from 'web-ml';

const scoresA = [0.82, 0.79, 0.85, 0.81, 0.84, 0.8, 0.83, 0.86, 0.78, 0.82];
const scoresB = [0.8, 0.78, 0.81, 0.8, 0.82, 0.79, 0.8, 0.83, 0.79, 0.8];

// Ten-fold cross-validation: each partition tests one tenth of the rows.
const result = bayesianCorrelatedTTest(scoresA, scoresB, { rope: 0.01, testFraction: 0.1 });
console.log(result.probabilityLower); // about 0.0009147
console.log(result.probabilityEquivalent); // about 0.1214
console.log(result.probabilityHigher); // about 0.8777
```

See [Cross-validated model comparison](specification/public-api/model-comparison.md).

## Nested cross-validation

`nestedCrossValidate(...)` estimates tuned-model performance using inner folds
for selection and untouched outer folds for scoring. Classifier folds are
stratified; regressor folds are seeded and shuffled. The utility accepts
row-major typed arrays and leaves the caller's source arrays usable.

```ts
import { nestedCrossValidate } from 'web-ml';

const run = nestedCrossValidate({
	algorithm: 'logistic-regression',
	features,
	targets,
	sampleCount,
	featureCount,
	targetCount: 1,
	outerFolds: 5,
	innerFolds: 3,
	classLabels: ['negative', 'positive'],
	searchSpace: {
		learningRate: { kind: 'log-uniform', min: 0.001, max: 0.1 }
	},
	scoring: 'accuracy',
	thresholdTuning: { positiveLabel: 'positive' },
	strategy: { kind: 'random-search', nTrials: 16, randomState: 7 },
	randomState: 12,
	includeMetrics: true
});

for await (const event of run.events) {
	if (event.type === 'outer-fold-complete') {
		showFoldScore(event.foldIndex, event.score);
	}
}

const estimate = await run.result;
showMeanScore(estimate.meanScore, estimate.standardDeviation);
```

Candidates are scored across all inner folds before selection; the selected
candidate is refit on all outer-training rows. Outer folds run sequentially.
Nested cross-validation supports supervised models accepted by the tuner, except
PCA and K-means, including LogisticRegression multi-label mode. Classification
and regression selection use the scorer catalogue in
[Metrics](specification/public-api/metrics.md#tuning-scores). Binary threshold
tuning selects cutoffs inside inner folds and scores them on untouched outer
folds. Unsupervised algorithms and custom scoring callbacks are not supported. See
[nested-CV result details](docs/interfaces/NestedCrossValidationResult.html).
Set `includeMetrics: true` for each outer-fold report and a pooled report in
source-row order; `completeMetrics` adds ranking and median absolute error.
Unavailable fields include a reason, such as negative targets for RMSLE.

## Class weights, priors and cutoffs

Class-label options are matched by the **original label**. A `classWeight` record
(`LogisticRegression`, `SVC` and `DecisionTreeClassifier`) needs one key per class you want to weight, spelled `String(label)`, with
a positive finite weight. Naive Bayes priors align with the distinct **observed** labels of the fitting
rows in portable order (booleans, then numbers ascending, then strings by UTF-16 code units), so
fitting the labels `10` and `2` with `[0.8, 0.2]` gives label `2` the prior `0.8`. A fixed binary
logistic `threshold` compares the second `classLabels` entry's probability with `>=`.

```ts
import { ArrayDatasetProvider, createTrainingClient } from 'web-ml';

const client = createTrainingClient();
const data = () =>
	new ArrayDatasetProvider(
		6,
		1,
		1,
		Float64Array.from([0, 1, 2, 5, 6, 7]),
		Float64Array.from([0, 0, 0, 1, 1, 1])
	);

const weighted = client.train({
	algorithm: 'logistic-regression',
	classLabels: ['blue', 'red'],
	options: { classWeight: { blue: 2 } }, // 'red' keeps weight 1
	data: data()
});
const bayes = client.train({
	algorithm: 'gaussian-nb',
	classLabels: [10, 2],
	options: { priors: [0.8, 0.2] }, // observed axis [2, 10]: 0.8 belongs to label 2
	data: data()
});
const cutoff = client.train({
	algorithm: 'logistic-regression',
	classLabels: ['no', 'yes'],
	options: { threshold: 0.7 }, // probability of 'yes' at or above 0.7 predicts 'yes'
	data: data()
});

const [first, second, third] = await Promise.all([weighted.result, bayes.result, cutoff.result]);
void [first.model.predict([[1]]), second.model.classes_, third.model.predict([[6]])];
```

Unknown or ambiguous weight keys, non-positive weights, and malformed or wrong-length priors fail with
`invalid-request` before any data is read or any solver starts. See the
[LogisticRegression](user-guide/models/logistic-regression.md#class-weights),
[SVC](user-guide/models/support-vector-classifier.md#class-weights) and
[Naive Bayes](user-guide/models/gaussian-nb.md#class-priors) guides for the migration notes.

## Reproducible stratified holdouts

`stratifiedTrainTestSplit` splits encoded class targets into seeded, stratified, ascending train and test
indices. Fixed and nested cross-validation also return the held-out rows of every outer fold as
`validationIndices`, so a comparison between estimators can reuse exactly the same partition.

```ts
import { stratifiedTrainTestSplit, TrainingError } from 'web-ml';

const targets = Float64Array.from([0, 0, 0, 0, 1, 1, 1, 1]);
const { trainIndices, testIndices } = stratifiedTrainTestSplit(targets, {
	testRatio: 0.25,
	randomState: 7
});
// testIndices holds one row of each class. Every row appears once, in ascending order.

try {
	// A class with a single row cannot appear on both sides of a split.
	stratifiedTrainTestSplit(Float64Array.from([0, 0, 0, 1]), { testRatio: 0.5 });
} catch (error) {
	if (!(error instanceof TrainingError) || error.code !== 'invalid-request') throw error;
}
void [trainIndices, testIndices];
```

`checkStratifiedPartition` reports, before any rows are split, whether a holdout (or a fold request) is
feasible for per-class row counts, with the exact limits those counts allow. See
[Checking stratified partition feasibility](user-guide/evaluation.md#checking-stratified-partition-feasibility).

```ts
import { checkStratifiedPartition } from 'web-ml';

const verdict = checkStratifiedPartition([6, 2], { kind: 'holdout', testRatio: 0.25 });
if (!verdict.feasible) throw new Error(verdict.issue.message);
// Safe to call stratifiedTrainTestSplit with the same ratio and class counts.
```

## Mixed and incomplete tabular data

Set the top-level `preprocessing` option and every fit (an ordinary run, each tuning split and each
cross-validation fold) learns per-column imputation, optional indicators, one-hot or ordinal encoding and scaling from **its own**
training rows. The fitted transformer comes back beside the model. See
[tabular preprocessing](specification/public-api/tabular-preprocessing.md) for the full contract.
Datetime columns accept epoch milliseconds and by default expand month and weekday into
sine/cosine pairs plus elapsed days from the fitting partition's earliest imputed instant.

```ts
import { ArrayDatasetProvider, createTrainingClient, encodeTabularFeatures } from 'web-ml';

const rows = [
	[21, 'blue'],
	[35, 'red'],
	[null, 'blue'],
	[48, 'green'],
	[52, 'red'],
	[29, null]
];
const packed = encodeTabularFeatures(rows, [
	{ name: 'age', kind: 'numeric' },
	{ name: 'colour', kind: 'categorical' }
]);

const { model, preprocessor, featureNamesOut, outputColumns } = await createTrainingClient().train({
	algorithm: 'logistic-regression',
	classLabels: ['no', 'yes'],
	preprocessing: { columns: packed.columns },
	data: new ArrayDatasetProvider(
		rows.length,
		2,
		1,
		packed.features,
		Float64Array.from([0, 0, 0, 1, 1, 0])
	)
}).result;

// outputColumns maps every encoded column to its source; featureNamesOut labels it.
const labels = model.predict(
	preprocessor!.transform([
		[40, 'green'],
		[null, 'unseen']
	])
);
void [labels, featureNamesOut, outputColumns];
```

## Supported models

| Task                     | Models                                                                                                                       |
| ------------------------ | ---------------------------------------------------------------------------------------------------------------------------- |
| Classification           | LogisticRegression, MLPClassifier, DecisionTreeClassifier, KNeighborsClassifier, GaussianNB, MultinomialNB, BernoulliNB, SVC |
| Regression               | LinearRegression, PolynomialRegression, MLPRegressor, DecisionTreeRegressor, KNeighborsRegressor, SVR                        |
| Clustering               | KMeans                                                                                                                       |
| Dimensionality reduction | PCA                                                                                                                          |

PCA training resolves to a reusable fitted `PCA` transformer. The
`pca-pipeline` request fits PCA followed by a supervised estimator in the worker
path and returns a model that applies PCA before prediction. The detailed
[model inventory](specification/public-api/models.md) marks unimplemented proposals separately.

```ts
const run = createTrainingClient().train({
	algorithm: 'pca-pipeline',
	pcaOptions: { nComponents: 2, scale: true },
	estimator: { algorithm: 'logistic-regression', classLabels: ['setosa', 'other'] },
	data: trainingData
});
const { model } = await run.result;
const labels = model.predict([[5.1, 3.5, 1.4, 0.2]]);
```

PCA pipelines support Random Search and nested cross-validation. Search paths
use `pca.<option>` and `estimator.<option>`. Pipeline PCA is refitted inside
each training fold. MultinomialNB is not a supported downstream estimator
because PCA scores may be negative.

## Important limitations

- Training is dense and in-memory. Sparse matrices, general-purpose preprocessing
  pipelines, learnt target encodings and online `partialFit` are not provided. The
  only built-in preprocessing is the opt-in, fixed-order tabular transformation
  (per-column imputation, optional indicators, one-hot or ordinal encoding and scaling) fitted inside each fit;
  see [tabular preprocessing](specification/public-api/tabular-preprocessing.md).
  The PCA pipeline is a limited PCA-plus-supervised-estimator composition.
- Prediction is synchronous. Large prediction batches, SVM models, and
  brute-force neighbor searches may need an application-managed worker.
- LinearRegression and PolynomialRegression use squared-error loss with OLS,
  full-batch SGD, or Adam. OLS is the default. Lasso regression is not implemented. Polynomial expansion
  materializes a dense feature matrix.
- Only MLPRegressor supports multiple regression outputs; the other regressors
  require one target per sample.
- LogisticRegression defaults to Adam and supports SGD, L-BFGS, and coordinate
  descent. L-BFGS supports only none/L2 penalties; Adam and coordinate descent
  support all current penalties. Multi-label probabilities are independent
  sigmoid outputs, and multi-label mode is not supported by tuning or nested CV.
- MLP models default to fixed-setting Adam and preserve SGD as an option. They do
  not implement mini-batches, momentum, validation early stopping, gradient
  clipping, or learning-rate schedules.
- K-neighbors defaults to brute-force search and also supports exact KD and Ball trees for certified Euclidean/Manhattan pruning. Cached or JSON-restored trees use exhaustive queries. Decision trees support numeric thresholds and native categorical code-set splits. DecisionTreeRegressor supports squared error, Friedman
  MSE, absolute error, and Poisson; Poisson requires nonnegative targets, and
  absolute-error leaves predict the median.
  Both trees support minimal cost-complexity pruning (`ccpAlpha`, inspected with `costComplexityPruningPath()`), best-first leaf budgets (`maxLeafNodes`) and fractional `minSamplesSplit`/`minSamplesLeaf`; `DecisionTreeClassifier` also accepts `classWeight`.
- PCA exposes synchronous `transform()` and `inverseTransform()` after its
  worker-backed fit, and its versioned state retains the effective feature scales
  needed for new rows. Whitening, randomized/truncated and incremental PCA, and
  automatic component selection remain unsupported.
- SVC and SVR fit one full dataset using LIBSVM. SVC uses one-vs-one
  classification; `predictProba()` requires `probability: true`. Per-sample
  weights, SGD, solver iteration histories, and custom kernels are unsupported.

Numerical details that can affect results:

- Linear and polynomial regression use the same L2 objective for OLS and SGD:
  mean squared error plus `alpha / 2 * ||weights||²`. The learned intercept and
  PolynomialRegression's optional constant bias feature are excluded from the
  penalty. OLS uses a rank-aware QR solve.
- Distance-weighted K-neighbors gives weight only to exact matches when a
  selected neighbor has zero distance; otherwise it uses inverse distance.
- K-means uses seeded k-means++ initialization and relative convergence
  tolerance. If there are fewer distinct data points than requested clusters,
  duplicate centers can remain empty.
- PCA rejects non-finite inputs, requires centering when scaling, uses guarded
  unit scales for constant features, and returns components with a deterministic
  sign convention. Pipeline Random Search and nested CV fit PCA only on the
  corresponding training partition.
- GaussianNB applies a variance floor even when `varSmoothing: 0`. Unsmoothed
  BernoulliNB and MultinomialNB can produce negative-infinite log likelihoods;
  their current JSON text round-trip does not preserve those values.

See [Current Limitations](specification/public-api/current-limitations.md) and
[Hyperparameters](specification/public-api/hyperparameters.md) for detailed option and
numerical behavior.

## Deployment requirements

The browser package includes multiple worker and WebAssembly assets. Configure
your bundler or static deployment so it preserves the module URLs exported by
`web-ml` and keeps these files available beside the package entrypoint:

| Asset group      | Files                                                                                                                                                                                                                                                                  |
| ---------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Orchestrators    | `training-orchestrator.js`, `training-orchestrator-dedicated.js`                                                                                                                                                                                                       |
| Capability probe | `training-worker-probe.js`                                                                                                                                                                                                                                             |
| Compute workers  | `training-worker-linear.js`, `training-worker-logistic.js`, `training-worker-mlp.js`, `training-worker-clustering.js`, `training-worker-pca.js`, `training-worker-tree.js`, `training-worker-neighbors.js`, `training-worker-naive-bayes.js`, `training-worker-svm.js` |
| WebAssembly      | `wasm/linear-regression.v2.wasm`, `wasm/logistic-regression.v1.wasm`, `wasm/libsvm.js`, `wasm/libsvm.wasm`                                                                                                                                                             |

Bundling only `dist/index.js` is insufficient. The orchestrators resolve
compute workers relative to their own URLs, and model modules resolve their
WebAssembly assets relative to the package. Cross-origin isolation headers are
needed only for shared-memory optimizations; Web Locks and workers remain
required for training.

For SVC/SVR build details and native ownership constraints, read the
[SVM specification](specification/internals/svm.md).

## Migration from synchronous fitting

Synchronous estimator `fit()` and the standalone synchronous
`principalComponentAnalysis()` export are not part of the current API. Replace:

```ts
const model = new LinearRegression({ solver: 'sgd' });
model.fit(X, y);
```

with a streamed training request:

```ts
const run = createTrainingClient().train({
	algorithm: 'linear-regression',
	options: { solver: 'sgd' },
	data: {
		sampleCount: 2,
		featureCount: 1,
		targetCount: 1,
		batches: (async function* () {
			yield {
				rowCount: 2,
				features: new Float64Array([0, 1]),
				targets: new Float64Array([1, 3])
			};
		})()
	}
});
const { model } = await run.result;
```

The ordinary `run.result` object contains a hydrated `model` for synchronous
prediction. This result wrapper is a breaking change from the former direct
estimator result; tuning results retain their existing shape. For a portable
result stored outside the client flow, use the asynchronous
`hydrateTrainingResult(request, storedResult)` API.

## Contributing

Bug fixes, especially numerical correctness and edge-case fixes, are welcome and
valued. You can make a meaningful contribution without adding an algorithm:
regression tests, browser compatibility fixes, clearer errors, and documentation
improvements all help. See [CONTRIBUTING.md](CONTRIBUTING.md) for local setup,
the specification-driven workflow, and pull request requirements.

## Documentation

- [API reference](docs/index.html)
- [Progress events](user-guide/progress-events.md)
- [Model inspection](user-guide/model-inspection.md)
- [Training timing](specification/public-api/timing.md)
- [Specifications and contributor requirements](specification/README.md)

The specification directory is the authoritative source for intended behavior
and implementation requirements. The former development roadmap is preserved as
status information in [Roadmap Proposals](specification/internals/roadmap.md).

## License

This project is licensed under the Apache License, Version 2.0. See [LICENSE.md](LICENSE.md) for the full license text.

`web-ml` includes third-party software:

- **LIBSVM**: Copyright (c) 2000–2023 Chih-Chung Chang and Chih-Jen Lin (3-Clause BSD License; see [`src/models/support-vector-machines/vendor/libsvm/COPYRIGHT`](src/models/support-vector-machines/vendor/libsvm/COPYRIGHT)).
