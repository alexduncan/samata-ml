# Tabular preprocessing

This is the consumer-facing contract for the opt-in tabular transformation that every fit learns
from its own training rows. It covers raw packing, the fit and apply rules, the fitted transformer
and its portable state, where the result appears on each entry point, and the failure modes. The
transformation is deliberately small: imputation, optional standardisation and one-hot encoding in
a fixed order. It is not a general preprocessing framework, and it does not change dense training,
which still rejects every non-finite feature. See
[Hyperparameters](hyperparameters.md) for estimator options, [Metrics](metrics.md) for reports, and
[Current limitations](current-limitations.md) for the surrounding constraints.

## Source codes and raw packing

A request that sets `preprocessing` carries **raw codes** in its existing `DatasetProvider` or
`TrainingData` sources. Each source column is numeric or categorical:

```ts
type TabularColumn =
	| { readonly name: string; readonly kind: 'numeric' }
	| {
			readonly name: string;
			readonly kind: 'categorical';
			readonly categories: readonly ClassificationLabel[];
	  };
```

`encodeTabularFeatures(rows, columns)` is a lossless source-packing convenience for observed values.
It returns caller-owned row-major `features` and the complete transport `columns`.

- A numeric cell is copied. `null` and `NaN` are missing; every other value must be a finite number.
- A categorical cell becomes the position of its label in the column's transport dictionary. `null`
  is missing. Labels are finite strings, finite numbers or booleans, with type-sensitive identity:
  `true`, `'true'`, `2` and `'2'` are four different categories. `-0` and `0` are the same
  category.
- A column without a dictionary receives first-seen codes. A supplied dictionary is copied, and
  duplicate or invalid entries are rejected.
- A literal that is absent from a **supplied** dictionary becomes `-1`, meaning unknown. That sentinel
  is valid only when applying an already fitted transform. A fit that contains it fails with
  `invalid-request`.
- No frequency, mode, scale, one-hot axis or target enters this operation. Nothing is coerced or
  trimmed.

Set the request's top-level `preprocessing` to `{ columns: encoded.columns, standardize?: boolean }`.
Every source in the request shares those transport dictionaries. For separately packed held-out data,
pass the returned `encoded.columns` to `encodeTabularFeatures` again. Missing values of either kind
travel as `NaN`. An unused dictionary entry has no influence on the fitted state.

A provider that fills its destination in place must write every cell. The library marks unwritten
cells with positive infinity before calling the provider and rejects any that remain, so a provider
that forgets a cell cannot silently produce a `0` or a missing value.

## Where the option belongs

`preprocessing` belongs to the outermost request: `client.train` (including a direct tuning
request), `createTuner().search`, `crossValidate` and `nestedCrossValidate`. In a PCA pipeline the
order is raw rows, then the frozen tabular transform, then PCA, then the supervised estimator.
`PCAPipelineEstimatorRequest` omits `preprocessing`, and the union is intersected with
`{ readonly preprocessing?: never }`, so a literal or a variable carrying a second schema fails
assignment. An untyped caller that supplies an own `preprocessing` property on the embedded
estimator, even with the value `undefined`, receives `invalid-request` before any source is read.

Raw schema checks use the source width. PCA component counts are checked against each fit's
**encoded** width, and the downstream estimator against its PCA projection width. A valid encoded
component count may therefore exceed the raw column count. Class labels, target shape and split
identities use the original rows throughout.

## Fit and apply rules

Statistics are learnt in source-column order from the fitting rows only:

- **Numeric.** Missing values are imputed with the mean of the observed fitting values. With
  `standardize: true` the column is centred and divided by the population standard deviation
  (`ddof = 0`) over all imputed fitting rows, using scale `1` for a constant column. The default
  is `standardize: false`.
- **Categorical.** The vocabulary is the observed fitting categories in `compareClassificationLabels`
  order: booleans (`false`, `true`), then finite numbers ascending, then strings by UTF-16 code units.
  The mode is the most frequent observed category, with ties broken by that order. Missing values
  take the mode. One unscaled 0/1 column is emitted per observed category in that order.
- An entirely missing fitting column of either kind fails with `invalid-request`, naming the source
  column and the fold or partition. Non-finite computed statistics fail with `numerical-failure`.

When the learnt state is applied, a missing cell takes the mean or the mode. A category that was never
seen while fitting, whether it is a valid code the fit did not use or a literal that is not in the
dictionary, produces an all-zero indicator block and never widens the fit.

`featureNamesOut` lists the emitted features in order. A numeric feature is `JSON.stringify([name])`
and an indicator is `JSON.stringify([name, category])`, so names decode to the exact source column and
category type. For source columns `age, colour` and observed colours `blue, red` the names are
`['["age"]','["colour","blue"]','["colour","red"]']`. Names describe the input to the estimator, or to
PCA, before any estimator-internal expansion.

### Finite features

Every emitted feature must be finite. If a valid finite input produces a non-finite feature, for
example a standardiser fitted on `[0, 1]` (mean and scale `0.5`) applied to `Number.MAX_VALUE`, the
operation raises `TrainingError` with code `numerical-failure`, identifying the source column and,
where available, the fold. The check covers training features, ordinary validation, tuning holdouts,
outer cross-validation scoring and synchronous inference, including after restoration. Nothing reaches
PCA, a solver or a prediction, and no partial tensor, metric or winner is returned. A raw infinity
supplied by the caller is `invalid-request`.

## The fitted transformer and its portable state

```ts
interface FittedTabularPreprocessorState {
	readonly version: 1;
	readonly standardize: boolean;
	readonly columns: readonly (
		| {
				readonly kind: 'numeric';
				readonly name: string;
				readonly mean: number;
				readonly scale: number;
		  }
		| {
				readonly kind: 'categorical';
				readonly name: string;
				readonly mode: ClassificationLabel;
				readonly categories: readonly ClassificationLabel[];
		  }
	)[];
}
```

`FittedTabularPreprocessor` is exported from the package root.

- `toJSON()` returns a fresh version-1 snapshot. Numeric columns store scale `1` when standardisation is
  off. Categorical columns store the mode and the observed vocabulary.
- `FittedTabularPreprocessor.fromJSON(state)` validates and copies a snapshot: the version, types,
  finite numbers, positive scales, unique nonempty source names, nonempty sorted unique vocabularies
  and mode membership. Invalid input raises `invalid-request`. Mutating a snapshot or its parsed input
  afterwards cannot change the live transformer.
- `featureNamesOut` is derived from those columns.
- `transform(rows)` is synchronous. It accepts literal categories, including unseen ones, and returns
  an owned two-dimensional tensor. Pass it to a fitted model and dispose it after prediction.

## Where the result appears

| Surface                                                                                 | Opt-in result                                                                                                                                                                                                                                                              |
| --------------------------------------------------------------------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Every concrete member of `FittedTrainingResult`                                         | `preprocessorState?: FittedTabularPreprocessorState`, stored once on the outer fitted result. For a PCA pipeline this is the pipeline's field; its PCA and estimator child payloads omit it.                                                                               |
| Tuning `TrainingResult`                                                                 | `result.bestResult.preprocessorState` is the winner's snapshot. An explicit holdout returns the training-only winner. An inner-fold search returns the winner refitted on all search-training rows. The tuning envelope carries no second copy.                            |
| Hydrated `FittedRun`, `TuningResult`, `CrossValidationRefit` and `HoldoutValidationFit` | `preprocessor?: FittedTabularPreprocessor` and `featureNamesOut?: readonly string[]`, both present for an opt-in fit. `model` and `bestModel` keep consuming encoded features.                                                                                             |
| `checkTrainingState` with `status === 'completed'`                                      | The same two properties, restored from `result.preprocessorState` (or `result.bestResult.preprocessorState` for tuning) without reading any source or refitting.                                                                                                           |
| Fixed and nested CV folds                                                               | `featureNamesOut?` describes that fold's own fit, so folds can have different axes. The fixed-CV full-data refit returns its own transformer and names. `holdoutValidate` with `returnFit` returns the transformer fitted on the training partition only, in `result.fit`. |

For dense fits and legacy completed records every one of these fields is absent. A malformed stored
snapshot fails the lookup with `numerical-failure`. An incomplete cache entry has no transformer;
restart it with fresh raw sources.

`hydrateTrainingResult(request, result)` keeps its algorithm-dependent return type. A caller that holds
a portable result restores the transformer itself, narrowing a tuning result first:

```ts
const fitted = result.algorithm === 'hyperparameter-tuning' ? result.bestResult : result;
const state = fitted.preprocessorState;
const preprocessor = state === undefined ? undefined : FittedTabularPreprocessor.fromJSON(state);
```

### Retained request metadata

A keyed run stores its request metadata in the local completed-result cache, and that metadata
includes the complete transport dictionaries you supplied, including categories that no fitting row
used and categories seen only in a holdout. The fitted snapshot, by contrast, contains only learnt
categories, and restoration always uses the snapshot, never the stored dictionary. The cache is local
and follows the usual cache lifecycle and deletion rules; decide whether to supply a `cacheKey` with
that retention in mind.

## What each fit learns from

| Operation                                    | Rows used to learn preprocessing                               | Where the frozen state is applied                                                                                             |
| -------------------------------------------- | -------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------- |
| Ordinary train, optional separate validation | Training source only                                           | Training features in the worker and validation in the orchestrator                                                            |
| Explicit-holdout tuning                      | The leading training partition only                            | The same state for its candidates and the held-out score. The winning training fit is returned.                               |
| Inner-fold tuning, including Hyperband       | The complement of the current validation fold                  | The corresponding holdout. Promotions reuse that fold's state. The winner is refitted on the whole search-training partition. |
| Fixed CV                                     | The complement of each outer fold                              | The outer holdout during page-side scoring. The optional refit learns a fresh state.                                          |
| Nested CV                                    | Inner complements, then all outer-training rows for the winner | The outer holdout, scored with the winner's transformer, after which the model and transient state are disposed.              |

`onModel` hook matrices (see [Metrics](metrics.md#fitted-model-hook-onmodel)) are rebuilt on the page
from the model's frozen fold transformer applied to the raw coded rows, which is the function and input the
worker fitted on, so they never learn from validation rows. Validation matrices are fresh copies of the
buffer already transformed for scoring.

Fitting statistics happen in workers under the origin Web Lock. The page slices raw rows, transfers owned
buffers and applies a frozen transform for synchronous inference and outer-fold scoring. The transformed
fitting matrix is allocated once per live fit in shared memory and is shared across compute tasks; a
cancelled or failed run disposes its scratch.

## Fold-dependent PCA component domains

Observed vocabularies differ between folds, so the encoded width can too. For every opt-in Random
Search that fits PCA, that is a standalone `pca` target (explicit holdout only) or a PCA pipeline
(explicit holdout or inner folds), the search is rejected **as a whole** with `invalid-request`, before
any candidate or PCA dispatch, if any admissible component count cannot fit any fitting partition at its
encoded width. Every explicit count is checked against `1..min(fitting rows, encoded width)`: the
fixed value when no domain overrides it, every value of a categorical domain and the endpoints of an
`integer`, `uniform` or `log-uniform` range. The error names the partition (an inner fold index, the
search-training partition, or the explicit-holdout training partition), the requested count and the
limit. No failed trial is recorded and no winner is returned, so the "Every hyperparameter tuning
trial failed" `numerical-failure` can never come from a component bound. In nested CV this runs within
each outer search and ends the run without a result.

When the count is omitted and has no domain, each actual fit resolves its own default
`min(sample count, encoded width)`, including the final refit. A standalone explicit-holdout PCA search
returns its training-only fit with no refit, and its `reconstruction-error` is measured on held-out rows
encoded with that training-only transform. Dense requests keep their existing raw-width checks.

## Explicit-holdout failures in `createTuner().search`

For an opt-in explicit-holdout search the facade honours an already-aborted signal first. Otherwise it
compares the two sources' declared `featureCount` with each other and with `preprocessing.columns.length`,
and their `targetCount`, before combining them. On a mismatch it returns the normal run handle
immediately: the stream emits `queued`, then a single `failed` event with code `invalid-request` and
`retriable: false`, then closes, and `result` and `trainingMetrics` reject with the same `TrainingError`.
Neither source is read and no training request is dispatched. A dense explicit-holdout search keeps its
documented synchronous `Error` for incompatible dimensions or missing validation data.

## Memory

Budgets for an opt-in search use the actual encoded width, independently of the retained component
count: raw storage, the transformed training and holdout rows, expanded downstream work and every
concurrently live candidate. For PCA the budget includes the full-width squared Float64 covariance
buffers that are live at once (one partial per worker, their transferred copies, the reduced
covariance and the eigensolver's input, vectors and scratch). An estimate above `memoryBudgetBytes`, or
one that overflows, or a failed allocation of the bounded finiteness-scan buffer, fails with `wasm-out-of-memory` before compute dispatch. An unavailable
shared-memory facility fails an opt-in request with `environment-not-supported`.

The bounded finiteness scan allocates its `min(rows, 2048) × encodedWidth` Float64 scratch before
the budget check, so a very wide encoding can briefly hold that buffer above `memoryBudgetBytes`. A run
whose encoded copies do not fit still fails with `wasm-out-of-memory` before compute dispatch.

Hook matrices (`trainingFeatures`, `validationFeatures`) are owned `NumericTensor` values, the type that
`transform` returns, of `rows × featureNamesOut.length` doubles. They are built only when an `onModel`
hook and `preprocessing` are both present, and the library disposes them when the hook settles (or at run
settlement after a cancellation). Hooks must not dispose them and copy them if they must outlive the call.

## Adjusted R²

Regression reports use the **fitted** predictor count, which is the number of columns delivered to the
estimator, not a rank or variability estimate. For single-output unpenalised linear OLS with an
intercept, `p` counts every encoded column, including a constant numeric column and an all-one
indicator. After PCA it is the number of retained components. See [Metrics](metrics.md) for
eligibility, the degrees-of-freedom boundary and pooling.

## Standalone example

```ts
import {
	ArrayDatasetProvider,
	FittedTabularPreprocessor,
	createTrainingClient,
	encodeTabularFeatures
} from 'web-ml';

const rows = [
	[21, 'blue'],
	[35, 'red'],
	[null, 'blue'],
	[48, 'green'],
	[52, 'red'],
	[29, null]
];
const labels = Float64Array.from([0, 0, 0, 1, 1, 0]);

// Pack the training rows. Their transport dictionary is shared by every source of the request.
const training = encodeTabularFeatures(rows, [
	{ name: 'age', kind: 'numeric' },
	{ name: 'colour', kind: 'categorical', categories: ['green', 'blue', 'red', 'purple'] }
]);

// Pack held-out rows with the same transport columns. 'unknown' is not in the dictionary, so it
// travels as -1 and becomes an all-zero block when the frozen transform is applied.
const heldOut = [
	[30, 'blue'],
	[58, 'unknown']
];
const validation = encodeTabularFeatures(heldOut, training.columns);

const client = createTrainingClient();
const run = client.train(
	{
		algorithm: 'logistic-regression',
		classLabels: ['no', 'yes'],
		preprocessing: { columns: training.columns, standardize: true },
		data: new ArrayDatasetProvider(rows.length, 2, 1, training.features, labels),
		validation: {
			data: new ArrayDatasetProvider(
				heldOut.length,
				2,
				1,
				validation.features,
				Float64Array.from([0, 1])
			)
		}
	},
	{ cacheKey: 'customers/v1' }
);
const { model, preprocessor, featureNamesOut, metrics } = await run.result;

// Predict from raw rows with the frozen transformer; it never learns from them.
if (preprocessor === undefined) throw new Error('Expected a fitted transformer.');
const probe = [
	[40, 'green'],
	[null, 'never-seen']
];
const predictions = model.predict(preprocessor.transform(probe));

// Later, restore the same transformer from the cache without reading any source.
const state = await client.checkTrainingState('customers/v1');
if (state && state.status === 'completed') {
	const fitted =
		state.result.algorithm === 'hyperparameter-tuning' ? state.result.bestResult : state.result;
	const restored =
		fitted.preprocessorState === undefined
			? undefined
			: FittedTabularPreprocessor.fromJSON(fitted.preprocessorState);
	restored?.transform(probe);
}
void [featureNamesOut, metrics, predictions];
```

## Fold mappings and the tuning winner

```ts
import {
	ArrayDatasetProvider,
	createTuner,
	crossValidate,
	encodeTabularFeatures,
	nestedCrossValidate,
	type TrainingData
} from 'web-ml';

// One row carries the rare category, so some folds never observe it and have a narrower axis.
const rows = Array.from({ length: 24 }, (_, row) => [
	row * 1.5,
	row === 7 ? 'rare' : row % 2 === 0 ? 'a' : 'b'
]);
const labels = Float64Array.from({ length: 24 }, (_, row) => (row >> 1) % 2);
const packed = encodeTabularFeatures(rows, [
	{ name: 'x', kind: 'numeric' },
	{ name: 'group', kind: 'categorical' }
]);
const provider = () =>
	new ArrayDatasetProvider(
		24,
		2,
		1,
		Float64Array.from(packed.features),
		Float64Array.from(labels)
	);
const preprocessing = { columns: packed.columns };
const options = { solver: 'sgd', maxIter: 30 } as const;

// Fixed CV: each fold exposes its own mapping, and the refit returns its own transformer.
const fixed = await crossValidate({
	algorithm: 'logistic-regression',
	data: provider(),
	folds: 3,
	scoring: 'accuracy',
	options,
	refit: true,
	preprocessing
}).result;
const foldAxes = fixed.folds.map((fold) => fold.featureNamesOut);
const fromRefit = fixed.refit?.preprocessor?.transform([[10, 'a']]);

// Nested CV keeps the winner's mapping for every outer fold even though the winners are disposed.
const nested = await nestedCrossValidate({
	algorithm: 'logistic-regression',
	data: provider(),
	outerFolds: 3,
	innerFolds: 2,
	searchSpace: { learningRate: { kind: 'categorical', values: [0.05] } },
	baseOptions: options,
	scoring: 'accuracy',
	strategy: { kind: 'random-search', nTrials: 1 },
	preprocessing
}).result;
const outerAxes = nested.folds.map((fold) => fold.featureNamesOut);

// Tuning: the winner's transformer and mapping sit beside the threshold-aware model.
const batches = (): TrainingData => ({
	sampleCount: 24,
	featureCount: 2,
	targetCount: 1,
	batches: (async function* () {
		yield { rowCount: 24, features: Float64Array.from(packed.features), targets: labels };
	})()
});
const tuned = await createTuner().search({
	algorithm: 'logistic-regression',
	trainingData: batches(),
	innerFoldAssignments: Uint32Array.from({ length: 24 }, (_, row) => row % 3),
	innerFoldCount: 3,
	preprocessing,
	searchSpace: { learningRate: { kind: 'categorical', values: [0.05] } },
	baseOptions: options,
	scoring: 'accuracy',
	strategy: { kind: 'random-search', nTrials: 1 }
}).result;
const winnerNames = tuned.featureNamesOut;
void [foldAxes, fromRefit, outerAxes, winnerNames];
```

## Related references

- `stratifiedTrainTestSplit` and the held-out indices of fixed and nested CV are described in
  [Metrics](metrics.md#reproducible-partitions).
- Class-label options (weights, priors, cutoffs) are in [Hyperparameters](hyperparameters.md).
- The user guides show the same contracts with runnable examples: [training](../../user-guide/training.md),
  [datasets](../../user-guide/dataset-provider.md), [tuning](../../user-guide/tuning.md) and
  [evaluation](../../user-guide/evaluation.md).

For `holdoutValidate`, preprocessing is learned only from the training split. The same frozen transformer is applied to held-out rows and to the optional resubstitution report.
