# Metrics

This document describes exported metric functions and metrics reported by training, tuning, and nested cross-validation. The model support table below describes classification evaluation for fitted estimators.
The [machine-readable model specifications](model-specifications/README.md)
record only currently exposed model-specific fit statistics and training
diagnostics. Evaluation reports are separate from model-specific JSON metrics;
`liveMetrics?: boolean` is accepted on ordinary requests (including PCA pipelines) and defaults to false. It is rejected for tuning and nested pipeline estimators. Existing loss and inertia remain available without the flag.

## Exported metric functions

| Function                                                                                               | Current behavior                                                                                                                                                                                                                                                            |
| ------------------------------------------------------------------------------------------------------ | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `accuracyScore(yTrue, yPred)`                                                                          | Returns the fraction of matching labels as a scalar number. Rejects unequal or empty inputs.                                                                                                                                                                                |
| `f1Score(yTrue, yPred, options?)`                                                                      | Returns a scalar F1 score. Supports `binary`, `macro`, `micro`, and `weighted` averaging, plus positive-label and label-order options. Default averaging is binary.                                                                                                         |
| `logLoss(yTrue, yPred, options?)`                                                                      | Returns scalar log loss for label or indicator targets and predicted-probability inputs. Rejects shape mismatch, empty data, negative/non-finite probabilities, and rows with a non-positive or non-finite sum. Positive-sum rows are normalized, then clipped using `eps`. |
| `meanSquaredError(yTrue, yPred)`                                                                       | Returns scalar mean squared error over the supplied target values; rejects empty or mismatched shapes.                                                                                                                                                                      |
| `meanAbsoluteError(yTrue, yPred)`                                                                      | Returns scalar mean absolute error over the supplied target values; rejects empty or mismatched shapes.                                                                                                                                                                     |
| `r2Score(yTrue, yPred)`                                                                                | Returns scalar R². Multioutput scores are uniformly averaged. Constant target columns score 1 for exact predictions and 0 otherwise. Rejects empty or mismatched shapes.                                                                                                    |
| `precisionScore`, `recallScore`                                                                        | Label precision and recall with binary, macro, micro or weighted averaging.                                                                                                                                                                                                 |
| `truePositiveRate`, `trueNegativeRate`, `falsePositiveRate`, `falseNegativeRate`                       | Positive-versus-rest rates.                                                                                                                                                                                                                                                 |
| `perClassClassificationScores`                                                                         | Per-label precision, recall, F1 and rates.                                                                                                                                                                                                                                  |
| `matthewsCorrelationCoefficient`                                                                       | Full-matrix Matthews correlation.                                                                                                                                                                                                                                           |
| `brierScoreLoss`                                                                                       | Binary, multiclass or multi-label Brier loss.                                                                                                                                                                                                                               |
| `rocAucScore`, `averagePrecisionScore`                                                                 | Macro or per-class ranking scores.                                                                                                                                                                                                                                          |
| `evaluateClassification`                                                                               | A typed binary, multiclass or multi-label report.                                                                                                                                                                                                                           |
| `rootMeanSquaredError`, `meanAbsolutePercentageError`, `medianAbsoluteError`                           | Regression error metrics, averaged uniformly across outputs.                                                                                                                                                                                                                |
| `explainedVarianceScore`, `maxError`, `meanSquaredLogarithmicError`, `rootMeanSquaredLogarithmicError` | Regression metrics with the domain and averaging rules below.                                                                                                                                                                                                               |
| `adjustedR2Score`, `evaluateRegression`                                                                | Adjusted R² with caller-supplied predictor count, and a typed regression report.                                                                                                                                                                                            |

Standalone `rocCurve`, `precisionRecallCurve`, `oneVsRestCurves`,
`calibrationCurve`, `confusionMatrix`, and `binaryThresholdSweep` return
owned typed arrays. Binary curves use inclusive thresholds and return
`{ available: false, reason: 'single-class' }` when positives or negatives
are absent. ROC starts at the origin with an infinite threshold; precision-recall
ends at precision 1 and recall 0. Calibration uses uniform half-open bins,
including 1 in the final bin, and reports weighted expected calibration error.
A binary singleton requires an explicit axis or positive label for calibration.
Probability matrices use the caller's class axis and must sum to one within
1e-6 per row. Confusion matrices use truth rows and prediction columns.
Invalid inputs throw `RangeError`; inputs are never mutated.

The classification functions accept supported labels and probability layouts;
regression functions accept vector, matrix, and web-ml structural tensor inputs.
See the public declarations and their TSDoc for exact overloads and input types.

The classification exports also include `precisionScore`, `recallScore`,
`truePositiveRate`, `trueNegativeRate`, `falsePositiveRate`,
`falseNegativeRate`, `perClassClassificationScores`,
`matthewsCorrelationCoefficient`, `brierScoreLoss`, `rocAucScore`,
`averagePrecisionScore`, and `evaluateClassification`. Label-count
functions treat an explicit `labels` list as the subset to score; rows outside
that subset still contribute false positives and false negatives. Probability
and ranking functions instead treat labels as a strict column vocabulary.

`evaluateClassification` reports binary positive-versus-rest metrics,
multiclass macro and per-class scores, or multi-label exact-set and per-label
scores. Unseen truth labels are appended in boolean, numeric, then UTF-16
string order and make probability and ranking scores unavailable. Zero
denominators yield zero. Binary report MCC uses positive-versus-rest counts;
standalone MCC uses the full observed confusion matrix, which can differ when
unseen labels occur. Multi-label log loss is element-wise binary cross-entropy;
multiclass Brier is the unscaled sum of squared errors across classes. Ranking
uses midranks for ROC-AUC and step-wise average precision grouped by ties.
Multi-label ranking uses each label's probability column, including when there
is only one label. Undefined individual classes are skipped in macro ranking
averages.

## Out-of-sample diagnostics

`classificationDiagnostics` builds a row-major confusion matrix (true rows,
predicted columns), support, predicted counts, accuracy, macro and per-class
precision, recall and F1. Zero denominators yield zero. Labels define matrix
order. `MAX_DIAGNOSTIC_CLASSES` is 4096, bounding the dense matrix to 64 MiB.
`regressionDiagnostics` returns target-minus-prediction residuals in row order,
mean residual, MSE, RMSE, MAE, maximum absolute error and R²; constant targets
score 1 for exact predictions and 0 otherwise. Both return cloneable objects.

`diagnoseModel(model, heldOutData, options)` applies these builders to a fitted
model and separate held-out rows. Classifiers require `options.classLabels` in
the dataset's target encoding order, which can differ from `model.classes_`.
Multi-label LogisticRegression is rejected. The model remains caller-owned.

## Cross-validation (fixed hyperparameters)

`crossValidate` fits fixed options in sequential worker-backed folds. It supports
`accuracy` and binary `f1` for classifiers and `r2` and `mean-squared-error` for
regressors. Its always-present `diagnostics` pools out-of-fold predictions in
source-row order; classifier memory is O(n + K²) and regression memory is O(n).
`includeMetrics` averages fixed-CV scalar summaries equally across folds;
SVC requires probability estimates and regression RMSLE requires non-negative
targets. Optional `refit` trains one full-data model, owned by the caller. Every fold
result carries `validationIndices`; with the opt-in `preprocessing` option it also carries
`featureNamesOut`, and the refit returns its own `preprocessor` and `featureNamesOut`.
The fold-count and class-capacity rules are specified in
[Stratified partition feasibility](stratified-partitions.md).

### Fitted-model hook (`onModel`)

`crossValidate(request, { signal, onModel })`, `nestedCrossValidate(request, { signal, onModel })` and
`holdoutValidate(request, { signal, onModel })` accept an optional page-side callback. The hook lives in the run options, never in the request, so it
is never structured-cloned, never part of a cache key and never reaches a worker. A present `onModel`
that is not a function fails with `invalid-request` before any fit. `holdoutValidate` calls it once per
run with `kind: 'holdout'`, after held-out scoring, diagnostics, requested reports and baselines have been
collected and before `fold-complete`. Its `trainingIndices` and `validationIndices` are fresh copies of the
result's `trainIndices` and `validationIndices`, and with `preprocessing` its `preprocessing` context follows
the same rules as for a fold. A model kept through `returnFit` is the instance the hook receives and stays
valid after the hook settles.

- **Calls.** One call per fold (`kind: 'fold'`, with `foldIndex`) and one for the refit
  (`kind: 'refit'`) when `refit` is set. Nested CV calls it once per outer fold with the outer winner
  and once with the refit model; it is never called for models inside the inner searches. Calls are
  sequential, in fold order and then refit, and each is awaited before the next fit starts.
- **Context.** `trainingIndices` and `validationIndices` are ascending, freshly allocated source-row
  indices (a refit has `trainingIndices` `0 … n−1` and no validation indices). With the opt-in
  `preprocessing` option, `context.preprocessing` carries `featureNamesOut`, `trainingFeatures`
  and, for folds, `validationFeatures`: owned `float64` `NumericTensor` values of shape
  `[rows, featureNamesOut.length]`, rebuilt on the page from the model's frozen transformer and the
  same raw codes the worker fitted on (for PCA pipelines, the pipeline's input features). Without
  `preprocessing` the field is absent and callers index their own data. Pass a tensor straight to
  `model.predict`; copy it (`tensor.copy()` or `Float64Array.from(tensor.data, Number)`) if it must
  outlive the call.
- **Order and timing.** fit, score and collect opt-in evaluation, end of the `durationMs`
  measurement, build the matrices, await the hook, dispose the matrices, dispose the fold model
  (a refit is returned), then emit `fold-complete`, `outer-fold-complete` or `refit-complete`. Fold
  and refit `durationMs` exclude hook time, and fold `durationMs` also excludes model disposal in every
  run. The run-level `trainingMetrics.durationMs` includes hooks and disposal. In nested
  cross-validation, an outer fold whose selected score is non-finite fails with `numerical-failure`
  before its hook is called.
- **Lifetime.** The model, index arrays and tensors are valid only until the hook settles. The library
  disposes each tensor exactly once when the hook settles; hooks must not dispose them. Fold models are
  disposed afterwards. A refit model stays valid because the caller owns it.
- **Failure.** A synchronous throw or rejection disposes the model, emits `failed` and rejects both
  promises with a `TrainingError` whose code is `callback-failed`, whose message starts
  `onModel hook failed:` and whose `cause` is the thrown value.
- **Cancellation.** An abort (a signal, or `cancel()` on `crossValidate`) while a hook is pending
  settles the run as cancelled without waiting for the hook. The model and the tensors are disposed at
  settlement and a later rejection of the abandoned hook is ignored. A pre-aborted run never calls it.

### Reproducible partitions

`stratifiedTrainTestSplit(targets, { testRatio, randomState? })` returns freshly owned ascending
`trainIndices` and `testIndices` for one seeded, stratified holdout. For ratio `r` and a class of
`n` rows the test quota is bounded by `floor(r*n)` and `ceil(r*n)`, each clamped to `[1, n-1]`;
the required total is `Math.round(r*N)` (the rule is checked in advance by
[`checkStratifiedPartition`](stratified-partitions.md)), and the remaining slots go to classes with room by
decreasing fractional remainder (ties by ascending code). A class's test rows come from the start
of its seeded shuffle, so every row occurs once and each class differs from `r*n` by at most one.
The seed defaults to `0` and uses the same xorshift32 stream as cross-validation. Empty input,
a singleton class, a total outside the per-class bounds, invalid codes, a ratio outside the open
interval (0, 1) and a non-finite seed fail with `invalid-request`.

## Comparing cross-validated models

`bayesianCorrelatedTTest(scoresA, scoresB, { rope, testFraction })` and
`correctedResampledTTest(scoresA, scoresB, { testFraction, alternative? })` compare two models or
hyperparameter settings from paired per-partition scores, such as
`result.folds.map((fold) => fold.score)` from two `crossValidate` runs with equal `folds`,
`randomState` and `classLabels`. The Bayesian test returns the posterior probabilities that A's expected
score is lower than B's by more than `rope`, within it, or higher; the corrected test returns the
Nadeau–Bengio statistic and a two-sided or one-sided p-value. Both are pure and synchronous and need no
worker. Results are stated on `A − B`, so for a loss such as `mean-squared-error` a high
`probabilityHigher` means A is worse. See [Cross-validated model comparison](model-comparison.md).

## Training progress and run timing

Training `progress` events may include an optional algorithm-typed `metrics`
object. Values are numerical diagnostics such as iterative loss, not a guaranteed
complete evaluation report. Field names and availability vary by algorithm.
For iterative regressors and classifiers, progress metrics report the current
objective loss. Solver stopping uses the contracts in
[`hyperparameters.md`](hyperparameters.md): absolute objective change for SGD and
Adam, gradient infinity norm for LogisticRegression L-BFGS, and maximum KKT
violation for LogisticRegression coordinate descent. With `liveMetrics: true`,
the `convergence` key exposes the applicable stopping statistic when defined.

Ordinary supervised training with an explicit validation partition returns an
optional evaluation report as `result.metrics`; fitted estimators do not retain
the report. The run handle also has a separate `trainingMetrics` promise
containing `durationMs`; see the
[timing guide](timing.md) for measurement boundaries.

## Tuning scores

The built-in tuning scorers and optimization directions are:

| Scorers                                                                                                                                                                                                 | Task                                      | Direction |
| ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ----------------------------------------- | --------- |
| `accuracy`                                                                                                                                                                                              | Classification; exact-set for multi-label | Higher    |
| `f1`, `precision`, `recall`, `true-negative-rate`                                                                                                                                                       | Binary classification                     | Higher    |
| `false-positive-rate`, `false-negative-rate`                                                                                                                                                            | Binary classification                     | Lower     |
| `f1-macro`, `precision-macro`, `recall-macro`, `matthews-correlation`                                                                                                                                   | Classification                            | Higher    |
| `log-loss`, `brier-score`                                                                                                                                                                               | Classification with probabilities         | Lower     |
| `roc-auc`, `average-precision`                                                                                                                                                                          | Classification with ranking scores        | Higher    |
| `r2`, `explained-variance`                                                                                                                                                                              | Regression                                | Higher    |
| `mean-squared-error`, `root-mean-squared-error`, `mean-absolute-error`, `median-absolute-error`, `mean-absolute-percentage-error`, `max-error`, `mean-squared-log-error`, `root-mean-squared-log-error` | Regression                                | Lower     |
| `validation-inertia`, `reconstruction-error`                                                                                                                                                            | K-means, PCA respectively                 | Lower     |

Scorer/model compatibility is validated on the worker-backed tuning path, whether
the request comes through `createTrainingClient().train(...)` or
`createTuner().search(...)`; `nestedCrossValidate(...)` also validates its own
request before starting the inner searches. Binary F1 requires exactly two
configured labels. `thresholdTuning` can select a binary probability cutoff
when paired with `accuracy` or `f1`; it requires exactly two labels and a
classifier with `predictProba()`. SVC threshold tuning and log-loss require
`probability: true`. Custom scorer callbacks are not supported. Every tuning
trial reports fit-and-score elapsed time in `durationMs`; failed trials retain
time to failure, and a pruned Hyperband trial retains the duration of its last
evaluation. Resumed-rung duration covers only the added solver iterations.
Iterations have solver-specific costs, so solver comparisons should be read with
these elapsed times rather than treating each resource unit as equal wall time.

### Trial histories and the winning trial

`TuningResult.trials` is ordered by ascending `trialId`, then ascending `resource`. `trialId` is the
sampling and dispatch order; trials of one Random Search batch may run concurrently, so completion order
is not reproducible. Each summary whose evaluation completed carries `foldScores`, a `Float64Array` with
the score on each validation partition in partition order (`innerFolds` values for fold-aware searches,
one for a holdout search). Without `thresholdTuning`, `score` is the mean of `foldScores`. With
`thresholdTuning`, each partition is scored at the selected pooled cutoff, so `score` (the pooled value)
generally differs from the mean of `foldScores`. A summary has `foldScores` exactly when it has a
`score`: failed Random Search trials, and Hyperband entries reported as `pruned` with an `error`
(Hyperband rewrites every unpromoted rung evaluation, failed ones included, to `pruned`), have neither.

`TuningResult.bestTrialId` names the winning trial. Let `W` be the `trials` entry with that id (for
Hyperband also `resource === maxResource`). Then `W.status` is `completed`, `W.score === bestScore` and
`W` has no `error`. For Random Search `bestParams` deep-equals `W.params`. For Hyperband `bestParams`
deep-equals `W.params` plus the resource parameters at `maxResource`: `maxIter`, and `nIterations` for
`logistic-regression`. Summaries keep recording only the trial's own parameters. Both new fields are
optional: a `TuningResult` stored under a caller `cacheKey` before they existed is returned unchanged
without them, and custom `TrainingClient` implementations may omit `bestTrialId`.

### Trial reports (`trialMetrics`)

Pooled reports for fold-aware or threshold-tuned searches are built on the declared class axis. Decision
margins are passed to the report only when the declared axis has exactly two labels; with three or more
declared labels ranking falls back to probabilities or is marked unavailable one metric at a time (for
example `unseen-validation-labels` or `probabilities-unavailable`) while counts stay on the declared
axis. The single-partition (holdout) report stays on the fitted axis. A report never changes a trial's
status or score: if building it throws a non-fatal, non-abort error, the trial keeps its score, omits
`metrics` and records the message in `metricsError`. Fatal infrastructure errors and aborts still stop the
search. Failed evaluations carry neither `metrics` nor `metricsError`.

## Nested cross-validation metrics

Nested CV supports the supervised scorers above. With `thresholdTuning`, each
inner search selects one cutoff from pooled out-of-fold probabilities, then
applies it to the untouched outer fold. `includeMetrics: true` returns one report
per fold and a pooled source-ordered report. `completeMetrics: true` enables
ranking and median absolute error. Missing probabilities and negative RMSLE
targets are represented as unavailable fields unless that field is the required
selection scorer, in which case the fold fails. Each outer fold reports its
`validationIndices` (ascending, freshly owned) even when metrics are disabled, and, with the
opt-in `preprocessing` option, the `featureNamesOut` of its winning fit. Outer and inner fold
capacity rules are in [Stratified partition feasibility](stratified-partitions.md).

Two opt-in request fields extend the result:

- `includeTrials: true` adds `trials` (the inner search's full history, including pruned and failed
  trials, with `foldScores` and no `metrics`) and `bestTrialId` to every outer-fold result. They satisfy
  the winner relation above with the fold's `bestParams` and `innerScore`. Memory grows with
  `outerFolds × trials × innerFolds` doubles plus parameter objects. Non-boolean values fail with
  `invalid-request` before any fit.
- `refit: true` runs the same inner search (same `searchSpace`, `baseOptions`, `strategy`, `scoring`,
  `thresholdTuning`, `preprocessing`, `classLabels` and resources) over all rows after the outer folds
  and returns `result.refit` with the winner fitted on every row: `model`, `bestParams`, `innerScore`,
  the threshold fields, `durationMs` (refit search plus final fit), `sampleCount`, `preprocessor` and
  `featureNamesOut` with preprocessing, and `trials` and `bestTrialId` with `includeTrials`. The refit
  assignment uses partition seed `outerFolds + 1` (outer fold `f` keeps `f + 1`) and is built and
  validated before the first outer fold. Events `refit-start`, `refit-progress` and `refit-complete`
  precede `completed`. The caller owns `refit.model` and must dispose native (SVC/SVR) models; the
  library disposes it on failure or cancellation. Outer fold results are identical with and without
  `refit`. The `onModel` hook described above is also called for the outer winners and the refit model.

## Implemented live solver diagnostics

With `liveMetrics: true`, iterative linear and polynomial regression report `gradientNorm`, the Euclidean norm of the smooth pre-update gradient including the L2 contribution only on regularized parameters and the intercept gradient only when fitted; `weightNorm`, the post-update coefficient norm excluding the intercept; and `convergence`, the absolute loss change when a preceding loss exists. OLS reports solver `rank` and `conditionNumber` of the thin unregularized design spectrum on its final snapshot. It discards padded structural singular values, includes the actual intercept/bias columns, and emits Infinity only for an exactly zero retained minimum; other non-finite diagnostics are omitted. QR shard and polynomial expansion counts are always reported.

Logistic regression reports `parameterChange`, the norm of the full parameter update, and `convergence`, its solver stopping statistic: absolute loss change for SGD/Adam, gradient infinity norm for L-BFGS, or maximum KKT violation for coordinate descent. K-means reports `centroidShift`, the Frobenius norm of the most recent centre shift. Existing loss and inertia remain independent of the flag. Events are throttled and coalesced snapshots; these fits force their final training-stage snapshot.

### MLP and decision-tree snapshots

MLP diagnostics use the pre-update training forward pass and the actual fit subset, excluding any validationFraction rows. Classification accuracy uses canonical argmax: a binary probability of 0.5 and multiclass ties select the first class, regardless of any post-fit decision threshold. Regression training R² is the uniform mean across outputs of 1 − SSE/SST; a constant output scores 1 for zero SSE and 0 otherwise. Gradient norm uses the sum of training-shard gradients in shard order, and convergence is the absolute change in training loss. The separate validation curve and final-weight policy are unchanged.

Tree snapshots report deepest created depth (root zero), nodes created, leaves finalized, and impurityDecrease as the sum of completed split gains weighted by the node sample count divided by the original sample count. weightedImpurity is root impurity minus that sum. Undefined or non-finite values are omitted.

### Naive Bayes snapshots

GaussianNB reports the number of observed class-feature pairs with exactly zero unsmoothed M2. From the second chunk onward, varianceChange is the Euclidean norm of changes in unsmoothed M2/n for pairs observed at both boundaries; an unavailable or non-finite norm is omitted.

BernoulliNB reports prequentialLogLikelihood, the mean conditional feature log likelihood under the model from earlier chunks; the class prior is excluded. MultinomialNB reports prequentialCrossEntropy, the mean negative true-class log posterior under earlier chunks. The first chunk is never scored; later rows whose class had not yet appeared are excluded. scoredSamples counts eligible rows, including those with impossible or unavailable scores. A non-finite score makes the cumulative mean unavailable for the remainder of the fit, while the count remains visible. Zero-feature terms contribute zero even for a negative-infinite log probability; all-negative-infinite Multinomial joint scores use uniform active-class fallback. Existing smoothing and prior rules apply, including active classes only and explicit priors on their original observed-axis positions. No prequential keys appear when the fit has one chunk.

### Neighbour index build snapshots

Tree builds report completed rows in finalized leaves. With liveMetrics enabled, indexDepth is the deepest created level, indexNodes counts built nodes and indexLeaves counts finalized leaves. Brute search has no index metrics. The final tree snapshot has depth L−1, nodes 2^L−1, leaves 2^(L−1) and completed = total = N.

### SVM solver snapshots

SVC counts completed non-calibration one-vs-one solves out of k(k−1)/2 for k observed classes; SVR counts one solve. With `liveMetrics`, `solverIterations` and `calibrating` describe the current solve. `supportVectors` counts nonzero dual coefficients, and `boundedSupportVectors` counts coefficients at their C bound (for SVR, one paired variable at the bound and the other zero). The counts describe only the current pair or calibration fold, not the multiclass total. `maxKktViolation` is the latest finite active-set Gmax + Gmax2; it is omitted if either extremum or their sum is unavailable or non-finite. A final snapshot indicates termination, not necessarily convergence: an iteration limit may be reached. No loss history or duality gap is inferred. Equal fitted states with live metrics on and off require equal starting native C RNG state for probability calibration.

### Proposal corrections

Prequential Naive Bayes scores are means over eligible rows, with rows rather than tokens counted. Median neighbour splits do not report split balance or target-dependent variance reduction. MLP diagnostics score the fit subset, not live validation, and do not invent mini-batches or learning-rate schedules. Tree gain measures weighted impurity decrease. SVM reports a finite active-set KKT gap and support counts, not a duality gap or loss history. Existing loss and inertia retain their solver definitions.

### Default Metrics

When a validation or CV report is requested, its default tier includes the
linear-time fields defined below; unavailable fields carry a reason.

### Complete Metrics

The optional `completeMetrics` flag enables ranking and median absolute error.

# Metrics by Task

## Classification Metrics

The definitions below apply to the exported classification calculations. The model integration table describes fitted-model evaluation coverage.

### Classification Metric Definitions

#### Confusion Matrix Notation & Base Rates

Let binary ground-truth classes be positive ($y = 1$) and negative ($y = 0$).

- $\text{TP}$: True Positives ($y = 1, \hat{y} = 1$)
- $\text{TN}$: True Negatives ($y = 0, \hat{y} = 0$)
- $\text{FP}$: False Positives ($y = 0, \hat{y} = 1$)
- $\text{FN}$: False Negatives ($y = 1, \hat{y} = 0$)
- $\text{P} = \text{TP} + \text{FN}$ (Total actual positives)
- $\text{N} = \text{TN} + \text{FP}$ (Total actual negatives)

#### Accuracy (ACC)

$$\text{ACC} = \frac{\text{TP} + \text{TN}}{\text{TP} + \text{TN} + \text{FP} + \text{FN}}$$

- **Definition:** Proportion of total predictions that were correct across all classes.
- **Notes:** Susceptible to the accuracy paradox on imbalanced datasets. For multi-class classification with confusion matrix $C$ of size $K \times K$:

$$\text{ACC} = \frac{\sum_{k=1}^K C_{k,k}}{\sum_{i=1}^K \sum_{j=1}^K C_{i,j}}$$

#### Precision (PREC) / Positive Predictive Value (PPV)

$$\text{PREC} = \frac{\text{TP}}{\text{TP} + \text{FP}}$$

- **Definition:** Fraction of positive predictions that belong to the positive class.
- **Notes:** When $\text{TP} + \text{FP} = 0$, define $\text{PREC} = 0.0$ to avoid division by zero. Multi-class extensions:

* _Macro:_ $\frac{1}{K}\sum_{k=1}^K \text{PREC}_k$
* _Weighted:_ $\sum_{k=1}^K \frac{n_k}{N} \text{PREC}_k$
* _Micro:_ Equals global Accuracy.

#### Recall (REC) / Sensitivity / True Positive Rate (TPR)

$$\text{REC} = \text{TPR} = \frac{\text{TP}}{\text{TP} + \text{FN}} = \frac{\text{TP}}{\text{P}}$$

- **Definition:** Fraction of actual positive instances correctly retrieved by the model.
- **Notes:** Undefined if $\text{P} = 0$ (set to $0.0$ or guard against empty positive sets). Multi-class requires One-vs-Rest (OvR) per-class computation:

$$\text{REC}_k = \frac{C_{k,k}}{\sum_{j=1}^K C_{k,j}}$$

#### F1 Score (F1)

$$\text{F1} = 2 \cdot \frac{\text{PREC} \cdot \text{REC}}{\text{PREC} + \text{REC}} = \frac{2\text{TP}}{2\text{TP} + \text{FP} + \text{FN}}$$

- **Definition:** Harmonic mean of Precision and Recall, balancing false positives and false negatives under equal weighting.
- **Notes:** Evaluates to $0.0$ if $\text{TP} + \text{FP} + \text{FN} = 0$. For imbalanced multiclass targets, report both Macro-F1 (unweighted class average) and Weighted-F1 (prevalence-weighted).

#### Logarithmic Loss (LogLoss) / Cross-Entropy Loss

- **Binary Formulation:**

$$\text{LogLoss} = -\frac{1}{n} \sum_{i=1}^n \left[ y_i \ln(\hat{p}_i) + (1 - y_i) \ln(1 - \hat{p}_i) \right]$$

- **Multi-class Formulation ($K$ classes, one-hot $y\_{i,k}$):**

$$\text{LogLoss} = -\frac{1}{n} \sum_{i=1}^n \sum_{k=1}^K y_{i,k} \ln(\hat{p}_{i,k})$$

- **Definition:** Information-theoretic penalty measuring divergence between true distributions and predicted probabilities.
- **Notes:** Probabilities must be clipped to $[\epsilon, 1 - \epsilon]$ (typically $\epsilon = 10^{-15}$) before computing $\ln$ to prevent undefined $\ln(0)$ evaluations.

#### True Negative Rate (TNR) / Specificity

$$\text{TNR} = \frac{\text{TN}}{\text{TN} + \text{FP}} = \frac{\text{TN}}{\text{N}}$$

- **Definition:** Proportion of actual negatives correctly identified.
- **Notes:** Complement of the False Positive Rate ($\text{TNR} = 1 - \text{FPR}$). In multi-class OvR settings, $\text{TN}_k$ consists of all samples outside class $k$ not predicted as class $k$.

#### False Positive Rate (FPR) / Fall-Out

$$\text{FPR} = \frac{\text{FP}}{\text{TN} + \text{FP}} = 1 - \text{TNR}$$

- **Definition:** Proportion of actual negatives incorrectly flagged as positive (Type I error rate).
- **Notes:** Serves as the horizontal axis on the Receiver Operating Characteristic (ROC) curve.

#### False Negative Rate (FNR) / Miss Rate

$$\text{FNR} = \frac{\text{FN}}{\text{TP} + \text{FN}} = 1 - \text{TPR}$$

- **Definition:** Proportion of actual positives missed by the model (Type II error rate).
- **Notes:** Critical metric in high-cost asymmetric risk domains (e.g., fault detection, medical diagnosis).

#### Matthews Correlation Coefficient (MCC)

$$\text{MCC} = \frac{\text{TP} \cdot \text{TN} - \text{FP} \cdot \text{FN}}{\sqrt{(\text{TP} + \text{FP})(\text{TP} + \text{FN})(\text{TN} + \text{FP})(\text{TN} + \text{FN})}}$$

- **Definition:** Pearson correlation coefficient between true and predicted binary classifications, bounded in $[-1, +1]$.
- **Notes:** Evaluates to $0.0$ if the denominator evaluates to zero. Generalizes directly to multi-class via the confusion matrix $C$:

$$\text{MCC} = \frac{\sum_{k}\sum_{l}\sum_{m} (C_{k,k} C_{m,l} - C_{k,l} C_{m,k})}{\sqrt{\sum_{k}\left(\sum_l C_{k,l}\right)\left(\sum_{k' \neq k}\sum_{l'} C_{k',l'}\right)} \sqrt{\sum_{k}\left(\sum_l C_{l,k}\right)\left(\sum_{k' \neq k}\sum_{l'} C_{l',k'}\right)}}$$

#### Brier Score Loss (BSL)

- **Binary Formulation:**

$$\text{BSL} = \frac{1}{n} \sum_{i=1}^n (\hat{p}_i - y_i)^2$$

- **Multi-class Formulation:**

$$\text{BSL} = \frac{1}{n} \sum_{i=1}^n \sum_{k=1}^K (\hat{p}_{i,k} - y_{i,k})^2$$

- **Definition:** Strictly proper scoring rule quantifying calibration error and probabilistic accuracy via mean squared probability error. Bounded in $[0, 1]$ (or $[0, 2]$ for multi-class unscaled formulations).

#### Receiver Operating Characteristic Area Under Curve (ROC-AUC)

$$\text{ROC-AUC} = \int_{0}^{1} \text{TPR}(\text{FPR}^{-1}(t)) \, dt$$

- **Non-parametric Formulation (Mann-Whitney $U$ / Wilcoxon rank-sum equivalence):**

$$\text{ROC-AUC} = \frac{\sum_{i \in \mathcal{P}} \sum_{j \in \mathcal{N}} \left( \mathbb{I}(\hat{p}_i > \hat{p}_j) + 0.5 \cdot \mathbb{I}(\hat{p}_i = \hat{p}_j) \right)}{\vert{}\mathcal{P}\vert{} \cdot \vert{}\mathcal{N}\vert{}}$$

- **Definition:** Probability that a randomly drawn positive instance receives a higher predicted probability or score than a randomly drawn negative instance.
- **Notes:** Invariant to monotonic score transformations and baseline class prevalence. For multi-class targets, compute using Hand & Till (1999) macro-average OvO or weighted OvR with trapezoidal numerical integration.

#### Precision-Recall Area Under Curve (PR-AUC)

$$\text{PR-AUC} = \int_{0}^{1} \text{PREC}(\text{REC}) \, d(\text{REC})$$

- **Average Precision (AP) Numerical Approximation:**

$$\text{AP} = \sum_{k=1}^M (\text{REC}_k - \text{REC}_{k-1}) \cdot \text{PREC}_k$$

- **Definition:** Area under the precision-recall curve across varying classification thresholds.
- **Notes:** Linear interpolation between discrete points on a PR curve overestimates area; numerical integration must use the stair-step/interpolated precision method (such as Scikit-learn's `average_precision_score`) rather than standard trapezoidal rules. Significantly more informative than ROC-AUC when evaluating severe class skew ($\text{P} \ll \text{N}$).

Fitted classifiers and PCA classifier pipelines can be scored with
`evaluateClassifier`. The source of probabilities is `native` for Naive Bayes
and LogisticRegression, `leaf-frequency` for trees, `neighbor-vote` for
K-neighbors, `network-output` for MLP, and `platt` for calibrated SVC.
Multiclass LogisticRegression sigmoid rows are normalized for evaluation. Binary
SVC ranking always uses its oriented decision function; multiclass SVC ranking
requires calibrated probabilities.

### Classification Model Metric Support

| Model ID                  | Model Name                        | Type        | Accuracy (ACC)          | Precision (PREC)                  | Recall (REC)                      | F1 Score (F1)                     | Logarithmic Loss (LogLoss)                       | True Positive Rate (TPR)                         | True Negative Rate (TNR)                         | False Positive Rate (FPR)                        | False Negative Rate (FNR)                        | Matthews Correlation Coefficient (MCC) | Brier Score Loss (BSL)                           | Receiver Operating Characteristic Area Under Curve (ROC-AUC)                        | Precision-Recall Area Under Curve (PR-AUC)                                          |
| ------------------------- | --------------------------------- | ----------- | ----------------------- | --------------------------------- | --------------------------------- | --------------------------------- | ------------------------------------------------ | ------------------------------------------------ | ------------------------------------------------ | ------------------------------------------------ | ------------------------------------------------ | -------------------------------------- | ------------------------------------------------ | ----------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------- |
| bernoulli-nb              | Bernoulli Naive Bayes             | Binary      | Yes<br />Type: `number` | Yes<br />Type: `number`           | Yes<br />Type: `number`           | Yes<br />Type: `number`           | Yes (Native)<br />Type: `number`                 | Yes<br />Type: `number`                          | Yes<br />Type: `number`                          | Yes<br />Type: `number`                          | Yes<br />Type: `number`                          | Yes<br />Type: `number`                | Yes (Native)<br />Type: `number`                 | Yes<br />Type: `number`                                                             | Yes<br />Type: `number`                                                             |
| bernoulli-nb              | Bernoulli Naive Bayes             | Multi-class | Yes<br />Type: `number` | Yes (Average)<br />Type: `number` | Yes (Average)<br />Type: `number` | Yes (Average)<br />Type: `number` | Yes (Native)<br />Type: `number`                 | Yes<br />(One-vs-Rest)<br />Type: `Float32Array` | Yes<br />(One-vs-Rest)<br />Type: `Float32Array` | Yes<br />(One-vs-Rest)<br />Type: `Float32Array` | Yes<br />(One-vs-Rest)<br />Type: `Float32Array` | Yes<br />Type: `number`                | Yes (Native)<br />Type: `number`                 | Yes<br />(One-vs-Rest)<br />Type: `number \| Float32Array`                          | Yes<br />(One-vs-Rest)<br />Type: `number \| Float32Array`                          |
| decision-tree-classifier  | DecisionTreeClassifier            | Binary      | Yes<br />Type: `number` | Yes<br />Type: `number`           | Yes<br />Type: `number`           | Yes<br />Type: `number`           | Yes (Uncalibrated)<br />Type: `number`           | Yes<br />Type: `number`                          | Yes<br />Type: `number`                          | Yes<br />Type: `number`                          | Yes<br />Type: `number`                          | Yes<br />Type: `number`                | Yes (Coarse purity)<br />Type: `number`          | Yes<br />Type: `number`                                                             | Yes<br />Type: `number`                                                             |
| decision-tree-classifier  | DecisionTreeClassifier            | Multi-class | Yes<br />Type: `number` | Yes (Average)<br />Type: `number` | Yes (Average)<br />Type: `number` | Yes (Average)<br />Type: `number` | Yes (Uncalibrated)<br />Type: `number`           | Yes<br />(One-vs-Rest)<br />Type: `Float32Array` | Yes<br />(One-vs-Rest)<br />Type: `Float32Array` | Yes<br />(One-vs-Rest)<br />Type: `Float32Array` | Yes<br />(One-vs-Rest)<br />Type: `Float32Array` | Yes<br />Type: `number`                | Yes (Coarse purity)<br />Type: `number`          | Yes<br />(One-vs-Rest)<br />Type: `number \| Float32Array`                          | Yes<br />(One-vs-Rest)<br />Type: `number \| Float32Array`                          |
| gaussian-nb               | Gaussian Naive Bayes              | Binary      | Yes<br />Type: `number` | Yes<br />Type: `number`           | Yes<br />Type: `number`           | Yes<br />Type: `number`           | Yes (Native)<br />Type: `number`                 | Yes<br />Type: `number`                          | Yes<br />Type: `number`                          | Yes<br />Type: `number`                          | Yes<br />Type: `number`                          | Yes<br />Type: `number`                | Yes (Native)<br />Type: `number`                 | Yes<br />Type: `number`                                                             | Yes<br />Type: `number`                                                             |
| gaussian-nb               | Gaussian Naive Bayes              | Multi-class | Yes<br />Type: `number` | Yes (Average)<br />Type: `number` | Yes (Average)<br />Type: `number` | Yes (Average)<br />Type: `number` | Yes (Native)<br />Type: `number`                 | Yes<br />(One-vs-Rest)<br />Type: `Float32Array` | Yes<br />(One-vs-Rest)<br />Type: `Float32Array` | Yes<br />(One-vs-Rest)<br />Type: `Float32Array` | Yes<br />(One-vs-Rest)<br />Type: `Float32Array` | Yes<br />Type: `number`                | Yes (Native)<br />Type: `number`                 | Yes<br />(One-vs-Rest)<br />Type: `number \| Float32Array`                          | Yes<br />(One-vs-Rest)<br />Type: `number \| Float32Array`                          |
| k-neighbors-classifier    | KNeighborsClassifier              | Binary      | Yes<br />Type: `number` | Yes<br />Type: `number`           | Yes<br />Type: `number`           | Yes<br />Type: `number`           | Yes (Neighbor vote)<br />Type: `number`          | Yes<br />Type: `number`                          | Yes<br />Type: `number`                          | Yes<br />Type: `number`                          | Yes<br />Type: `number`                          | Yes<br />Type: `number`                | Yes (Neighbor vote)<br />Type: `number`          | Yes<br />Type: `number`                                                             | Yes<br />Type: `number`                                                             |
| k-neighbors-classifier    | KNeighborsClassifier              | Multi-class | Yes<br />Type: `number` | Yes (Average)<br />Type: `number` | Yes (Average)<br />Type: `number` | Yes (Average)<br />Type: `number` | Yes (Neighbor vote)<br />Type: `number`          | Yes<br />(One-vs-Rest)<br />Type: `Float32Array` | Yes<br />(One-vs-Rest)<br />Type: `Float32Array` | Yes<br />(One-vs-Rest)<br />Type: `Float32Array` | Yes<br />(One-vs-Rest)<br />Type: `Float32Array` | Yes<br />Type: `number`                | Yes (Neighbor vote)<br />Type: `number`          | Yes<br />(One-vs-Rest)<br />Type: `number \| Float32Array`                          | Yes<br />(One-vs-Rest)<br />Type: `number \| Float32Array`                          |
| logistic-regression       | LogisticRegression                | Binary      | Yes<br />Type: `number` | Yes<br />Type: `number`           | Yes<br />Type: `number`           | Yes<br />Type: `number`           | Yes (Native)<br />Type: `number`                 | Yes<br />Type: `number`                          | Yes<br />Type: `number`                          | Yes<br />Type: `number`                          | Yes<br />Type: `number`                          | Yes<br />Type: `number`                | Yes (Native)<br />Type: `number`                 | Yes<br />Type: `number`                                                             | Yes<br />Type: `number`                                                             |
| logistic-regression       | LogisticRegression                | Multi-class | Yes<br />Type: `number` | Yes (Average)<br />Type: `number` | Yes (Average)<br />Type: `number` | Yes (Average)<br />Type: `number` | Yes (Native)<br />Type: `number`                 | Yes<br />(One-vs-Rest)<br />Type: `Float32Array` | Yes<br />(One-vs-Rest)<br />Type: `Float32Array` | Yes<br />(One-vs-Rest)<br />Type: `Float32Array` | Yes<br />(One-vs-Rest)<br />Type: `Float32Array` | Yes<br />Type: `number`                | Yes (Native)<br />Type: `number`                 | Yes<br />(One-vs-Rest)<br />Type: `number \| Float32Array`                          | Yes<br />(One-vs-Rest)<br />Type: `number \| Float32Array`                          |
| mlp-classifier            | Multi-Layer Perceptron Classifier | Binary      | Yes<br />Type: `number` | Yes<br />Type: `number`           | Yes<br />Type: `number`           | Yes<br />Type: `number`           | Yes (Requires softmax)<br />Type: `number`       | Yes<br />Type: `number`                          | Yes<br />Type: `number`                          | Yes<br />Type: `number`                          | Yes<br />Type: `number`                          | Yes<br />Type: `number`                | Yes (Requires softmax)<br />Type: `number`       | Yes<br />Type: `number`                                                             | Yes<br />Type: `number`                                                             |
| mlp-classifier            | Multi-Layer Perceptron Classifier | Multi-class | Yes<br />Type: `number` | Yes (Average)<br />Type: `number` | Yes (Average)<br />Type: `number` | Yes (Average)<br />Type: `number` | Yes (Requires softmax)<br />Type: `number`       | Yes<br />(One-vs-Rest)<br />Type: `Float32Array` | Yes<br />(One-vs-Rest)<br />Type: `Float32Array` | Yes<br />(One-vs-Rest)<br />Type: `Float32Array` | Yes<br />(One-vs-Rest)<br />Type: `Float32Array` | Yes<br />Type: `number`                | Yes (Requires softmax)<br />Type: `number`       | Yes<br />(One-vs-Rest)<br />Type: `number \| Float32Array`                          | Yes<br />(One-vs-Rest)<br />Type: `number \| Float32Array`                          |
| multinomial-nb            | Multinomial Naive Bayes           | Binary      | Yes<br />Type: `number` | Yes<br />Type: `number`           | Yes<br />Type: `number`           | Yes<br />Type: `number`           | Yes (Native)<br />Type: `number`                 | Yes<br />Type: `number`                          | Yes<br />Type: `number`                          | Yes<br />Type: `number`                          | Yes<br />Type: `number`                          | Yes<br />Type: `number`                | Yes (Native)<br />Type: `number`                 | Yes<br />Type: `number`                                                             | Yes<br />Type: `number`                                                             |
| multinomial-nb            | Multinomial Naive Bayes           | Multi-class | Yes<br />Type: `number` | Yes (Average)<br />Type: `number` | Yes (Average)<br />Type: `number` | Yes (Average)<br />Type: `number` | Yes (Native)<br />Type: `number`                 | Yes<br />(One-vs-Rest)<br />Type: `Float32Array` | Yes<br />(One-vs-Rest)<br />Type: `Float32Array` | Yes<br />(One-vs-Rest)<br />Type: `Float32Array` | Yes<br />(One-vs-Rest)<br />Type: `Float32Array` | Yes<br />Type: `number`                | Yes (Native)<br />Type: `number`                 | Yes<br />(One-vs-Rest)<br />Type: `number \| Float32Array`                          | Yes<br />(One-vs-Rest)<br />Type: `number \| Float32Array`                          |
| support-vector-classifier | Support Vector Classifier         | Binary      | Yes<br />Type: `number` | Yes<br />Type: `number`           | Yes<br />Type: `number`           | Yes<br />Type: `number`           | Yes (Requires Platt scaling)<br />Type: `number` | Yes<br />Type: `number`                          | Yes<br />Type: `number`                          | Yes<br />Type: `number`                          | Yes<br />Type: `number`                          | Yes<br />Type: `number`                | Yes (Requires Platt scaling)<br />Type: `number` | Yes (Can use raw decision_function)<br />Type: `number`                             | Yes (Can use raw decision_function)<br />Type: `number`                             |
| support-vector-classifier | Support Vector Classifier         | Multi-class | Yes<br />Type: `number` | Yes (Average)<br />Type: `number` | Yes (Average)<br />Type: `number` | Yes (Average)<br />Type: `number` | Yes (Requires Platt scaling)<br />Type: `number` | Yes<br />(One-vs-Rest)<br />Type: `Float32Array` | Yes<br />(One-vs-Rest)<br />Type: `Float32Array` | Yes<br />(One-vs-Rest)<br />Type: `Float32Array` | Yes<br />(One-vs-Rest)<br />Type: `Float32Array` | Yes<br />Type: `number`                | Yes (Requires Platt scaling)<br />Type: `number` | Yes (Requires Platt scaling for One-vs-One fix)<br />Type: `number \| Float32Array` | Yes (Requires Platt scaling for One-vs-One fix)<br />Type: `number \| Float32Array` |

### Regression Metrics

### Regression Metric Definitions

#### Mean Squared Error (MSE)

$$\text{MSE} = \frac{1}{n} \sum_{i=1}^{n} (y_i - \hat{y}_i)^2$$

#### Root Mean Squared Error (RMSE)

$\text{RMSE}_j = \sqrt{\text{MSE}_j}$

For multiple outputs, average the per-output square roots uniformly. RMSLE uses
the same per-output square-root averaging.

#### Mean Absolute Error (MAE)

$$\text{MAE} = \frac{1}{n} \sum_{i=1}^{n} \vert{}y_i - \hat{y}_i\vert{}$$

#### Mean Absolute Percentage Error (MAPE)

MAPE is the mean of absolute relative errors as a fraction, skipping targets
equal to zero. Each output is averaged over its nonzero targets; the scalar is
the uniform average of defined outputs. A report counts skipped elements and
marks MAPE `all-targets-zero` when none remain; standalone calls throw.

#### Median Absolute Error (MedAE)

$$\text{MedAE} = \text{median}(\vert{}y_1 - \hat{y}_1\vert{}, \dots, \vert{}y_n - \hat{y}_n\vert{})$$

_Robustness:_ Outlier-insensitive metric; requires sorting the array of absolute residuals.

#### Coefficient of Determination ($R^2$)

$$R^2 = 1 - \frac{\sum_{i=1}^n (y_i - \hat{y}_i)^2}{\sum_{i=1}^n (y_i - \bar{y})^2}$$

Can return negative values if the model predicts worse than the constant mean baseline $\bar{y}$.

#### \*Adjusted $R^2$ ($\text{Adj } R^2$)

$$\text{Adj } R^2 = 1 - \left[ \frac{(1 - R^2)(n - 1)}{n - p - 1} \right]$$

Here $n$ is the number of scored rows and $p$ is the count of **fitted predictor
columns delivered to the estimator**, excluding the intercept or bias term. The standalone
`adjustedR2Score` uses the count its caller supplies. Ordinary validation, tuning reports and
nested CV derive the count from the fitted estimator, with or without preprocessing, and require no
rank or variability estimate:

- single-output, unpenalised linear OLS with a fitted intercept: every column delivered to the
  estimator, including a constant numeric column and an all-one indicator;
- after PCA: the number of retained components;
- single-output, unpenalised polynomial OLS with an intercept or polynomial bias: the fitted expanded
  width `nOutputFeatures_ - Number(includeBias)`.

When `n ≤ p + 1` the field is unavailable with `insufficient-degrees-of-freedom`; an
ineligible estimator gives `not-applicable`. Inner-fold tuning reports and nested outer reports pool
the source-ordered predictions with the pooled sample count and a common `p`, and only when every
contributing fit supplies the same eligible count. An ineligible fit or unequal counts give pooled
`not-applicable`. Fixed CV keeps its existing scalar summaries and does not report adjusted R².

#### Explained Variance Score (EVS)

$$\text{EVS} = 1 - \frac{\text{Var}(y - \hat{y})}{\text{Var}(y)}$$

Differs from $R^2$ only when the residual mean error $\mathbb{E}[y - \hat{y}] \neq 0$ (unbiased predictions yield $\text{EVS} = R^2$).

#### Max Error (ME)

$$\text{ME} = \max_i (\vert{}y_i - \hat{y}_i\vert{})$$

#### Mean Squared Logarithmic Error (MSLE)

$$\text{MSLE} = \frac{1}{n} \sum_{i=1}^{n} (\ln(1 + y_i) - \ln(1 + \hat{y}_i))^2$$

_Domain restriction:_ Negative targets make MSLE and RMSLE unavailable; negative
predictions are clipped to zero.

### Regression Model Metric Support

| Model ID                   | Model Name                       | Mean Squared Error (MSE)                                                                                     | Root Mean Squared Error (RMSE) | Mean Absolute Error (MAE)                                                                              | Mean Absolute Percentage Error (MAPE)                         | Median Absolute Error (MedAE) | Coefficient of Determination ($R^2$) | Adjusted $R^2$ ($\text{Adj } R^2$)  | Explained Variance Score (EVS)                                                 | Max Error (ME)          | Mean Squared Logarithmic Error (MSLE)                                                                   |
| -------------------------- | -------------------------------- | ------------------------------------------------------------------------------------------------------------ | ------------------------------ | ------------------------------------------------------------------------------------------------------ | ------------------------------------------------------------- | ----------------------------- | ------------------------------------ | ----------------------------------- | ------------------------------------------------------------------------------ | ----------------------- | ------------------------------------------------------------------------------------------------------- |
| `k-neighbors-regressor`    | KNeighborsRegressor              | Yes<br />Type: `number`                                                                                      | Yes<br />Type: `number`        | Yes<br />Type: `number`                                                                                | Yes<br />Type: `number`<br />_Note: Zero targets are skipped_ | Yes<br />Type: `number`       | Yes<br />Type: `number`              | Not applicable                      | Yes<br />Type: `number`                                                        | Yes<br />Type: `number` | Yes<br />Type: `number`<br />_Note: Negative targets are unavailable; negative predictions are clipped_ |
| `linear-regression`        | Linear Regression                | Yes<br />Type: `number`                                                                                      | Yes<br />Type: `number`        | Yes<br />Type: `number`                                                                                | Yes<br />Type: `number`<br />_Note: Zero targets are skipped_ | Yes<br />Type: `number`       | Yes<br />Type: `number`              | Eligible OLS with intercept or bias | Yes<br />Type: `number`<br />_Note: Identical to $R^2$ if intercept is fitted_ | Yes<br />Type: `number` | Yes<br />Type: `number`<br />_Note: Negative targets are unavailable; negative predictions are clipped_ |
| `polynomial-regression`    | Polynomial Regression            | Yes<br />Type: `number`                                                                                      | Yes<br />Type: `number`        | Yes<br />Type: `number`                                                                                | Yes<br />Type: `number`<br />_Note: Zero targets are skipped_ | Yes<br />Type: `number`       | Yes<br />Type: `number`              | Eligible OLS with intercept or bias | Yes<br />Type: `number`<br />_Note: Identical to $R^2$ if intercept is fitted_ | Yes<br />Type: `number` | Yes<br />Type: `number`<br />_Note: Negative targets are unavailable; negative predictions are clipped_ |
| `mlp-regressor`            | Multi-Layer Perceptron Regressor | Yes<br />Type: `number`<br />_Note: Corresponds directly to MSE training loss with linear output activation_ | Yes<br />Type: `number`        | Yes<br />Type: `number`                                                                                | Yes<br />Type: `number`<br />_Note: Zero targets are skipped_ | Yes<br />Type: `number`       | Yes<br />Type: `number`              | Not applicable                      | Yes<br />Type: `number`                                                        | Yes<br />Type: `number` | Yes<br />Type: `number`<br />_Note: Negative targets are unavailable; negative predictions are clipped_ |
| `support-vector-regressor` | Support Vector Regressor         | Yes<br />Type: `number`                                                                                      | Yes<br />Type: `number`        | Yes<br />Type: `number`<br />_Note: Correlates with $\epsilon$-insensitive loss when $\epsilon \to 0$_ | Yes<br />Type: `number`<br />_Note: Zero targets are skipped_ | Yes<br />Type: `number`       | Yes<br />Type: `number`              | Not applicable                      | Yes<br />Type: `number`                                                        | Yes<br />Type: `number` | Yes<br />Type: `number`<br />_Note: Negative targets are unavailable; negative predictions are clipped_ |
| `decision-tree-regressor`  | DecisionTreeRegressor            | Yes<br />Type: `number`<br />_Note: Matches internal node impurity when criterion is squared error_          | Yes<br />Type: `number`        | Yes<br />Type: `number`<br />_Note: Matches internal node impurity when criterion is absolute error_   | Yes<br />Type: `number`<br />_Note: Zero targets are skipped_ | Yes<br />Type: `number`       | Yes<br />Type: `number`              | Not applicable                      | Yes<br />Type: `number`                                                        | Yes<br />Type: `number` | Yes<br />Type: `number`<br />_Note: Negative targets are unavailable; negative predictions are clipped_ |

# Ordinary training validation

Supervised ordinary training requests can supply `validation: { data,
completeMetrics?, positiveLabel? }`. The result includes `metrics` for the
held-out partition, while runs without validation omit it. Training rows alone
are used for fitting. Set `completeMetrics` for the more expensive report tier;
binary classifiers may choose a positive label present in the training rows.
Completed cache entries preserve the report and older entries may omit it.

Tuning scores use the configured class axis for selection; a single-fit report
uses its fitted class order. Optional trial reports pool inner-fold outputs in
source order and mark probability and ranking fields unavailable if a truth was
unseen by the fold model. A singleton fitted probability column represents its
sole class directly. Constant-target tuning R² is 1 for exact predictions and 0
otherwise. Trial report and scratch memory are budgeted before fitting.

Nested cross-validation optionally reports each fitted outer fold and one
source-ordered pooled report. Pooled ranking scores can compare values on
different models' scales. If any fold lacks probabilities, pooled probability
metrics are unavailable; binary oriented decision scores remain usable when
every fold supplies them. Pooled adjusted R² requires matching eligible
predictor counts. Fixed-option CV retains its arithmetic mean of fold summaries.

## Partitioned classifier evaluation

`crossValidate`, outer `nestedCrossValidate`, and `holdoutValidate` accept an optional `evaluation` object for single-label classifiers. Its independent `outputs`, `reports`, and `trainingReports` booleans default to false; `baselines` defaults to empty. An empty object returns only the effective `classLabels` and binary `positiveLabel` (otherwise null). An explicit positive label must belong to a two-label axis; the default is its second label. Existing `includeMetrics` and scorer behavior remain independent. Unsupported tasks and malformed options fail with `invalid-request` before a fit.

Outputs contain source-ordered held-out `sourceRowIndex`, zero-based `partitionIndex`, `trueIndex` and `predictedIndex`, with labels encoded on the request axis. The optional row-major Float64 probability matrix uses that axis and is null unless every partition supplies probabilities. A binary `positiveScores` array uses oriented SVC decision margins, including uncalibrated SVC, or the positive probability column for other classifiers. Its source is `decision-function` or `probability`; no hard-label score is synthesized. Buffers are fresh and independently transferable.

Reports include each partition and a pooled report over its actual held-out rows. Binary axes of one or two classes use binary metrics; larger axes use multiclass metrics. Confusion matrices are truth-by-prediction in the request axis, with support, predicted counts, balanced accuracy, macro F1, per-class values, and an availability-wrapped MCC. A one-class report has unavailable ranking metrics. Missing probabilities make probability losses unavailable; SVC margins may still support ranking. Truth absent from its fitted partition takes precedence with `unseen-validation-labels`. Training reports score each fit’s own training complement and are not pooled.

The most-frequent baseline breaks count ties by axis order and emits a one-hot distribution. The stratified baseline draws from the training complement’s empirical frequencies, once per held-out source row using a partition-specific seeded stream; its probability distribution is those frequencies. Baselines use the same partitions and report rules as the model. Pooled cross-fold ranking compares scores from different fits and may compare different calibration scales.

`holdoutValidate` delegates once to `stratifiedTrainTestSplit`, fits once through the worker client, and returns owned train and validation indices, diagnostics, optional transformed feature names and evaluation data. Its run provides fold events, a result, cancellation and end-to-end timing. Evaluation does not change fitted thresholds or selection.

`holdoutValidate` also accepts the opt-in request field `returnFit: true` (a present non-boolean fails with
`invalid-request`, `returnFit must be a boolean.`, before any fit). A successful run then returns the evaluated
training-partition fit as `result.fit` (`HoldoutValidationFit`): the hydrated `model`, the fitted `preprocessor`
and `featureNamesOut` when `preprocessing` is set, `sampleCount` equal to `trainIndices.length`, and a fit-only
`durationMs`. These are the objects that produced the result's diagnostics and evaluation, never a refit on all
rows, and the preprocessor is learned from the training rows only. The caller owns the model and must dispose
SVC models; the library disposes it on failure or cancellation, and returns no result then. Without `returnFit`
(or with `false`) the result has no `fit` key and the model is disposed as before. The fit is restored through
the public serialisation: `ModelClass.fromJSON(structuredClone(fit.model.toJSON()))` and
`FittedTabularPreprocessor.fromJSON(fit.preprocessor.toJSON())`.

`rocCurve` groups equal scores, includes all ties under `score >= threshold` and ends at (1, 1). `precisionRecallCurve` returns ascending thresholds and a threshold-free terminal (precision 1, recall 0); its step-weighted area agrees with average precision. Both return `single-class` when either class is absent. `oneVsRestCurves` follows the explicit axis and reports unavailability independently per class. Uniform calibration returns bin counts and means, NaN means for empty bins, and weighted expected calibration error; top-label ties select the earliest class. Binary singleton calibration needs an explicit positive label or two-label axis. Threshold sweeps preserve the caller’s order, duplicates and infinite sentinels. Curves reject empty, malformed, non-finite or incompatible inputs with `RangeError`; probability values must be in [0, 1] and matrix rows must sum to one within 1e-6.

Stratified baseline partition `i` seeds `createRandom(((randomState ?? 0) | 0) ^ Math.imul(i + 1, 0x9e3779b9))`, consumes one draw per held-out row in ascending source order and chooses the first cumulative training count strictly above the scaled draw. Strategy order and other flags do not affect those draws.
