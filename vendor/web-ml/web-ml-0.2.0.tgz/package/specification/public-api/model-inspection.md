# Model inspection

**Status:** current

Fitted classifiers expose what they learned, so callers can debug, teach and audit a model
without re-implementing its arithmetic. Everything here is stable public API, runs on the
calling thread, never starts a training worker and never mutates its inputs. Result arrays are
freshly allocated ordinary typed arrays owned by the caller, and getters return copies on every
access. Where this page and `src/` disagree, `src/` is wrong. Examples live in the
[model inspection guide](../../user-guide/model-inspection.md).

Contributions and importances are per **model input column**. When tabular preprocessing
produced the columns, map them back with `featureNamesOut`; mapping one-hot columns to source
columns is not provided.

## Decision tree

`DecisionTreeClassifier` records `samples`, `classCounts` (on the sorted `classes_` axis) and
`impurity` for every node at fit time, in both fit paths, and carries them in portable state.
`maxDepth_` is the **realised** depth with the root at depth 0, not the configured `maxDepth`;
`nodeCount_` counts every node.

```ts
interface DecisionTreeStructure {
	readonly nodeCount: number;
	readonly classes: readonly ClassificationLabel[]; // copy of classes_
	readonly childrenLeft: Int32Array; // -1 for a leaf
	readonly childrenRight: Int32Array; // -1 for a leaf
	readonly feature: Int32Array; // -1 for a leaf
	readonly threshold: Float64Array; // NaN for a leaf
	readonly impurity: Float64Array;
	readonly nodeSamples: Uint32Array;
	readonly depth: Uint32Array; // root 0
	readonly classCounts: Uint32Array; // nodeCount x classes.length, row-major
}

interface DecisionTreePath {
	readonly indptr: Uint32Array; // length rows + 1, indptr[0] = 0
	readonly indices: Uint32Array; // node indices, root to leaf, per row
}
```

| Member                | Meaning                                                                         |
| --------------------- | ------------------------------------------------------------------------------- |
| `tree_`               | `DecisionTreeStructure`. Throws when the state lacks node statistics (below).   |
| `nLeaves_`            | Number of nodes whose `feature` is `-1`.                                        |
| `featureImportances_` | `Float64Array`, length `nFeaturesIn_`, mean decrease in impurity, summing to 1. |
| `apply(X)`            | `Uint32Array`: the leaf node index reached by each row.                         |
| `decisionPath(X)`     | `DecisionTreePath` in compressed sparse row form.                               |

- Node `i` is the `i`-th node of a pre-order traversal that visits the left child first. Row
  `i` of `classCounts` gives the training rows reaching node `i` per class and sums to
  `nodeSamples[i]`.
- A row goes left when `X[row, feature[i]] <= threshold[i]` and right otherwise, **including
  `NaN`**, exactly as prediction routes it. Each row's path starts at 0, ends at
  `apply(X)[row]`, is strictly increasing and has length `depth[leaf] + 1`.
- `impurity[i]` is Gini `1 - sum p^2`, or `-sum p log2 p` (bits) for `entropy` and `log_loss`,
  with `p = classCounts / nodeSamples` and `0 log 0 = 0`; a pure node has exactly 0. Both fit
  paths record it through one shared kernel, so equal counts give bit-identical values.
- `featureImportances_`: for every internal node `t` with children `l`, `r`, add
  `n_t imp_t - n_l imp_l - n_r imp_r` to `feature[t]`, divide every total by the root's sample
  count, then normalise to sum 1. A tree with no impurity decrease returns all zeros.
- `apply` and `decisionPath` validate `X` like prediction (fitted model, 2-D matrix, `nFeaturesIn_`
  columns) and throw the same errors.
- **Legacy states.** A state saved before node statistics hydrates and predicts, and supports
  `apply`, `decisionPath` and `nLeaves_`, but `tree_` and `featureImportances_` throw an `Error`
  saying the state lacks node statistics and the model must be refitted.
- **Worker and direct fits.** Both implement the same split search and tie order (lower feature,
  then lower threshold) but evaluate gains with different floating-point grouping. Worker- and
  direct-fitted trees agree exactly (structure, thresholds, counts, impurity) only when no split
  is near-tied; on near-tied gains they may choose different splits.

## Naive Bayes

| Member                    | Models                         | Meaning                                                                                          |
| ------------------------- | ------------------------------ | ------------------------------------------------------------------------------------------------ |
| `classLogPrior_`          | `MultinomialNB`, `BernoulliNB` | `NumericTensor` `[K]` in `classes_` order: the stored `log(prior + 1e-15)` used by prediction.   |
| `featureLogProb_`         | `BernoulliNB`                  | `NumericTensor` `[K, p]`: `log((N_cj + alpha) / (N_c + 2 alpha))`, the presence log probability. |
| `predictJointLogProba(X)` | all three                      | `NumericTensor` `[n, K]`: the unnormalised joint log-likelihood.                                 |

`prior` follows `classPrior`, otherwise `fitPrior` (empirical) or uniform; for empirical and
uniform priors `sum exp(classLogPrior_) = 1` within `1e-12`.

Joint log-likelihood of class `c`:

- GaussianNB: `log(classPrior_[c] + 1e-15) + sum_j (-0.5 log(2 pi var_cj) - (x_j - theta_cj)^2 / (2 var_cj))`.
  User-supplied `priors` are used unnormalised, so the base term is the model's own
  `log(prior + 1e-15)`.
- MultinomialNB: `classLogPrior_[c] + sum_j x_j featureLogProb_[c][j]`; negative input throws.
- BernoulliNB: `classLogPrior_[c] + sum_j (x_j > binarize ? featureLogProb_[c][j] : log(1 - exp(featureLogProb_[c][j])))`,
  using the stored negative term. The constructor maps `binarize: null` to `0`, and contributions
  follow that implemented behaviour.

Row-wise softmax of `predictJointLogProba` equals `predictProba` within `1e-12`, and
`predict`, `predictProba` and `predictJointLogProba` share one score routine. A matrix with the
wrong column count throws `Error('X has N features, but <Model> is expecting M features.')` from
every method.

## Logistic regression

`decisionFunction(X): NumericTensor` returns `intercept_k + sum_j coef_kj x_j`, summed from the
intercept in ascending `j` in Float64. Binary models give shape `[n, 1]`, the score for
`classes_[1]`; multiclass one-vs-rest and multi-label models give `[n, K]` in `classes_` order.
It does not apply the configured or tuned decision threshold.

`sigmoid(decisionFunction)` equals the matching `predictProba` column within `1e-7`, and for
non-multi-label multiclass the row argmax equals `predict`.

`predict`, `predictProba` and `decisionFunction` check the column count before any backend call:
a model that is not fitted throws the usual unfitted `Error`; a matrix whose column count `q`
differs from the coefficient column count `p` throws
`Error('X has <q> features, but LogisticRegression is expecting <p> features.')`. Valid inputs
are unaffected. SVC `decisionFunction` stays pairwise one-vs-one.

## Feature contributions

```ts
type ContributionModel = GaussianNB | MultinomialNB | BernoulliNB | LogisticRegression;

interface FeatureContributions {
	readonly score: 'joint-log-likelihood' | 'decision-function';
	readonly rowCount: number;
	readonly featureCount: number;
	readonly columnLabels: readonly ClassificationLabel[];
	readonly values: Float64Array;
}

function featureContributions(model: ContributionModel, X: MatrixLike): FeatureContributions;
```

`columnLabels` has one label per score column: `classes_` for Naive Bayes and for multiclass or
multi-label logistic regression, and `[classes_[1]]` for binary logistic regression. With
`C = columnLabels.length` and `T = featureCount + 1`, `values[(row * C + c) * T]` is the base term
and `values[(row * C + c) * T + 1 + j]` is the term for input column `j`.

The base and feature terms are exactly the summands of `predictJointLogProba` (Naive Bayes) or
`decisionFunction` (logistic regression) in the same order, so their left-to-right sum reproduces
those outputs **bit for bit**. For Naive Bayes the column argmax of the sums equals `predict`. A
BernoulliNB column that is absent contributes its stored negative log probability.

Errors: a model that is not one of the four classes throws `TypeError` naming the supported
models; an unfitted model or invalid `X` throws the model's own prediction error; a layout of
`rows * C * T` elements that is not a safe integer or exceeds `2 ** 31 - 1` throws `RangeError`
before allocating. Memory is `8 * rows * C * T` bytes.

## MLP validation loss

`MLPClassifier` and `MLPRegressor` accept `validationFraction?: number | null` (default `null`).
A value must be finite and strictly between 0 and 1: the constructor throws a plain `Error` and the
worker path rejects with `invalid-request` otherwise.

When set, the fit's rows are split before training:

- Classifiers use `stratifiedTrainTestSplit` with `testRatio: validationFraction` and
  `randomState ?? 0`, so its `TrainingError`s (such as a class with one row) propagate.
- Regressors take `nVal = ceil(validationFraction * n)` rows, require `1 <= nVal <= n - 1`
  (otherwise `invalid-request`, a plain `Error` on the direct path) and select them with a
  seeded Fisher-Yates shuffle seeded with `randomState ?? 0`.

Both index sets are ascending, and the split is reproducible even when weight initialisation is
not. The model trains exactly as before on the training rows only (they define the class
encoding, divisors and worker shards), so the fit equals a fit without `validationFraction` on
those rows alone. At each epoch, before the optimizer update, the validation loss is the same
training objective evaluated on the validation rows with the same pre-update parameters, divided
by `nVal` (classifier) or `nVal * targetCount` (regressor). The worker path evaluates it by
dispatching `mlp-gradient` on validation shards and discarding the gradients; the direct path uses
its own loss routine.

- `validationLossCurve_: number[] | null` has the same length as `lossCurve_`, entry `i` aligned
  with `lossCurve_[i]`.
- `bestEpoch_: number | null` is the first index of the minimum finite entry, or `null` when none
  is finite. Both are `null` without `validationFraction`.
- The stop rule, `nIter_`, `TrainingLossItem` history and returned weights are unchanged. The fitted
  model keeps its **final** weights, `tol` keeps monitoring the training objective, and
  `bestEpoch_` is informational. `earlyStopping`, `nIterNoChange`, best-weight restoration and L2
  `alpha` remain unsupported.
- Portable state gains `validationLossCurve`; a state without it hydrates as `null`. The worker
  `MLPClassifierTrainingResult` and `MLPRegressorTrainingResult` carry an optional
  `validationLossCurve`, present only when `validationFraction` is set.
- A run resumed from a checkpoint rejects `validationFraction` (`invalid-request`).

**Determinism.** Two fits with equal inputs, options and `randomState` on the same path and
runtime give bit-identical `lossCurve_` and `validationLossCurve_`. The worker and direct paths use
separate optimizers and reductions and are not required to agree. The worker summation order
depends on its shard count, `min(4, hardwareConcurrency - 1, ceil(n / 1024))`, so worker curves are
repeatable on one runtime but can differ across machines.

**Preprocessing note.** The internal split is taken from the fit's input after any tabular
preprocessing, so imputation and scaling statistics are learned from rows that include the
validation share. Callers who need a strictly unseen holdout use the evaluation entry points.

## Permutation importance

```ts
type PermutationImportanceScoring = 'accuracy' | 'f1' | 'r2' | 'mean-squared-error';

interface PermutationImportanceData {
	readonly features: MatrixLike;
	readonly targets: readonly ClassificationLabel[] | VectorLike;
}

interface PermutationImportanceOptions {
	readonly scoring: PermutationImportanceScoring;
	readonly nRepeats?: number; // integer >= 1, default 5
	readonly randomState?: number; // finite, default 0
	readonly classLabels?: readonly ClassificationLabel[];
	readonly signal?: AbortSignal;
}

interface PermutationImportanceResult {
	readonly scoring: PermutationImportanceScoring;
	readonly baselineScore: number;
	readonly featureCount: number;
	readonly nRepeats: number;
	readonly importancesMean: Float64Array; // length featureCount
	readonly importancesStd: Float64Array; // population standard deviation
	readonly importances: Float64Array; // featureCount x nRepeats, [j * nRepeats + r]
}

function permutationImportance(
	model: Classifier | Regressor,
	data: PermutationImportanceData,
	options: PermutationImportanceOptions
): Promise<PermutationImportanceResult>;
```

- `features` are in the model's input space. They are copied once into mutable row arrays and
  passed to the model's synchronous `predict`; inputs are never mutated. At least one row, finite
  values and a target length equal to the row count are required, otherwise `RangeError`.
- The scorers are the fixed cross-validation scorers: `'accuracy'`, binary `'f1'`, `'r2'` and
  `'mean-squared-error'` (a positive error). `'accuracy'` and `'f1'` require a classifier
  (a defined `classes_`) and compare labels with `===`; `'r2'` and `'mean-squared-error'` require a
  regressor and numeric targets. Anything else is a `RangeError`.
- `'f1'` uses entry 1 of the class axis as the positive label. The axis is `classLabels` when
  supplied (distinct labels), otherwise `model.classes_`; it needs exactly two labels. This default
  differs from fixed cross-validation, whose default axis is the integer codes `0..max(targets)`:
  an already fitted model has a known label set.
- A classifier's `predict` must return one label per row. A regressor's must return one value per
  row, shape `[n]` or `[n, 1]` (a single-target `MLPRegressor` returns `[n, 1]`). Any other shape,
  including a multi-output regressor's `[n, T]` with `T > 1`, rejects with `RangeError` stating that
  only single-output predictions are supported. The check runs on the baseline prediction, so a
  rejected model is called exactly once.
- The importance of column `j` for a repeat is `baseline - permuted` for `'accuracy'`, `'f1'` and
  `'r2'` and `permuted - baseline` for `'mean-squared-error'`. Each column has its own xorshift32
  stream seeded `((randomState ?? 0) | 0) ^ Math.imul(j + 1, 0x9e3779b9)`; each repeat shuffles the
  identity permutation with the partitions Fisher-Yates routine and writes the column in that order,
  then the column is restored. A column's draws do not depend on other columns, equal inputs and
  `randomState` give identical results, and a column with no effect on predictions has all
  importances exactly 0.
- The signal is checked before the baseline, before each permuted evaluation and before resolving,
  and the run yields with `setTimeout(..., 0)` after each evaluation. An aborted signal rejects
  with a `DOMException` named `AbortError` and calls `predict` no further. Errors thrown by `predict`
  reject unchanged.
- Cost: `1 + featureCount * nRepeats` prediction calls plus one copy of the features.
