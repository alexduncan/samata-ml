# Current limitations

Classification findings were rechecked on 20 November 2026 using the public APIs
in the Bun worker harness. The broader inventory dates from 10 October 2026.
Model support here refers to the exported library and its production worker path.

## Classification fixes in recommended order

1. **Preserve impossible events when saving BernoulliNB and MultinomialNB.**
   With `alpha: 0` and the default `forceAlpha: true`, a zero likelihood has
   log probability `-Infinity`. JSON text converts it to `null`, which
   `fromJSON()` accepts and prediction treats as zero in log space. Fit labels
   `["a", "b"]` to rows `[[0], [1]]` for BernoulliNB or `[[1, 0], [0, 1]]`
   for MultinomialNB. For the second row, both fitted models return `"b"` with
   probabilities `[0, 1]`. After `fromJSON(JSON.parse(JSON.stringify(model)))`,
   both return `"a"` with `[0.5, 0.5]`. A fix must preserve the predicted label
   and probabilities across that text round trip. [BernoulliNB state](../../src/models/bayesian/bernoulli-nb.ts)
   and [MultinomialNB state](../../src/models/bayesian/multinomial-nb.ts).

## Current Classification Support

| Model name             | Binary Classification | Multi-class Classification | Multinomial (joint softmax) | Multi-Label              |
| ---------------------- | --------------------- | -------------------------- | --------------------------- | ------------------------ |
| LogisticRegression     | ✅                    | ✅ (one-vs-rest)           | ❌                          | ✅ (independent sigmoid) |
| MLPClassifier          | ✅                    | ✅                         | ✅                          | ❌                       |
| DecisionTreeClassifier | ✅                    | ✅                         | ❌                          | ❌                       |
| KNeighborsClassifier   | ✅                    | ✅                         | ❌                          | ❌                       |
| GaussianNB             | ✅                    | ✅                         | ❌                          | ❌                       |
| MultinomialNB          | ✅                    | ✅                         | ❌                          | ❌                       |
| BernoulliNB            | ✅                    | ✅                         | ❌                          | ❌                       |
| SVC                    | ✅                    | ✅                         | ❌                          | ❌                       |

## Model completeness and task support

- **Every exported model family has worker-backed training.** Linear and polynomial
  regression, logistic regression, both MLPs, both decision trees, both K-neighbors
  models, all three Naive Bayes classifiers, SVC, SVR, K-means, and PCA are accepted
  by `createTrainingClient().train(...)`. None is restricted to synchronous
  page-side fitting. Constructors configure estimators; ordinary `run.result`
  supplies an object containing the fitted `model`. Prediction and inspection remain synchronous.
- **LogisticRegression supports binary and one-vs-rest single-label classification,
  plus indicator-matrix multi-label classification.** It uses independent sigmoid
  outputs, not joint softmax probabilities. Multi-label training uses one binary
  target column per ordered `classLabels` entry. Tuning and nested CV support
  multi-label reports and exact-set accuracy; fixed CV and PCA pipelines do not.
- **The other classifiers support multiclass classification:** MLPClassifier,
  DecisionTreeClassifier, KNeighborsClassifier, GaussianNB, MultinomialNB,
  BernoulliNB, and SVC. Binary MLP classification uses one sigmoid output and
  multiclass MLP uses softmax. SVC uses one-vs-one decisions.
- **Only MLPRegressor supports multiple regression outputs in the training API.**
  LinearRegression, PolynomialRegression, DecisionTreeRegressor,
  KNeighborsRegressor, and SVR require one target per sample.
- **PCA is a reusable worker-trained transformer.** Its fitted model exposes
  `transform()`, `inverseTransform()`, and versioned JSON-safe state. It retains
  the guarded feature standard deviations used during training, including unit
  scales for constant columns. Its standalone result also includes the training
  projection.
- **Automatic decision-threshold tuning is binary only.** Hyperparameter tuning
  through `createTrainingClient().train(...)`, `createTuner().search(...)`, or
  `nestedCrossValidate(...)` can select a cutoff from validation probabilities
  using accuracy or binary F1. Each request uses the same `thresholdTuning`
  option shape. The cutoff is carried into the returned fitted classifier and
  its JSON state. Multi-label LogisticRegression applies its fixed `threshold`
  to each indicator. SVC requires calibrated probabilities (`probability: true`).
  LogisticRegression's existing fixed `threshold` cannot be combined with
  automatic tuning.
- **Roadmap models are absent, not partially usable exports.** There are no Random
  Forest, Gradient Boosting, Lasso/ElasticNet estimators, DBSCAN, Gaussian Mixture
  Models, t-SNE, UMAP, bandit, Q-learning, or DQN implementations. Ridge behavior
  exists through LinearRegression's L2 penalty. Some former README evaluation
  proposals were stale: tuning, nested cross-validation, and several metrics
  already exist; automatic binary decision-threshold tuning is supported through
  all three public tuning entrypoints.

Sources: [training requests and results](../../src/training/types.ts),
[worker validation and dispatch](../../src/training/training-engine.ts),
[PCA result contract](../../src/models/dimensionality-reduction/pca.ts), [model inventory](models.md),
[roadmap status](../internals/roadmap.md).

## Shared data and training constraints

- **Training requires dense, finite, row-major Float64 data.** Batches must contain
  contiguous owned `Float64Array` feature and target buffers with explicit
  dimensions. There is no sparse CSR/CSC input, Float32 training mode, or native
  NaN/infinity handling. The one exception is the opt-in top-level `preprocessing`
  option, which accepts raw codes with `NaN` as a missing value and learns
  imputation, optional standardisation and one-hot encoding inside each fit; see
  [Tabular preprocessing](tabular-preprocessing.md). Dense requests still reject
  every non-finite feature.
  Single-label classification encodes strings, finite numbers, or booleans as
  zero-based target codes mapped through `classLabels`. Multi-label targets
  use one binary indicator per label.
- **An asynchronous batch source is not out-of-core learning.** The orchestrator
  allocates and assembles the entire declared dataset before training. Shards,
  tensors, model state, feature expansion, and WASM copies add memory overhead.
  Datasets must fit browser memory; an iterator does not remove this requirement.
- **Yielding a training batch transfers ownership and detaches its buffers.**
  Callers must allocate fresh owned batches and cannot keep using transferred
  arrays. Nested cross-validation emits fresh copies to preserve its source arrays.
- **There is no public `partialFit`, online learning, or general warm-start API.**
  Hyperband's internal checkpoint resumption does not provide arbitrary model
  continuation or resumable training after an application restart.
- **Per-sample training weights are unsupported across the public batch API.**
  `TrainingBatch` has no weight field. LogisticRegression and SVC accept
  `classWeight: 'balanced'` or a record of positive finite weights. Each record
  key must match exactly one declared label by `String(label)`. An omitted
  option or `null` uses unit weights. [Class-label options](hyperparameters.md#class-label-options).
- **PCA pipelines are supported, but there is no general preprocessing framework.**
  A pipeline fits one PCA step followed by one supported supervised estimator;
  it does not provide arbitrary transformers or multi-step chaining. The only
  built-in preprocessing is the opt-in, fixed-order tabular transformation
  (mean/mode imputation, optional standardisation, one-hot encoding) described in
  [Tabular preprocessing](tabular-preprocessing.md); there are no learnt target
  encodings, no search over preprocessing choices and no sparse backends.
  MultinomialNB is incompatible with PCA because PCA scores may be negative. The PCA
  pipeline and the tabular transformer are fitted inside each tuning or nested-CV
  training fold, while other application-managed preprocessing can still leak
  holdout data if it is fitted before cross-validation.
- **A classification PCA pipeline has one class axis.** Conflicting outer and
  embedded `classLabels` declarations are rejected with `invalid-request` before
  any source is read; a single declaration is propagated to every candidate, refit
  and hydrated result. NB priors align with the distinct **observed** labels in
  portable order (booleans, numbers, strings). The fitting path accepts
  non-negative prior vectors without checking or rescaling their sum.
- **Opt-in PCA searches reject fold-infeasible component counts as a whole.** With
  `preprocessing`, the encoded width depends on each fit's observed categories, so a
  Random Search over `nComponents` (standalone `pca` with an explicit holdout, or a
  PCA pipeline) is rejected with `invalid-request` before any candidate runs if any
  admissible count cannot fit any fitting partition. An omitted count resolves per
  fit to `min(rows, encodedWidth)`.
- **Only one training run may be active per origin.** The exclusive
  `web-ml:training` Web Lock also covers data ingestion and cleanup. Independent
  requests cannot train concurrently across tabs or library copies. A tuning run
  can schedule concurrent candidates inside its one active run.
- **Ordinary training parallelism is bounded.** Shardable runs use at most four
  compute workers, further limited by hardware concurrency and approximately one
  worker per 1,024 rows. The ordinary client has no worker-count option; tuning
  has `maxWorkers`. Small datasets use one worker even for feature-heavy tasks.
- **More workers do not remove serial stages.** Tree recursion/assembly,
  reductions, OLS solving, and PCA's symmetric eigendecomposition still have
  serial work. PCA covariance storage grows quadratically with feature count.
  K-neighbors tree index construction and certification also retain serial work.
- **Numerical backends vary by model.** Linear regression and polynomial
  regression's linear stage use Zig/WASM. LogisticRegression uses Zig/WASM for
  SGD and Adam gradients and for prediction after hydration. Its Adam reduction,
  L-BFGS and coordinate-descent updates use TypeScript. SVC and SVR use LIBSVM/WASM.
  The remaining model families use the TypeScript backend. The library has no
  WebGPU backend or automatic accelerator selection. [Model backend inventory](../internals/model-backends.md).
- **Prediction can block the UI.** The public API provides synchronous prediction,
  not a prediction worker service. Large MLP, SVM, or brute-force neighbor queries
  may need application-managed workers and model hydration.

Sources: [batch contract](../../src/training/types.ts),
[ingestion and scheduling](../../src/training/training-engine.ts),
[origin lock](../../src/training/training-orchestrator-runtime.ts),
[backend map](../../src/training/model-backends.ts), [public exports](../../index.ts).

## Model-specific hyperparameters and implementation limits

- **LinearRegression:** squared-error loss, no penalty or L2, and OLS, full-batch
  SGD, or Adam are supported. L1/ElasticNet, robust losses, non-negative
  coefficient constraints, and QR/SVD solver selection are absent. Despite the
  `sgd` name, worker updates aggregate gradients over the full dataset; there is
  no stochastic row sampling, mini-batch size, shuffle, momentum, or learning-rate
  schedule. Adam uses fixed β₁ `0.9`, β₂ `0.999`, ε `1e-8`, and learning rate
  `0.001`.
- **Rank-deficient OLS coefficients need not be unique.** The WASM solver uses
  rank-aware column-pivoted QR; the TypeScript reference uses `numpy-ts` least
  squares. Both providers are checked for rank, predictions, and residual parity,
  but their coefficients can differ for a rank-deficient design because QR returns
  a basic solution while the least-squares reference may choose a minimum-norm
  solution. The rank tolerance is internal; users cannot select QR versus SVD.
- **PolynomialRegression:** inherits the linear solver, squared-error loss, and
  penalty options; OLS, SGD, and Adam are supported. It materializes the expanded
  dense feature matrix. Feature count grows
  combinatorially with degree and input dimension; high-degree fits can exhaust
  memory, magnify numerical conditioning problems, or overflow on large inputs.
  There is no automatic scaling or sparse expansion. Its optional bias feature
  is correctly exempt from L2 regularization.
- **LogisticRegression:** full-batch SGD, Adam, L-BFGS, and cyclic proximal
  coordinate descent are supported. SGD/Adam/coordinate descent support no
  penalty, L1, L2, and elastic-net; L-BFGS supports only no penalty or L2. Adam
  uses fixed β₁ `0.9`, β₂ `0.999`, ε `1e-8`, and learning rate `0.001`; L-BFGS
  uses history size `10` and at most `20` Armijo line-search evaluations. There
  are no liblinear, Newton-CG, SAG, SAGA, minibatches, schedules, or built-in
  probability calibration. The configured threshold is fixed unless binary
  threshold tuning is requested.
- **MLPClassifier and MLPRegressor:** dense feed-forward networks support full-batch
  SGD and Adam. Adam uses fixed β₁ `0.9`, β₂ `0.999`, ε `1e-8`, and learning rate
  `0.001`. There are no momentum/Nesterov updates, batch size/shuffling, L2
  `alpha`, dropout, gradient clipping, learning-rate schedules, or validation
  early stopping. With `validationFraction` set the model reports a per-epoch
  `validationLossCurve_` and `bestEpoch_`, but it keeps its final weights (there is
  no best-weight restoration or patience), and `tol` stops on absolute objective
  change of the training loss; it never monitors the validation loss. The
  internal split is taken after any tabular preprocessing, so preprocessing
  statistics include the validation rows. See
  [Model inspection](model-inspection.md). Hidden activations are limited to identity, logistic,
  tanh, and ReLU; an empty hidden-layer list is rejected.
- **Decision trees:** use numeric, axis-aligned threshold splits only. There is no
  categorical split representation, missing-value routing, random splitter,
  `maxFeatures`, `maxLeafNodes`, cost-complexity pruning (`ccpAlpha`), monotonic
  constraints, or class/sample weighting. Minimum sample counts are integers,
  not dataset fractions. Unbounded default depth can produce large overfit trees;
  child datasets are copied during recursion. A tree state saved before node
  statistics were recorded still predicts, but cannot provide `tree_` or
  `featureImportances_` until the model is refitted. Worker- and direct-fitted
  trees choose identical splits only when no split is near-tied.
- **A tree split can disappear through rounding.** A DecisionTreeClassifier
  trained on `1 + Number.EPSILON` and `1 + 2 * Number.EPSILON` with labels
  `a` and `b` returns `a` for both rows. The chosen midpoint rounds up to
  the larger value, so the `<=` test sends both rows left and the node becomes
  a leaf. [Split scoring](../../src/training/worker-compute.ts) and [tree construction](../../src/training/training-engine.ts).
- **DecisionTreeRegressor:** supports `squared_error`, `friedman_mse`,
  `absolute_error`, and `poisson`. Poisson requires nonnegative targets. Leaves use
  medians for absolute error and means for the other criteria. The classifier
  supports Gini and entropy; `log_loss` uses the entropy split calculation, not
  calibrated probabilistic training.
- **K-neighbors models:** brute force remains the default; exact KD and Ball trees can prune certified Euclidean and Manhattan queries. Minkowski, non-finite queries and unusual neighbour counts use exhaustive paths. Fresh worker results retain certified boxes; cached and JSON-restored tree models perform exact exhaustive queries without rebuilding bounds on the page. With n rows, d features and M nodes, KD index arrays use n + 2Md doubles in packed form; Ball uses n + 3Md + M, in addition to retained rows and build scratch. Restoration performs bounded O(payload size) structural checks and copies. Approximate/radius search, custom metrics and callable weights remain unavailable; nNeighbors cannot exceed training rows.

- **Naive Bayes:** Gaussian, Multinomial, and Bernoulli variants only; Complement
  and Categorical NB are absent. Multinomial/Bernoulli smoothing uses one scalar
  `alpha`, not per-feature values. All three require at least two observed classes
  in worker training, so one-class fits and some small cross-validation folds fail.
  Custom prior arrays follow the fitted sorted observed-class order, which may
  differ from the request's `classLabels` order.
- **Naive Bayes feature semantics:** MultinomialNB requires non-negative features;
  BernoulliNB consumes thresholded binary features. GaussianNB adds a variance
  floor even with `varSmoothing: 0`. With zero smoothing, impossible events can
  leave every class with zero likelihood; probability methods fall back to uniform
  probabilities rather than indicating that the observation is unsupported.
- **A zero Naive Bayes prior can still win a prediction.** All three estimators
  add `1e-15` before taking the log of a class prior. For example, fit GaussianNB
  on `[0, 1]` for class `a` and `[100, 101]` for class `b`, with priors
  `[1, 0]`. At `100` the model predicts `b` with reported probability `1`.
  A caller requiring a class to be excluded cannot enforce that with a zero
  prior. Any change needs to account for the accepted all-zero prior vector.
  [Prior contract](hyperparameters.md#class-label-options), [GaussianNB inference](../../src/models/bayesian/gaussian-nb.ts)
  and [BernoulliNB and MultinomialNB fitting](../../src/training/training-engine.ts).
- **K-means:** only Lloyd updates with one seeded k-means++ initialization are
  available. There is no `nInit` best-of-multiple-restarts, custom initial centers,
  random initialization selector, Elkan, minibatch variant, or sample weights.
  A single initialization can settle at a poor local minimum. Fewer distinct points
  than requested clusters can leave duplicate centers/empty clusters despite
  farthest-point reinitialization. There is no automatic cluster-count selection.
- **PCA:** production fitting still uses a full feature-covariance
  eigendecomposition. An initial Bun kernel comparison of covariance/eigh against
  direct `numpy-ts` SVD varied by shape: 300×16 was 3.98/24.27 ms, 48×80 was
  34.82/10.22 ms, and 120×32 was 2.55/2.13 ms. These timings omit worker startup,
  transfers, and browser execution; no PCA Zig/WASM implementation is enabled
  without conformance and end-to-end performance evidence. There is no randomized/truncated SVD, solver
  selection, whitening, incremental PCA, fractional explained-variance target,
  or automatic component selection.
  `nComponents` must be an integer in `1..min(samples, features)`; at least two
  samples are required, and scaling requires centering. Covariance storage is
  quadratic in feature count, and the eigensolve is a single-worker stage. Forming
  covariance can worsen conditioning compared with direct SVD. Equal eigenvalues
  do not guarantee a uniquely oriented basis merely because signs are fixed.
- **SVC/SVR:** expose stock LIBSVM C-SVC and epsilon-SVR only. There are no
  NuSVC/NuSVR, one-class SVM, SGD/LinearSVC alternative, custom/precomputed kernels,
  squared-hinge/squared-epsilon objectives, `maxIter`, solver histories, or
  one-vs-rest decision output. Multiclass decision scores are pairwise, not one
  score per class. Cache size and shrinking controls are not public options.
- **Evaluation normalizes multiclass LogisticRegression scores.** The model's
  independent one-vs-rest sigmoid outputs can sum to a value other than one;
  `evaluateClassifier` normalizes each row for single-label scoring while
  leaving multi-label probabilities independent. Binary SVC ranking uses a raw
  decision margin oriented to the selected positive class; multiclass SVC
  ranking requires probability calibration.
- **SVC probabilities are opt-in.** `predictProba()` throws unless training used
  `probability: true`; calibration adds training work. There is no public
  `randomState` option for LIBSVM probability calibration, and probability argmax
  need not agree with LIBSVM's voting-based `predict()`.
- **SVM fitting cannot be reduced across independent workers.** Each fit uses one
  full-data synchronous native call inside a background worker. Cooperative polling
  supports cancellation; worker termination remains a grace-period fallback.
  Hydrated native models need `dispose()`;
  importing state requires WASM initialization in the receiving JavaScript realm.

Sources: [linear options](../../src/models/linear/linear-regression.ts),
[OLS kernel](../../src/models/linear/linear_regression.zig),
[polynomial model](../../src/models/linear/polynomial-regression.ts),
[logistic options](../../src/models/linear/logistic-regression.ts),
[MLP options](../../src/models/neural-networks/_base.ts), [tree options](../../src/models/trees/types.ts),
[neighbor options](../../src/models/distance-based/types.ts),
[neighbor search](../../src/models/distance-based/k-neighbors-classifier.ts),
[NB options](../../src/models/bayesian/types.ts), [K-means](../../src/models/clustering/k-means.ts),
[PCA kernels](../../src/training/worker-compute.ts), [SVM integration](../internals/svm.md).

## Model persistence limits

- **Model persistence interfaces are uneven.** KMeans has no estimator
  `toJSON()`/`fromJSON()` pair. PCA exports versioned, JSON-safe fitted state.
  A PCA pipeline embeds its estimator's own export, so a BernoulliNB step with
  zero smoothing inherits the JSON text limitation above. Typed-array payloads
  elsewhere require explicit encoding for JSON text.
- **Imported state is not uniformly validated.** Several non-SVM `fromJSON()`
  implementations cast arrays and dimensions directly rather than fully checking
  a versioned schema, finiteness, and parameter shapes. Corrupted or incompatible
  state can fail during prediction or yield incorrect results.

Sources: [PCA pipeline state](../../src/models/dimensionality-reduction/pca-pipeline.ts),
[Bernoulli serialization and prediction](../../src/models/bayesian/bernoulli-nb.ts),
[Multinomial serialization and prediction](../../src/models/bayesian/multinomial-nb.ts),
[hydration](../../src/training/hydrate.ts), [KMeans](../../src/models/clustering/k-means.ts).

## Tuning and evaluation limits

- **Search strategies are Random Search and Hyperband only.** There is no grid
  search, Bayesian optimization, conditional search-space API, custom scorer
  callback, or multi-objective selection. Domains are categorical, integer,
  uniform, or log-uniform and must use the model's supported option keys;
  unsupported keys are rejected, not silently enabled.
- **Hyperband supports iterative solvers for LinearRegression,
  PolynomialRegression, LogisticRegression, MLPClassifier, and MLPRegressor.**
  Each resource unit is one full-batch SGD/Adam update, one accepted L-BFGS step
  including its line search, or one complete coordinate-descent sweep. OLS is
  ineligible; if a LinearRegression or PolynomialRegression Hyperband request
  omits `solver`, it uses SGD as its iterative baseline. Iteration limits remain
  controlled by Hyperband and cannot be search dimensions. A search may compare
  solver choices, but elapsed time can differ substantially by solver and is
  reported in each trial's `durationMs`. Checkpoints retain portable model,
  optimizer, and convergence state internally; the hydrated winner exposes only
  its fitted model state. Trees, neighbors, NB, clustering, PCA, and SVM are not
  Hyperband targets.
- **Tuning requires IndexedDB, including Random Search.** Checkpoints and winner
  state use its ephemeral cache. Missing access, storage failures, or quota limits
  can fail the search. The memory budget is an estimate, not a hard browser/WASM
  allocation limit; ordinary training has no comparable public budget option.
- **Tuning supports the scorer catalogue in [Metrics](metrics.md)** with task,
  probability and target-domain checks. Custom callbacks and unsupervised
  silhouette scores are not supported.
- **Nested cross-validation supports supervised scorers only.** Classifier folds
  are stratified, including iterative multi-label stratification. Grouped,
  time-series and user-defined outer splits are not supported. For single-label
  classification, every class on the label axis (a declared `classLabels`, else
  `0 ... max target`, zero-row classes included) needs at least `outerFolds` rows,
  and each outer training complement must supply `innerFolds` rows per class; both
  are rejected otherwise. See [Stratified partition feasibility](stratified-partitions.md)
  for the exact rule and `checkStratifiedPartition`, which reports it before training.
- **Model comparison covers two models on one dataset.** `bayesianCorrelatedTTest` and
  `correctedResampledTTest` have no hierarchical multi-dataset model, signed-rank, sign or
  multiple-model tests, and no multiple-comparison correction. `testFraction` is a single average
  test share, which approximates uneven partitions. `crossValidate` has no built-in repetition:
  repeat it with different `randomState` values and concatenate the scores. See
  [Cross-validated model comparison](model-comparison.md).
- **Nested CV keeps no fitted fold models, and trial histories and the refit are opt-in.**
  Outer folds run sequentially. `includeTrials` stores `outerFolds × trials × innerFolds`
  doubles plus parameter objects; nested trial summaries never carry `metrics` because nested
  searches run without `trialMetrics`. `refit` returns one caller-owned model fitted on all rows.
  The `onModel` hook sees outer winners and the refit model, never models inside the inner searches,
  and it runs on the page thread, one model at a time. Probability-dependent metrics are unavailable
  without probabilities; RMSLE is unavailable for negative targets and clips
  negative predictions. A required unavailable scorer fails the outer fold.
- **Diagnostics cap dense confusion matrices at 4096 classes.** Standalone
  functions include classification, ranking and regression scores and ROC/PR
  curve arrays; clustering evaluation helpers are not supplied. Default F1
  uses binary averaging; multiclass callers must select an appropriate averaging
  mode. Multioutput regression uses uniform averaging.
- **Standalone probability losses need the fitted column order.** When
  `logLoss` or `brierScoreLoss` receives a vector of truth labels and a
  probability matrix without `labels`, it infers columns by sorting the string
  forms of the observed labels. For fitted columns `[2, 10]`, truth
  `[2, 10]` and rows `[[0.99, 0.01], [0.01, 0.99]]`, inferred log loss
  is about `4.605`. Passing `{ labels: [2, 10] }` gives the intended
  `0.010`. Supply `{ labels: [...model.classes_] }` for such matrices.
  [Probability loss implementation](../../src/metrics/probability.ts).
- **Multi-label log loss can return `NaN` for a perfect prediction.** With
  `logLoss([[1, 0]], [[1, 0]], { multiLabel: true, eps: 1e-20 })`, the
  upper clipping bound `1 - eps` rounds to `1`, leaving a `0 * log(0)` term.
  The default `eps: 1e-15` gives a finite result for this input.
  [Log loss clipping](../../src/metrics/probability.ts).
- **Fixed-option cross-validation** supports supervised non-pipeline estimators
  with one target (`folds` an integer from 2 to the row count, with every observed
  class holding at least `folds` rows; see
  [Stratified partition feasibility](stratified-partitions.md)), sequential folds and no multi-label logistic regression,
  threshold tuning, or tuning-only `maxWorkers`/`memoryBudgetBytes` controls.
  The caller owns any refit model and disposes SVC/SVR models when finished.
  Each fold result carries its own `validationIndices` (ascending, owned) and, with
  `preprocessing`, its own `featureNamesOut`; the optional refit returns its own
  transformer and mapping. Its `includeMetrics` scalar summaries keep their existing
  shape and are not adjusted-R² reports.
- **Outer partitions are deterministic and observable.** Fixed CV and the outer level
  of nested CV produce byte-identical ascending outer arrays, returned as
  `validationIndices` on every fold even with metrics disabled, for equal source row
  order, encoded targets and vocabulary, partition strategy, fold count and seed,
  across eligible algorithms and both APIs. Regression is unstratified; nested
  multi-label keeps its iterative stratifier. Inner assignments use derived seeds and
  refer to the outer-training complement. `stratifiedTrainTestSplit` gives the same
  seeded, stratified indices for a single holdout: per class the test quota is
  `floor(r*n)` or `ceil(r*n)` clamped to `[1, n-1]`, the total is `Math.round(r*N)`,
  and a singleton class, an infeasible total, an invalid code, a ratio outside
  (0, 1) or a non-finite seed is `invalid-request`.
- **A dense explicit-holdout `createTuner().search()` can throw synchronously.** When the
  training and validation providers declare different feature or target widths, or no
  `validationData` is given, the facade throws a plain `Error` before a run exists
  (see `Tuner.search`). With `preprocessing` the same mismatches, and a mismatch
  against the schema width, are delivered through the run instead: `queued`, one
  `failed` `invalid-request` event, a closed stream and rejecting `result` and
  `trainingMetrics`.
  `diagnoseModel` evaluates a separate held-out dataset using the same diagnostics.

Sources: [tuner API](../../src/training/TuningClient.ts),
[search validation](../../src/training/Tuner.ts), [cache](../../src/training/WeightCache.ts),
[nested CV](../../src/training/cross-validation.ts), [metrics](../../src/metrics/index.ts).

## Browser and deployment constraints

- **Web Workers and Web Locks are mandatory.** Without usable workers and the
  origin-scoped lock, training rejects with `environment-not-supported`. There is
  no main-thread or uncoordinated fallback. Deployment needs a secure context
  where Web Locks is available.
- **SharedWorker support is conditional.** It is used only after the nested module
  worker probe succeeds. The dedicated-worker fallback still coordinates via the
  origin lock, but does not provide a single shared in-memory queue across pages.
- **Cross-origin isolation is required.** The public client rejects with
  `environment-not-supported` unless the page is cross-origin isolated (COOP/COEP) and
  shared memory is available; there is no ordinary-buffer training mode for consumers.
  Production linear, polynomial, logistic and SVM paths require their respective
  WASM artifacts, including `logistic-regression.v1.wasm` for LogisticRegression.
- **Deployment must preserve worker and WASM artifacts and their relative URLs.**
  Both orchestrators, the probe, grouped compute workers, and adjacent WASM assets
  must remain available. Bundling only the main entrypoint is insufficient; CSP,
  worker restrictions, or missing assets can prevent training/initialization.
  The [package distribution](package-distribution.md) document states the packed
  layout that keeps these relative URLs valid.
- **Building native artifacts requires pinned external compilers.** Bun alone does
  not produce the Zig and LIBSVM modules; source builds require the pinned Zig and
  Emscripten toolchains. Consumers need the built assets, not these compilers.

Sources: [client capability handling](../../src/training/training-client.ts),
[capability probe](../../src/training/worker-capability.ts),
[build/package configuration](../../package.json), [deployment guidance](../../README.md).

## Partitioned classifier evaluation limits

Partitioned evaluation supports single-label classifiers in fixed CV, nested CV outer folds (including classifier PCA pipelines), and stratified holdout. It does not add regression, multi-label, inner-fold or tuning-trial row outputs. Fixed and nested CV require at least two effective labels; a holdout may have one when its estimator supports it. Probability outputs require coverage of every held-out partition, while binary SVC decision margins can remain available without calibration. Output probabilities scale with rows × classes; every dense report matrix scales with classes squared and is limited to 4096 classes.
