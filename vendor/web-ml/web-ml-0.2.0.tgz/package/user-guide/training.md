# Training Models

In `web-ml`, all model training happens asynchronously in Web Workers. This ensures your browser's main thread is never blocked, keeping your UI responsive.

The central entrypoint for training any model is `createTrainingClient()`.

## Basic Training

To start a training run, you create a client and call `.train(...)`. You'll need to specify the algorithm, any options (hyperparameters), and the dataset.

```typescript
import { ArrayDatasetProvider, createTrainingClient } from 'web-ml';
async function trainModel() {
	const client = createTrainingClient();
	const dataProvider = new ArrayDatasetProvider(
		4,
		2,
		1,
		new Float64Array([0, 0, 1, 0, 0, 1, 1, 1]),
		new Float64Array([0, 1, 1, 2])
	);

	const run = client.train({
		algorithm: 'linear-regression',
		options: { solver: 'sgd', maxIter: 1000 },
		data: dataProvider
	});

	// Await the finalized, hydrated model
	const { model } = await run.result;

	// Predict synchronously
	const prediction = model.predict([[1.5, -0.2]]);
	console.log('Prediction:', prediction.get(0, 0));
}

await trainModel();
```

## Solver defaults

LinearRegression and PolynomialRegression default to OLS. LogisticRegression,
MLPClassifier, and MLPRegressor default to Adam. You can select SGD where it is
available; set `solver: 'sgd'` when you want to tune its learning rate. Adam uses
a fixed learning rate of `0.001` with β₁ `0.9`, β₂ `0.999`, and ε `1e-8`.

```typescript
import { ArrayDatasetProvider, createTrainingClient } from 'web-ml';

const client = createTrainingClient();
const myDatasetProvider = new ArrayDatasetProvider(
	8,
	2,
	1,
	new Float64Array([0, 2, 1, 3, 2, 4, 3, 0, 4, 1, 0, 2, 1, 3, 2, 4]),
	new Float64Array([0, 0, 0, 0, 1, 1, 1, 1])
);
const run = client.train({
	algorithm: 'logistic-regression',
	classLabels: ['negative', 'positive'],
	options: { solver: 'sgd', learningRate: 0.01, penalty: 'l2' },
	data: myDatasetProvider
});
const { model } = await run.result;
```

`maxIter` (and each model's documented alias) is an iteration budget. The
`tol` option uses the solver's documented convergence measure; setting it to
`0` runs the full budget. See each model guide for the supported solvers and
stopping rule.

## Threshold tuning through the training client

`createTrainingClient().train(...)` also accepts threshold tuning when you send
a hyperparameter-tuning request. In that request, set
`algorithm: 'hyperparameter-tuning'`, name the classifier with
`targetAlgorithm`, and put `thresholdTuning` at the top level. Combine the
training and validation providers in that order; the sample counts mark their
boundary in the combined dataset.

```typescript
import { createTrainingClient } from 'web-ml';
import { CombinedDatasetProvider } from 'web-ml/training';

const data = new CombinedDatasetProvider([trainingData, validationData]);
const run = createTrainingClient().train({
	algorithm: 'hyperparameter-tuning',
	targetAlgorithm: 'logistic-regression',
	data,
	trainingSampleCount: trainingData.sampleCount,
	validationSampleCount: validationData.sampleCount,
	classLabels: ['negative', 'positive'],
	searchSpace: {
		C: { kind: 'log-uniform', min: 0.1, max: 10 }
	},
	scoring: 'f1',
	thresholdTuning: { positiveLabel: 'positive' },
	strategy: { kind: 'random-search', nTrials: 24, randomState: 7 }
});

const result = await run.result;
console.log('Selected cutoff:', result.bestDecisionThreshold);
console.log(result.bestModel.predict([[0.5, 0.5]]));
```

The `thresholdTuning` option has the same name and shape in
`createTuner().search(...)` and `nestedCrossValidate(...)`. Those APIs take
separate training/validation inputs or manage their own folds; see the
[tuning guide](./tuning.md) and [evaluation guide](./evaluation.md) for examples.

### Providing Data

`web-ml` accepts data via the `DatasetProvider` interface. The provider is responsible for loading your dataset into the continuous shared memory buffers used by the WebWorker orchestrator.

You can use `ArrayDatasetProvider` if your arrays are already in memory, or `BatchDatasetProvider` to stream chunks of data asynchronously.

[Read more about using the DatasetProvider here.](./dataset-provider.md)

## Listening to Progress

You can track a model's training progress by iterating over `run.events`. This stream emits events for initialization, batch processing, and epoch/iteration progress.

```typescript
for await (const event of run.events) {
	if (event.type === 'progress') {
		console.log(`Phase: ${event.phase}, Progress: ${Math.round(event.fraction * 100)}%`);
	}
}
```

_For more details on the exact events emitted, see the [Progress Events](./progress-events.md) guide._

## Cancellation

If the user navigates away or changes their mind, you can cancel a running training task to free up resources. Pass a standard `AbortSignal` to the `.train()` method.

```typescript
const controller = new AbortController();

const run = client.train(request, { signal: controller.signal });

// Later, cancel the run
controller.abort();
```

When aborted, the `run.result` promise will reject with an `AbortError`.

## Tabular preprocessing

Add `preprocessing` to an ordinary request to train on raw tabular codes with missing values and
categories. The worker fits the transformer from the training source only, validation rows are
transformed with that frozen state, and the transformer comes back as `preprocessor` and
`featureNamesOut`. In a PCA pipeline the order is raw rows, transform, PCA, estimator, and the option
belongs on the **outer** request only. The portable result stores the snapshot once as
`preprocessorState`, so a cached run can be restored without reading its sources again.

```typescript
import {
	ArrayDatasetProvider,
	FittedTabularPreprocessor,
	createTrainingClient,
	encodeTabularFeatures,
	hydrateTrainingResult
} from 'web-ml';

const cells = ['a', 'b', 'c', 'a', 'b', 'c'].map((value) => [value]);
const encoded = encodeTabularFeatures(cells, [{ name: 'kind', kind: 'categorical' }]);
const request = {
	algorithm: 'pca-pipeline' as const,
	// Two components from three encoded columns: more than the single raw column.
	pcaOptions: { nComponents: 2 },
	estimator: {
		algorithm: 'logistic-regression' as const,
		options: { solver: 'sgd' as const, maxIter: 50 }
	},
	preprocessing: { columns: encoded.columns },
	data: new ArrayDatasetProvider(6, 1, 1, encoded.features, Float64Array.from([0, 0, 1, 0, 0, 1]))
};

const client = createTrainingClient();
const { model, featureNamesOut } = await client.train(request, { cacheKey: 'kinds/v1' }).result;

const cached = await client.checkTrainingState('kinds/v1');
if (cached && cached.status === 'completed') {
	// Hydrate the estimator and the transformer from the portable result alone.
	const restoredModel = await hydrateTrainingResult(request, cached.result);
	const fitted =
		cached.result.algorithm === 'hyperparameter-tuning'
			? cached.result.bestResult
			: cached.result;
	const restored =
		fitted.preprocessorState === undefined
			? undefined
			: FittedTabularPreprocessor.fromJSON(fitted.preprocessorState);
	void [restoredModel, restored?.transform([['b']]), cached.featureNamesOut];
}
void [model, featureNamesOut];
```

## Persistent Training State

Training can take time, and a user might accidentally reload the page. `web-ml` uses IndexedDB to let you cache and resume completed training states seamlessly.

Pass a unique, application-defined `cacheKey` to the `.train(...)` method.

```typescript
import { ArrayDatasetProvider, createTrainingClient, LogisticRegression } from 'web-ml';

const client = createTrainingClient();
const request = {
	algorithm: 'logistic-regression' as const,
	classLabels: ['setosa', 'versicolor'],
	data: new ArrayDatasetProvider(
		4,
		4,
		1,
		new Float64Array([
			5.1, 3.5, 1.4, 0.2, 4.9, 3, 1.4, 0.2, 7, 3.2, 4.7, 1.4, 6.4, 3.2, 4.5, 1.5
		]),
		new Float64Array([0, 0, 1, 1])
	)
};
const cacheKey = 'my-app/iris-logistic-v1';

// Check if we already have a completed model cached
const cached = await client.checkTrainingState(cacheKey);

if (cached && cached.status === 'completed') {
	// We can immediately use the cached model!
	if (!(cached.model instanceof LogisticRegression)) throw new Error('Unexpected cached model');
	const prediction = cached.model.predict([[5.1, 3.5, 1.4, 0.2]]);
} else {
	// We need to train. If status was 'incomplete', resume() clears the old run and restarts.
	const run =
		cached && cached.status === 'incomplete'
			? cached.resume(request)
			: client.train(request, { cacheKey });

	const { model } = await run.result;
}
```

> **Note:** The cache key is completely up to you. Make sure to include dataset identifiers or application versions so you don't accidentally load an outdated model!

Fresh K-neighbors tree results reuse worker-certified bounds. Restoring a cached or JSON model validates and copies its state in O(payload size) without page-side index fitting; those restored models use exact exhaustive queries while retaining their configured algorithm and leafSize.

## Fit dispatch timing

For a successful ordinary training run, the optional `fitDurationMs` measures
orchestrator fit dispatch, including preparation and reductions but excluding
ingestion, initial pool acquisition, finalization and validation. PCA pipelines
sum the PCA and estimator fit intervals. Tuning does not report this measurement.
If the run fails or is cancelled, `trainingMetrics` rejects with the same error
instance as `result`.

```ts
const run = createTrainingClient().train(request);
const { model } = await run.result;
const { fitDurationMs } = await run.trainingMetrics;
console.log(model, fitDurationMs);
```
