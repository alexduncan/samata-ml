# Machine-readable model specifications

The package includes JSON descriptions of each concrete implemented model. They
make model IDs, task types, supported options, defaults, and model-specific
diagnostics available to tools that consume JSON. They do not add a runtime
training or prediction API; use `createTrainingClient().train(...)` for fitting.

## Load a model document

Import the catalogue, schema, or one model document with a JSON import attribute.
The model filename is its exact training `algorithm` value.

```ts
import catalogue from 'web-ml/model-specifications' with { type: 'json' };
import linearRegression from 'web-ml/model-specifications/linear-regression' with { type: 'json' };

const entry = catalogue.models.find((model) => model.id === linearRegression.id);
console.log(linearRegression.id, linearRegression.taskType, entry?.file);
```

The catalogue contains 16 concrete models. It excludes `pca-pipeline`, which is
a model composition, and `hyperparameter-tuning`, which is an orchestration
request. K-Means has `taskType: "clustering"`; PCA has
`taskType: "dimensionality-reduction"`.

## Read options and reported diagnostics

Each document's `hyperparameters` list describes accepted option names, value
schemas, whether an option is required, and how its default works. A `fixed`
default is stored in `default`, even when the value is `null`. Other kinds such
as `random-if-omitted` use `defaultNote`. A `conditional` default uses
`defaultBy` rules so consumers can inspect the prerequisite option and the
resulting default. Rules match effective values after the prerequisite option's
own default has been applied, including when that option was omitted. Enum
options have an `enumDescriptions` object keyed by each allowed value. The
`description` field stays a short explanation of the option itself.

```ts
import logisticRegression from 'web-ml/model-specifications/logistic-regression' with { type: 'json' };

for (const option of logisticRegression.hyperparameters) {
	console.log(option.name, option.valueSchema, option.defaultKind);
	if (option.enumDescriptions) console.log(Object.entries(option.enumDescriptions));
	if (option.defaultBy) console.log(option.defaultBy);
}
for (const diagnostic of logisticRegression.metrics) {
	console.log(diagnostic.accessor, diagnostic.description);
}
```

`metrics` lists only model-specific fit statistics and training diagnostics that
the fitted estimator or its progress events expose. An empty list means there
are no such values for that model. Standalone evaluation scores, tuning scores,
nested cross-validation scores, and run timing are separate API results and do
not appear here. Model coefficients and other fitted parameters are not metrics.

## Check versions and dates

Documents use `schemaVersion: 1`. `lastUpdated` is an ISO date that changes when
the model document's contract metadata changes; formatting-only edits do not
change it. Consumers can use the schema to validate documents before reading
their fields.

```ts
import schema from 'web-ml/model-specifications/schema' with { type: 'json' };
import pca from 'web-ml/model-specifications/pca' with { type: 'json' };

if (pca.schemaVersion !== 1) throw new Error('Unsupported model document version');
console.log(schema.$schema, pca.lastUpdated);
```

The schema is JSON Schema Draft 2020-12. It defines both model documents and the
catalogue index under `$defs.model` and `$defs.index`.

## Documentation paths and package files

The `documentation` values are POSIX paths relative to the installed package
root, not URLs and not paths relative to the JSON file. The package includes
`specification/public-api/model-specifications/`, `specification/public-api/models.md`,
`specification/public-api/hyperparameters.md`, `specification/public-api/metrics.md`,
`user-guide/models/`, and this guide at `user-guide/model-specifications.md`.

```ts
import pca from 'web-ml/model-specifications/pca' with { type: 'json' };

// Resolve this package-root-relative path with your package or documentation tooling.
console.log(pca.documentation.modelGuide); // user-guide/models/pca.md
```
