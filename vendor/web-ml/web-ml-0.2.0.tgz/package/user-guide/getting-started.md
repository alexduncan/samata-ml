# Getting Started with `web-ml`

## Quick Overview of `web-ml`

`web-ml` is a machine-learning library designed specifically for web applications. It allows you to train and use machine learning models directly in the browser using TypeScript. Instead of relying on a backend server or complex setups, you can bring capabilities like classification, regression, and clustering right into your web frontend.

One of the core features of `web-ml` is that it runs training tasks asynchronously in Web Workers. This means your application's user interface will remain smooth and responsive while computationally heavy models are training in the background. Once a model is trained, you can use it to make synchronous predictions instantly.

## Before You Start

For `web-ml` to function correctly and securely, your web page must be **cross-origin isolated**. This is a strict requirement for utilizing `SharedArrayBuffer`, which `web-ml` uses for high-performance memory sharing between workers.

You must serve your application with the following HTTP headers:

```http
Cross-Origin-Opener-Policy: same-origin
Cross-Origin-Embedder-Policy: require-corp
```

If these headers are missing, `web-ml` will throw an `environment-not-supported` error. You must also run your application in a secure context (`HTTPS` or `localhost`).

## Quick Start

Here is a simple example showing how to train a basic logistic regression classification model using a simulated Iris dataset.

```typescript
import { createTrainingClient } from 'web-ml';
import { ArrayDatasetProvider } from 'web-ml/training';

async function trainIrisModel() {
	// A mock version of the classic Iris dataset for our example
	const mockIrisFeatures = new Float64Array([
		5.1,
		3.5,
		1.4,
		0.2, // row 1
		4.9,
		3.0,
		1.4,
		0.2, // row 2
		7.0,
		3.2,
		4.7,
		1.4, // row 3
		6.4,
		3.2,
		4.5,
		1.5 // row 4
	]);
	const mockIrisTargets = new Float64Array([
		0, // class: setosa
		0, // class: setosa
		1, // class: versicolor
		1 // class: versicolor
	]);

	const client = createTrainingClient();

	const provider = new ArrayDatasetProvider(
		4, // sampleCount
		4, // featureCount
		1, // targetCount
		mockIrisFeatures,
		mockIrisTargets
	);

	const run = client.train({
		algorithm: 'logistic-regression',
		classLabels: ['setosa', 'versicolor'],
		data: provider
	});

	// Optional: Listen to progress events during training
	for await (const event of run.events) {
		if (event.type === 'progress') {
			console.log(`Training progress: ${Math.round(event.fraction * 100)}%`);
		}
	}

	// Await the finalized model
	const { model } = await run.result;

	// Make a prediction instantly
	const prediction = model.predict([[5.0, 3.4, 1.5, 0.2]]);
	console.log('Predicted class index:', prediction.get(0, 0));
}
```

## Main Endpoints

`web-ml` focuses its public orchestration API into three main endpoints:

1. **`createTrainingClient();`**<br />Used for fitting models and persisting completed training state. Use `createTrainingClient().train(...)` to run asynchronous model fitting. See the [Training Guide](./training.md).
2. **`createTuner();`**<br />Used for hyperparameter tuning. It exposes `search(...)` to find the best configuration for an estimator by validating multiple parameter combinations. See the [Hyperparameter Tuning Guide](./tuning.md).
3. **`nestedCrossValidate();`**<br />Used for robust evaluation of your tuned model pipelines. It assesses generalization performance through nested cross-validation across outer and inner splits. See the [Evaluation Guide](./evaluation.md).

## Shared Features

Across these endpoints, `web-ml` provides several standardized features:

- **Progress Events**<br />All endpoints yield asynchronous event streams (`run.events`) that track detailed progress, metrics, and warnings over time. You can use this to drive UI loading bars. (See [Progress Events Guide](./progress-events.md)).
- **Cancellation**<br />You can easily cancel any long-running training, tuning, or evaluation task by passing a standard `AbortSignal`.
- **Persistent State**<br />The library allows you to cache intermediate or completed states in IndexedDB, which is especially useful for recovering work after a page reload.
- **Metrics Output**<br />Depending on the estimator, you will receive rich training and evaluation metrics directly in the event stream or final result payload.

## Machine Learning Models

Here is a summary of the machine learning algorithms currently supported by `web-ml`. Follow the model ID links for detailed guides and hyperparameter references for each specific model.

| Model                                                                    | Type                     | Description                                                                                                   |
| :----------------------------------------------------------------------- | :----------------------- | :------------------------------------------------------------------------------------------------------------ |
| [Logistic Regression](./models/logistic-regression.md)                   | Classification           | A common linear model used for binary and multi-class probabilistic classification.                           |
| [Linear Regression](./models/linear-regression.md)                       | Regression               | A foundational model that predicts a continuous target by finding the best linear relationship with features. |
| [Polynomial Regression](./models/polynomial-regression.md)               | Regression               | Extends linear regression to capture non-linear relationships by creating polynomial features.                |
| [Support Vector Classifier (SVC)](./models/support-vector-classifier.md) | Classification           | A robust classification method that finds the optimal margin separating classes (uses LIBSVM).                |
| [Support Vector Regressor (SVR)](./models/support-vector-regressor.md)   | Regression               | Adapts the support vector algorithm for continuous regression tasks.                                          |
| [K-Nearest Neighbors Classifier](./models/k-neighbors-classifier.md)     | Classification           | Classifies new samples based on the majority class of their nearest neighbors in the training data.           |
| [K-Nearest Neighbors Regressor](./models/k-neighbors-regressor.md)       | Regression               | Predicts a continuous value based on the average of its nearest neighbors.                                    |
| [Decision Tree Classifier](./models/decision-tree-classifier.md)         | Classification           | Creates a tree of simple if-then rules to categorize data into classes.                                       |
| [Decision Tree Regressor](./models/decision-tree-regressor.md)           | Regression               | Uses a decision tree structure to predict a continuous numerical value.                                       |
| [Multi-layer Perceptron Classifier](./models/mlp-classifier.md)          | Classification           | A feedforward neural network algorithm optimized for classification.                                          |
| [Multi-layer Perceptron Regressor](./models/mlp-regressor.md)            | Regression               | A feedforward neural network optimized for continuous predictions.                                            |
| [Bernoulli Naive Bayes](./models/bernoulli-nb.md)                        | Classification           | A probabilistic classifier designed for binary or boolean feature data.                                       |
| [Gaussian Naive Bayes](./models/gaussian-nb.md)                          | Classification           | A probabilistic classifier based on the assumption that continuous features follow a normal distribution.     |
| [Multinomial Naive Bayes](./models/multinomial-nb.md)                    | Classification           | A probabilistic classifier well-suited for discrete data, such as word counts in text.                        |
| [K-Means](./models/k-means.md)                                           | Clustering               | An unsupervised algorithm that partitions data into a set of distinct clusters.                               |
| [Principal Component Analysis (PCA)](./models/pca.md)                    | Dimensionality Reduction | Reduces the complexity of data by projecting it onto its most significant principal components.               |

Model IDs, supported options, and exposed model-specific diagnostics are also
available as package JSON files. This metadata does not train a model; use the
training client shown above for fitting. See the
[machine-readable model specifications guide](./model-specifications.md).

```ts
import pca from 'web-ml/model-specifications/pca' with { type: 'json' };

console.log(
	pca.id,
	pca.taskType,
	pca.hyperparameters.map((option) => option.name)
);
```

## Pipelines

You can also chain multiple algorithms together so they execute efficiently within the same worker context without passing intermediate data back to the browser's main thread.

Currently, `web-ml` supports the `pca-pipeline` algorithm, which allows you to perform Principal Component Analysis (PCA) to reduce dimensionality before immediately feeding the transformed data into any supervised classifier or regressor (except `multinomial-nb`). This pipeline can be seamlessly trained, tuned, or evaluated using `createTrainingClient`, `createTuner`, or `nestedCrossValidate`.

See the [PCA Guide](./models/pca.md#pca-pipeline) for a code example.
