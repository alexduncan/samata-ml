# DatasetProvider: Supplying Data to web-ml

The `DatasetProvider` is the standard way to feed data into `web-ml` for training, tuning, and evaluation. It handles moving data efficiently from your application into the background compute workers.

In `web-ml`, all models are trained on continuous blocks of memory (dense arrays) using WebAssembly. To avoid freezing the main thread while moving large amounts of data, `web-ml` uses `SharedArrayBuffer` to allocate memory in the background and share it with the main thread.

The `DatasetProvider` interface abstracts this process: it gives you a simple way to load your data into these shared memory buffers right before training begins, without needing to worry about memory allocation or web workers yourself.

## Built-in Providers

The library exports two standard dataset providers:

### `ArrayDatasetProvider`

Use the `ArrayDatasetProvider` when you already have your entire dataset loaded into memory as a `Float64Array`.

```typescript
import { ArrayDatasetProvider } from 'web-ml/training';

const provider = new ArrayDatasetProvider(
	100, // sampleCount (number of rows)
	4, // featureCount (number of columns per row)
	1, // targetCount (number of target columns)
	myFeaturesFloat64Array,
	myTargetsFloat64Array
);
```

### `BatchDatasetProvider`

If your dataset is too large to create a single array up front, or you want to stream data out of a database, you can use the `BatchDatasetProvider`. It accepts an async generator that yields chunks of the data.

```typescript
import { BatchDatasetProvider } from 'web-ml/training';

const provider = new BatchDatasetProvider({
	sampleCount: 10000,
	featureCount: 4,
	targetCount: 1,
	batches: (async function* () {
		for (let start = 0; start < 10000; start += 1000) {
			// Fetch or generate the next 1000 rows
			const features = new Float64Array(1000 * 4);
			const targets = new Float64Array(1000 * 1);

			// ... fill arrays with your data ...

			yield {
				rowCount: 1000,
				features,
				targets
			};
		}
	})()
});
```

**Memory Tip:** The arrays yielded in the batch generator will be copied sequentially into the shared training buffer. You do not need to preserve ownership of the arrays after yielding them.

## Using DatasetProviders

Once you have created a `DatasetProvider`, you pass it directly to the `.train()`, `.search()`, or `nestedCrossValidate()` APIs.

```typescript
import { createTrainingClient } from 'web-ml';
import { ArrayDatasetProvider } from 'web-ml/training';

const client = createTrainingClient();
const data = new ArrayDatasetProvider(100, 4, 1, featuresArray, targetsArray);

const run = client.train({
	algorithm: 'linear-regression',
	data: data // Pass the provider directly
});
```

## Creating a Custom Dataset Provider

If you want fine-grained control over how your data is loaded into memory, you can implement the `DatasetProvider` interface yourself.

```typescript
import { DatasetProvider } from 'web-ml/training/types';

class MyCustomProvider implements DatasetProvider {
	readonly sampleCount = 100;
	readonly featureCount = 2;
	readonly targetCount = 1;

	async load(
		features: Float64Array,
		targets?: Float64Array,
		signal?: AbortSignal,
		onProgress?: (fraction: number) => void
	): Promise<void> {
		// The `features` and `targets` arrays provided here are views into the
		// SharedArrayBuffer. Write your data directly into these arrays!

		for (let i = 0; i < this.sampleCount; i++) {
			if (signal?.aborted) throw new Error('Aborted');

			features[i * 2 + 0] = getFeature1(i);
			features[i * 2 + 1] = getFeature2(i);

			if (targets) {
				targets[i] = getTarget(i);
			}

			if (i % 10 === 0 && onProgress) {
				onProgress(i / this.sampleCount);
			}
		}
	}
}
```

The orchestrator will allocate the required shared memory and then call your `load()` method, allowing you to hydrate the matrices with zero intermediate memory allocations.

## Raw tabular sources

With the top-level `preprocessing` option, a provider carries raw codes: numeric cells as numbers,
categorical cells as positions in a shared transport dictionary, and `NaN` for a missing value.
`encodeTabularFeatures` packs literal rows into exactly that layout. Reuse the returned `columns` for every
source of the request, held-out sources included.

The library fills the destination you receive with positive infinity for features and `NaN` for targets
before it calls `load`, and rejects any feature cell that is still infinite afterwards. A provider
must therefore write **every** cell it owns; a forgotten cell fails the run instead of becoming `0` or a
missing value. A raw infinity or a non-finite target is also `invalid-request`.

```typescript
import { createTrainingClient, encodeTabularFeatures, type DatasetProvider } from 'web-ml';

const rows = [
	[1.5, 'north'],
	[null, 'south'],
	[3.5, 'north'],
	[4.5, 'east'],
	[6, 'south'],
	[7.5, 'east']
];
const labels = Float64Array.from([0, 0, 0, 1, 1, 1]);
const packed = encodeTabularFeatures(rows, [
	{ name: 'distance', kind: 'numeric' },
	{ name: 'region', kind: 'categorical' }
]);

class RawRows implements DatasetProvider {
	readonly sampleCount = rows.length;
	readonly featureCount = 2;
	readonly targetCount = 1;
	async load(features: Float64Array, targets?: Float64Array): Promise<void> {
		features.set(packed.features); // every cell is written; NaN marks a missing value
		targets?.set(labels);
	}
}

const { model, preprocessor } = await createTrainingClient().train({
	algorithm: 'logistic-regression',
	classLabels: ['near', 'far'],
	preprocessing: { columns: packed.columns, standardize: true },
	data: new RawRows()
}).result;
void model.predict(preprocessor!.transform([[5, 'north']]));
```
