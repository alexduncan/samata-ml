# Hyperparameter Tuning

Finding the right configuration for a machine learning model is difficult. `web-ml` provides a built-in hyperparameter tuner that evaluates many different configurations to find the best performing model.

The central entrypoint for tuning is `createTuner()`.

## Trial reports and scorer axes

Set `trialMetrics: { completeMetrics: true }` to retain a report for each
completed or pruned candidate evaluation. The report for a holdout describes
the fitted model's class order; the selection score uses the configured
`classLabels` axis. Inner cross-validation reports pool out-of-fold predictions
in original row order on that configured axis. Probabilities and ranking
metrics are unavailable when a row's label was absent from the model that
predicted it. Reports consume memory for every retained trial and rung, so the
tuner includes them in its memory budget.

A report never changes a trial's status or score. Pooled reports pass decision
margins only for a two-label axis, so with three or more declared labels each
metric that cannot be computed is marked unavailable on its own while counts stay
on the declared axis. If a report still cannot be built, the trial keeps its score,
omits `metrics` and records the reason in `metricsError`.

```ts
import { createTuner } from 'web-ml';
import type { TrainingData } from 'web-ml';

async function tuneWithReports(trainingData: TrainingData, validationData: TrainingData) {
	const result = await createTuner().search({
		algorithm: 'k-neighbors-classifier',
		classLabels: ['negative', 'positive'],
		trainingData,
		validationData,
		searchSpace: { nNeighbors: { kind: 'categorical', values: [1, 3] } },
		scoring: 'accuracy',
		trialMetrics: { completeMetrics: true },
		strategy: { kind: 'random-search', nTrials: 2, randomState: 7 }
	}).result;
	for (const trial of result.trials) console.log(trial.score, trial.metrics);
}

function data(): TrainingData {
	return {
		sampleCount: 4,
		featureCount: 1,
		targetCount: 1,
		batches: (async function* () {
			yield {
				rowCount: 4,
				features: new Float64Array([-2, -1, 1, 2]),
				targets: new Float64Array([0, 0, 1, 1])
			};
		})()
	};
}
await tuneWithReports(data(), data());
```

For a one-class fit under two configured labels, binary F1 selection keeps the
configured positive label while the fitted report uses its sole class. Log loss
uses the observed class probability instead of inverting a one-column output.
Constant-target R² is 1 for exact predictions and 0 otherwise.

## Fold scores and the winning trial

Every trial whose evaluation completed carries `foldScores`: the score on each validation partition, in
partition order. Without `thresholdTuning`, `score` is their mean. With `thresholdTuning`, each partition is
scored at the selected pooled cutoff, so `score` generally differs from their mean. `bestTrialId` names the
winning trial: for Random Search its `params` equal `bestParams`; for Hyperband the entry at the maximum
`resource` has `score === bestScore` and `bestParams` adds `maxIter` (and `nIterations` for
`logistic-regression`) to its `params`. Trials are ordered by `trialId`, the sampling and dispatch order.
Failed trials, and Hyperband entries pruned after a failure, have no `foldScores`. Results stored under a
`cacheKey` before these fields existed return without them, so treat both as optional.

```ts
import { createTuner } from 'web-ml';
import type { TrainingData } from 'web-ml';

async function inspectFolds(trainingData: TrainingData) {
	const result = await createTuner().search({
		algorithm: 'decision-tree-classifier',
		classLabels: ['negative', 'positive'],
		trainingData,
		innerFoldAssignments: new Uint32Array([0, 1, 0, 1, 0, 1, 0, 1]),
		innerFoldCount: 2,
		searchSpace: { maxDepth: { kind: 'categorical', values: [1, 2] } },
		scoring: 'accuracy',
		strategy: { kind: 'random-search', nTrials: 2, randomState: 3 }
	}).result;
	const winner = result.trials.find((trial) => trial.trialId === result.bestTrialId);
	for (const trial of result.trials)
		console.log(trial.trialId, trial.score, trial.foldScores && Array.from(trial.foldScores));
	console.log('winner', winner?.params, result.bestScore);
}

const rows = [-4, -3, -2, -1, 1, 2, 3, 4];
void inspectFolds({
	sampleCount: 8,
	featureCount: 1,
	targetCount: 1,
	batches: (async function* () {
		yield {
			rowCount: 8,
			features: Float64Array.from(rows),
			targets: Float64Array.from(rows, (value) => (value > 0 ? 1 : 0))
		};
	})()
});
```

## Multi-label tuning

LogisticRegression can tune independent labels with one binary target column per
ordered class label. `accuracy` measures an exact match across every label in a
row. A categorical `multiLabel` search domain must contain only `true` or only
`false`; it overrides the fixed option. Binary threshold tuning is unavailable.

```ts
import { createTuner } from 'web-ml';
import type { TrainingData } from 'web-ml';

async function tuneMultiLabel(trainingData: TrainingData, validationData: TrainingData) {
	const run = createTuner().search({
		algorithm: 'logistic-regression',
		classLabels: ['red', 'green', 'blue'],
		trainingData,
		validationData,
		searchSpace: { multiLabel: { kind: 'categorical', values: [true] } },
		scoring: 'accuracy',
		trialMetrics: {},
		strategy: { kind: 'random-search', nTrials: 1 }
	});
	console.log((await run.result).trials[0]?.metrics);
}

function data(): TrainingData {
	return {
		sampleCount: 4,
		featureCount: 1,
		targetCount: 3,
		batches: (async function* () {
			yield {
				rowCount: 4,
				features: new Float64Array([-2, -1, 1, 2]),
				targets: new Float64Array([0, 0, 0, 0, 1, 1, 1, 0, 1, 1, 1, 0])
			};
		})()
	};
}
await tuneMultiLabel(data(), data());
```

## Target-specific result from the training client

The tuning overload retains the target algorithm in `bestModel` and `bestParams`:

```ts
import { ArrayDatasetProvider, createTrainingClient } from 'web-ml';
import type { LogisticRegression, LogisticRegressionOptions } from 'web-ml';

async function tuneTyped() {
	const data = new ArrayDatasetProvider(
		8,
		1,
		1,
		new Float64Array([-4, -3, -2, -1, 1, 2, 3, 4]),
		new Float64Array([0, 0, 0, 0, 1, 1, 1, 1])
	);
	const result = await createTrainingClient().train({
		algorithm: 'hyperparameter-tuning',
		targetAlgorithm: 'logistic-regression',
		data,
		trainingSampleCount: 6,
		validationSampleCount: 2,
		classLabels: [0, 1],
		searchSpace: { C: { kind: 'categorical', values: [1] } },
		scoring: 'accuracy',
		strategy: { kind: 'random-search', nTrials: 1 }
	}).result;
	const model: LogisticRegression = result.bestModel;
	const parameters: Readonly<LogisticRegressionOptions> = result.bestParams;
	console.log(model.predict([[0]]), parameters);
}
void tuneTyped();
```

## Basic Tuning

Instead of `.train()`, you use the `.search()` method. You provide separate `trainingData` (used to fit the candidate models) and `validationData` (used to evaluate their performance).

```typescript
import { createTuner } from 'web-ml';
import type { TrainingData } from 'web-ml';

function makeData(): TrainingData {
	return {
		sampleCount: 8,
		featureCount: 2,
		targetCount: 1,
		batches: (async function* () {
			yield {
				rowCount: 8,
				features: new Float64Array([0, 0, 0, 1, 1, 0, 1, 1, 2, 2, 2, 3, 3, 2, 3, 3]),
				targets: new Float64Array([0, 0, 0, 0, 1, 1, 1, 1])
			};
		})()
	};
}

async function tuneModel() {
	const tuner = createTuner();

	const trainingProvider = makeData();
	const validationProvider = makeData();

	const run = tuner.search({
		algorithm: 'logistic-regression',
		classLabels: ['negative', 'positive'],
		trainingData: trainingProvider,
		validationData: validationProvider,
		baseOptions: { solver: 'sgd' },

		// Define the boundaries to search within
		searchSpace: {
			learningRate: { kind: 'log-uniform', min: 0.001, max: 0.1 },
			C: { kind: 'log-uniform', min: 0.1, max: 10 }
		},

		// Choose the metric to maximize/minimize
		scoring: 'f1',
		thresholdTuning: { positiveLabel: 'positive' },

		// Configure the search strategy
		strategy: { kind: 'random-search', nTrials: 24, randomState: 7 },

		// Run up to 4 workers in parallel
		maxWorkers: 4
	});

	// Track tuning progress
	for await (const event of run.events) {
		if (event.type === 'tuning-progress') {
			console.log(`Trials completed: ${event.trialsCompleted} / ${event.totalTrials}`);
		}
	}

	const result = await run.result;

	// The tuner returns the best performing, fully hydrated model!
	const bestClassifier = result.bestModel;
	console.log('Best Score:', result.bestScore);
	console.log('Selected cutoff:', result.bestDecisionThreshold);
	console.log('Prediction:', bestClassifier.predict([[0.5, 0.5]]));
}

await tuneModel();
```

## Binary Decision-Threshold Tuning

The same `thresholdTuning` request option is available through all three public
tuning paths: `createTrainingClient().train(...)` with
`algorithm: 'hyperparameter-tuning'`, `createTuner().search(...)`, and
`nestedCrossValidate(...)`. The shape is always
`{ positiveLabel?: ClassificationLabel }`; only where the option sits in the
request differs. The example above shows the `createTuner().search(...)` form.
For the direct training-client form, see [training models](./training.md); for
the nested cross-validation form, see [evaluating models](./evaluation.md).

Set `thresholdTuning` to choose a probability cutoff on validation data. The
positive label defaults to the second label in `classLabels`; pass
`positiveLabel` to choose the other class. Use `scoring: 'accuracy'` or
`scoring: 'f1'` to define what the tuner maximizes. The result includes
`bestDecisionThreshold` and `decisionThresholdPositiveLabel`, and
`result.bestModel.predict()` uses that cutoff. The classifier's JSON state
preserves it. In the all-negative case, the selected cutoff can be slightly
above `1` so the model's inclusive probability comparison excludes even a
probability of exactly `1`.

The option supports binary single-label classifiers that expose `predictProba()`:
LogisticRegression, MLPClassifier, DecisionTreeClassifier, KNeighborsClassifier,
GaussianNB, MultinomialNB, BernoulliNB, and SVC. For SVC, set
`probability: true` in `baseOptions`, or search it with a categorical domain
containing only `true` values. Do not combine automatic tuning with LogisticRegression's fixed
`threshold` option.

Threshold tuning currently rejects multiclass and multi-label classification.
These tasks need per-class or per-label decision policies; one binary cutoff
would not define how to choose among multiple mutually exclusive classes.
Regression, clustering, and PCA do not predict class probabilities and cannot
use this option. For fold-aware searches, cutoff selection pools inner
out-of-fold predictions. Nested cross-validation then measures performance on
untouched outer folds.

## Tuning with tabular preprocessing

`createTuner().search` and a direct tuning request accept the same top-level `preprocessing`. Every fit
learns its transformer from its own training rows only: the explicit holdout's training partition, each inner
fold's complement and the final refit. Holdout rows are encoded with the training-only state, so an
extreme or held-out-only value cannot change what was learnt. The winner's transformer and mapping sit
beside `bestModel`, and the portable winner snapshot is `result.bestResult.preprocessorState`.

```typescript
import {
	BatchDatasetProvider,
	CombinedDatasetProvider,
	FittedTabularPreprocessor,
	createTrainingClient,
	createTuner,
	encodeTabularFeatures,
	type TrainingData
} from 'web-ml';

const rows = [
	[1, 'a'],
	[2, 'b'],
	[3, 'a'],
	[4, 'b'],
	[5, 'a'],
	[6, 'b'],
	[7, 'a'],
	[8, 'b']
];
const labels = [0, 0, 0, 0, 1, 1, 1, 1];
const packed = encodeTabularFeatures(rows, [
	{ name: 'x', kind: 'numeric' },
	{ name: 'group', kind: 'categorical' }
]);
const source = (from: number, to: number): TrainingData => ({
	sampleCount: to - from,
	featureCount: 2,
	targetCount: 1,
	batches: (async function* () {
		yield {
			rowCount: to - from,
			features: packed.features.slice(from * 2, to * 2),
			targets: Float64Array.from(labels.slice(from, to))
		};
	})()
});
const search = {
	searchSpace: { learningRate: { kind: 'categorical', values: [0.05] } },
	baseOptions: { solver: 'sgd', maxIter: 30 },
	classLabels: ['no', 'yes'],
	scoring: 'accuracy',
	strategy: { kind: 'random-search', nTrials: 1 }
} as const;

// The facade: the first six rows fit, the last two are held out.
const tuned = await createTuner().search({
	algorithm: 'logistic-regression',
	trainingData: source(0, 6),
	validationData: source(6, 8),
	preprocessing: { columns: packed.columns },
	...search
}).result;
const mapping = tuned.featureNamesOut;

// The direct client: a keyed run whose completed lookup restores the winner's transformer.
const client = createTrainingClient();
await client.train(
	{
		algorithm: 'hyperparameter-tuning',
		targetAlgorithm: 'logistic-regression',
		trainingSampleCount: 6,
		validationSampleCount: 2,
		preprocessing: { columns: packed.columns },
		data: new CombinedDatasetProvider([
			new BatchDatasetProvider(source(0, 6)),
			new BatchDatasetProvider(source(6, 8))
		]),
		...search
	},
	{ cacheKey: 'tuning/v1' }
).result;
const state = await client.checkTrainingState('tuning/v1');
if (state && state.status === 'completed' && state.result.algorithm === 'hyperparameter-tuning') {
	const snapshot = state.result.bestResult.preprocessorState;
	const restored =
		snapshot === undefined ? undefined : FittedTabularPreprocessor.fromJSON(snapshot);
	// Predict from raw rows with the restored transformer and the live winner.
	const raw = [[9, 'a']];
	if (restored) tuned.bestModel.predict(restored.transform(raw));
}
void mapping;
```

For opt-in PCA searches, every admissible component count must fit every fitting partition at its
encoded width, or the whole search is rejected with `invalid-request` before any candidate runs. See
[tabular preprocessing](../specification/public-api/tabular-preprocessing.md).

## Search Spaces

You define the hyperparameter boundaries using the `searchSpace` property. Different hyperparameters support different sampling distributions:

- **`categorical`**: Pick randomly from an array of explicit values (e.g., `{ kind: 'categorical', values: ['l1', 'l2'] }`).
- **`uniform`**: Pick a continuous number between a `min` and `max`.
- **`log-uniform`**: Pick a continuous number, exploring magnitudes evenly (e.g., 0.001 to 0.1). Perfect for learning rates and regularization penalties.
- **`integer`**: Pick a whole number between `min` and `max`.

Any options not listed in the `searchSpace` can be provided statically via `baseOptions`.

## Strategies

`web-ml` supports two primary search strategies:

1. **Random Search** (`kind: 'random-search'`):
   Randomly samples `nTrials` combinations from the search space and trains each one to completion. It is robust and supports every estimator in the library.

2. **Hyperband** (`kind: 'hyperband'`):
   A resumable search that starts candidate models with a small resource budget and promotes the better results. It supports SGD/Adam LinearRegression and PolynomialRegression, SGD/Adam/L-BFGS/coordinate descent LogisticRegression, and SGD/Adam MLPClassifier and MLPRegressor. OLS is not eligible because it has no progressive iteration budget. If a LinearRegression or PolynomialRegression Hyperband request omits `solver`, it starts with SGD.

Hyperband counts one solver iteration as one full-model SGD/Adam update, one
accepted L-BFGS step including its line search, or one complete coordinate
sweep. You can include `solver` in the search space to compare supported
choices. Keep the rest of the options compatible with every solver in the
domain; for example, L-BFGS accepts only no penalty or L2, and Adam uses fixed
settings.

```typescript
const run = createTuner().search({
	algorithm: 'logistic-regression',
	trainingData,
	validationData,
	classLabels: ['negative', 'positive'],
	baseOptions: { penalty: 'l2', tol: 0 },
	searchSpace: {
		solver: {
			kind: 'categorical',
			values: ['sgd', 'adam', 'lbfgs', 'coordinate_descent']
		}
	},
	scoring: 'accuracy',
	strategy: { kind: 'hyperband', minResource: 1, maxResource: 81, eta: 3 }
});
const result = await run.result;
console.table(
	result.trials.map(({ params, status, durationMs }) => ({
		solver: params.solver,
		status,
		durationMs
	}))
);
```

Solver iterations have different run times. Compare the validation score with
each trial's `durationMs`; a resumed rung reports only the time for that rung's
additional iterations. Completed, pruned, and failed trials retain their elapsed
time in the trial summary.

## Resource Management

Tuning can be computationally heavy. `web-ml` automatically scales the work across available CPU cores:

- **`maxWorkers`**: By default, the tuner utilizes one fewer than the reported logical CPU cores on the device. You can explicitly set this to control concurrency.
- **`memoryBudgetBytes`**: The tuner calculates a safe memory budget (defaulting to 128 MiB, or 10% of the device's reported memory) so it doesn't crash the browser tab. If a single estimated trial exceeds this budget, the search is aborted before it even starts.

If a search is canceled (via `AbortSignal`) or fails, any intermediate checkpoint data stored in IndexedDB is automatically cleaned up.

Hyperband stores portable fitted parameters and the optimizer state needed to
continue the same updates, including Adam moments and step count or L-BFGS
history. This resume state stays inside tuning and is removed when the search
settles; the returned winner contains the fitted estimator.
