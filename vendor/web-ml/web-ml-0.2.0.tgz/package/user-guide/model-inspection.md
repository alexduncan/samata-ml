# Model inspection

Fitted models expose what they learned. Decision trees give their full structure and the path
each row takes, Naive Bayes and logistic regression decompose their scores exactly into one term
per input column, MLPs can report a held-out loss per epoch, and `permutationImportance` measures
how much any fitted classifier or regressor relies on each column.

Everything on this page runs on the calling thread, never starts a training worker, and returns
freshly allocated typed arrays you own. The exact layouts, formulas and errors are in the
[model inspection specification](../specification/public-api/model-inspection.md).

Results are per **model input column**. If tabular preprocessing produced the columns, use
`featureNamesOut` to name them.

## Decision tree structure

`tree_` returns parallel typed arrays with one entry per node in pre-order (root 0, left child
first). `apply` gives the leaf of each row, `decisionPath` the root-to-leaf node indices, and
`featureImportances_` the normalised mean decrease in impurity. `maxDepth_` is the realised depth
with the root at 0, not the configured `maxDepth`.

```typescript
import { ArrayDatasetProvider, createTrainingClient } from 'web-ml';

const run = createTrainingClient().train({
	algorithm: 'decision-tree-classifier',
	classLabels: ['low', 'high'],
	options: { maxDepth: 3 },
	data: new ArrayDatasetProvider(
		6,
		2,
		1,
		new Float64Array([0, 5, 1, 5, 2, 5, 7, 5, 8, 5, 9, 5]),
		new Float64Array([0, 0, 0, 1, 1, 1])
	)
});
const { model } = await run.result;

const tree = model.tree_;
console.log(tree.nodeCount, model.nLeaves_, model.maxDepth_);
console.log(tree.feature, tree.threshold, tree.nodeSamples);

const rows = [
	[1, 5],
	[8, 5]
];
console.log(model.apply(rows)); // leaf node index per row
const { indptr, indices } = model.decisionPath(rows);
console.log(indices.subarray(indptr[0], indptr[1])); // nodes visited by row 0
console.log(model.featureImportances_); // the constant second column gets 0
```

A row goes left when `x[feature] <= threshold` and right otherwise, including `NaN`. A tree
state saved before node statistics were recorded still predicts and supports `apply`, but `tree_`
and `featureImportances_` ask for a refit.

## Feature contributions

`featureContributions` splits a Naive Bayes joint log-likelihood or a logistic-regression linear
score exactly into a base term (class prior or intercept) plus one term per input column. With
`C` score columns and `T = featureCount + 1`, `values[(row * C + c) * T]` is the base term and
`values[(row * C + c) * T + 1 + j]` the term for column `j`. Summing a block left to right
reproduces `predictJointLogProba` or `decisionFunction` bit for bit.

```typescript
import { ArrayDatasetProvider, createTrainingClient, featureContributions } from 'web-ml';

const run = createTrainingClient().train({
	algorithm: 'logistic-regression',
	classLabels: ['no', 'yes'],
	options: { solver: 'sgd', learningRate: 0.1, maxIter: 300 },
	data: new ArrayDatasetProvider(
		6,
		2,
		1,
		new Float64Array([0, 0, 0, 1, 1, 0, 1, 1, 2, 1, 2, 2]),
		new Float64Array([0, 0, 0, 1, 1, 1])
	)
});
const { model } = await run.result;

const rows = [
	[1, 1],
	[2, 2]
];
const contributions = featureContributions(model, rows);
console.log(contributions.score, contributions.columnLabels); // 'decision-function', ['yes']

const width = contributions.featureCount + 1;
for (let row = 0; row < contributions.rowCount; row += 1) {
	const block = contributions.values.subarray(row * width, (row + 1) * width);
	console.log('intercept', block[0], 'per column', block.subarray(1));
}
console.log(model.decisionFunction(rows)); // the same scores, shape [2, 1]
```

Naive Bayes models also expose `classLogPrior_` (`MultinomialNB`, `BernoulliNB`),
`featureLogProb_` (`BernoulliNB`) and `predictJointLogProba(X)`. Multiclass and multi-label
logistic regression give one score column per class.

## MLP validation loss

Set `validationFraction` to hold out a share of the fit rows and record the training objective on
them each epoch. The held-out rows are not trained on, the fitted model keeps its final weights,
and `tol` still monitors the training loss. `bestEpoch_` is informational.

```typescript
import { ArrayDatasetProvider, createTrainingClient } from 'web-ml';

const features = new Float64Array(80);
const targets = new Float64Array(40);
for (let row = 0; row < 40; row += 1) {
	features[row * 2] = row / 10;
	features[row * 2 + 1] = (row * 7) % 5;
	targets[row] = row % 2;
}

const run = createTrainingClient().train({
	algorithm: 'mlp-classifier',
	classLabels: ['even', 'odd'],
	options: {
		hiddenLayerSizes: [4],
		maxIter: 50,
		tol: 0,
		randomState: 1,
		validationFraction: 0.25
	},
	data: new ArrayDatasetProvider(40, 2, 1, features, targets)
});
const { model } = await run.result;

console.log(model.lossCurve_.length, model.validationLossCurve_?.length);
console.log('lowest validation loss at epoch', model.bestEpoch_);
```

Classifiers split stratified by class, regressors with a seeded shuffle, both seeded from
`randomState` (0 when omitted). The split is taken after any tabular preprocessing; callers who
need a strictly unseen holdout use the [evaluation](evaluation.md) entry points. Worker curves are
repeatable on one machine but can differ across machines with different worker counts.

## Permutation importance

`permutationImportance` shuffles one column at a time and reports how much a score falls. It works
for any fitted classifier (`'accuracy'`, binary `'f1'`) or single-output regressor (`'r2'`,
`'mean-squared-error'`) and runs on the calling thread, yielding to the event loop between
evaluations. Columns that do not influence predictions get exactly 0.

```typescript
import { ArrayDatasetProvider, createTrainingClient, permutationImportance } from 'web-ml';

const rows = [
	[0, 5],
	[1, 5],
	[2, 5],
	[3, 5],
	[6, 5],
	[7, 5],
	[8, 5],
	[9, 5]
];
const labels = ['a', 'a', 'a', 'a', 'b', 'b', 'b', 'b'];

const run = createTrainingClient().train({
	algorithm: 'decision-tree-classifier',
	classLabels: ['a', 'b'],
	data: new ArrayDatasetProvider(
		8,
		2,
		1,
		Float64Array.from(rows.flat()),
		Float64Array.from(labels, (label) => (label === 'a' ? 0 : 1))
	)
});
const { model } = await run.result;

const controller = new AbortController();
const result = await permutationImportance(
	model,
	{ features: rows, targets: labels },
	{ scoring: 'accuracy', nRepeats: 10, randomState: 1, signal: controller.signal }
);
console.log(result.baselineScore);
console.log(result.importancesMean, result.importancesStd);
```

`'f1'` uses entry 1 of `classLabels` (default `model.classes_`) as the positive label. A regressor
must predict one value per row; a multi-output regressor is rejected with a `RangeError` after a
single `predict` call. An aborted `signal` rejects with an `AbortError`.
