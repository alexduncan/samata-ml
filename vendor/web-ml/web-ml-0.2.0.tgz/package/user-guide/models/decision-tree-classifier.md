# Decision Tree Classifier

**Algorithm ID:** `decision-tree-classifier`

Decision Tree Classifier (DTC) is a non-parametric supervised learning algorithm used for classification. It learns simple decision rules inferred from the data features to predict the class of the target variable.

Under the hood, `web-ml` builds the decision tree using criteria like Gini Impurity, Shannon Entropy, or Log Loss.

## When to Use It

- **Interpretable Models**: When you need a model whose decisions are easy to understand and explain.
- **Non-linear Relationships**: When the data has complex, non-linear relationships that linear models fail to capture.
- **Handling Mixed Data Types**: Decision trees handle both numerical and categorical data well (when encoded properly) and don't require feature scaling.

## Quick Example

```typescript
import { ArrayDatasetProvider, createTrainingClient } from 'web-ml';

const client = createTrainingClient();
const myDatasetProvider = new ArrayDatasetProvider(
	8,
	2,
	1,
	new Float64Array([0, 2, 1, 3, 2, 4, 3, 0, 4, 1, 0, 2, 1, 3, 2, 4]),
	new Float64Array([0, 0, 0, 0, 1, 1, 1, 1])
);

const run = client.train({
	algorithm: 'decision-tree-classifier',
	classLabels: ['A', 'B'],
	options: {
		criterion: 'gini',
		maxDepth: 3,
		minSamplesSplit: 2
	},
	data: myDatasetProvider
});

const { model } = await run.result;

// Predict the most likely class label
const prediction = model.predict([[0.5, 1.2]]);

// Predict probabilities for each class
const probabilities = model.predictProba([[0.5, 1.2]]);
```

## Inspecting the fitted model

`model.tree_` returns the full tree as parallel typed arrays (children, feature, threshold, impurity, node samples, depth and per-class counts) in pre-order. `model.nLeaves_`, `model.featureImportances_`, `model.apply(X)` (leaf per row) and `model.decisionPath(X)` (root-to-leaf nodes per row) complete the view. `maxDepth_` is the realised depth, root at 0, not the `maxDepth` limit. A state saved before node statistics were recorded cannot provide `tree_` or `featureImportances_` until it is refitted. See [Model inspection](../model-inspection.md#decision-tree-structure).

## Hyperparameters

You can configure the model's behavior by passing these properties into the `options` object.

| Option                | Default  | Description                                                                                                                  |
| :-------------------- | :------- | :--------------------------------------------------------------------------------------------------------------------------- |
| `criterion`           | `'gini'` | Impurity criterion to measure split quality. Options: `'gini'`, `'entropy'`, or `'log_loss'`.                                |
| `maxDepth`            | `null`   | Maximum tree depth; `null` indicates unbounded growth until leaves are pure or contain fewer than `minSamplesSplit` samples. |
| `minSamplesSplit`     | `2`      | Minimum number of samples required to split an internal node.                                                                |
| `minSamplesLeaf`      | `1`      | Minimum number of samples required to be at a leaf node.                                                                     |
| `minImpurityDecrease` | `0.0`    | A node will be split if this split induces a decrease of the impurity >= this value.                                         |

## Tune a binary decision threshold

For binary classification, the tuner can choose a cutoff from the tree's leaf
probabilities and apply it to the returned model's `predict()` method.

```typescript
import { createTuner } from 'web-ml';

const search = createTuner().search({
	algorithm: 'decision-tree-classifier',
	trainingData,
	validationData,
	classLabels: ['negative', 'positive'],
	searchSpace: { maxDepth: { kind: 'integer', min: 1, max: 8 } },
	scoring: 'f1',
	thresholdTuning: { positiveLabel: 'positive' },
	strategy: { kind: 'random-search', nTrials: 12, randomState: 4 }
});
const result = await search.result;
const predictions = result.bestModel.predict([[0.5, 1.2]]);
console.log(result.bestDecisionThreshold, predictions);
```
